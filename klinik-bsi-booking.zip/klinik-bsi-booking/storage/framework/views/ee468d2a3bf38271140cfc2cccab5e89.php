<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> · Admin Rumah Sakit BSI</title>
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"><link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-sidebar" data-admin-sidebar>
        <a class="admin-brand" href="<?php echo e(route('admin.dashboard')); ?>"><span class="brand-mark">＋</span><span><strong>RS BSI</strong><small>ADMIN PANEL</small></span></a>
        <div class="sidebar-caption">MENU UTAMA</div>
        <nav class="sidebar-nav">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>"><span>▦</span>Dashboard</a>
            <a href="<?php echo e(route('admin.appointments.index')); ?>" class="<?php echo e(request()->routeIs('admin.appointments.*') ? 'active' : ''); ?>"><span>▣</span>Booking Pasien</a>
            <a href="<?php echo e(route('admin.medical-records.index')); ?>" class="<?php echo e(request()->routeIs('admin.medical-records.*') ? 'active' : ''); ?>"><span>▤</span>Rekam Medis</a>
            <a href="<?php echo e(route('admin.doctors.index')); ?>" class="<?php echo e(request()->routeIs('admin.doctors.*') ? 'active' : ''); ?>"><span>⚕</span>Data Dokter</a>
            <a href="<?php echo e(route('admin.polyclinics.index')); ?>" class="<?php echo e(request()->routeIs('admin.polyclinics.*') ? 'active' : ''); ?>"><span>✚</span>Data Poli</a>
        </nav>
        <div class="sidebar-bottom"><div class="sidebar-user"><span class="admin-avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></span><div><strong><?php echo e(auth()->user()->name); ?></strong><small>Administrator</small></div></div><form method="POST" action="<?php echo e(route('admin.logout')); ?>"><?php echo csrf_field(); ?><button class="sidebar-logout" type="submit"><span>↪</span> Keluar</button></form><a href="<?php echo e(route('home')); ?>" class="sidebar-public-link" target="_blank" rel="noopener">Buka halaman pasien ↗</a></div>
    </aside>
    <div class="admin-main-wrap">
        <header class="admin-topbar"><button class="sidebar-toggle" type="button" data-admin-toggle aria-label="Buka navigasi">☰</button><div><span class="topbar-overline">ADMINISTRASI</span><strong><?php echo $__env->yieldContent('page-heading', 'Dashboard'); ?></strong></div><div class="topbar-right"><span class="admin-live-dot"></span><span>Panel Admin</span><span class="topbar-date"><?php echo e(now('Asia/Jakarta')->format('d M Y')); ?></span></div></header>
        <main class="admin-content">
            <?php if(session('success')): ?><div class="admin-alert success"><span>✓</span><?php echo e(session('success')); ?><button type="button" data-dismiss-alert>×</button></div><?php endif; ?>
            <?php if(session('warning')): ?><div class="admin-alert warning"><span>!</span><?php echo e(session('warning')); ?><button type="button" data-dismiss-alert>×</button></div><?php endif; ?>
            <?php if($errors->any()): ?><div class="admin-alert danger"><span>!</span><div><strong>Periksa kembali input berikut:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><button type="button" data-dismiss-alert>×</button></div><?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>
<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\klinik-bsi-booking\resources\views/layouts/admin.blade.php ENDPATH**/ ?>