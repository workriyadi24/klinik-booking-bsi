<?php $__env->startSection('title', 'Beranda & Jadwal Dokter'); ?>
<?php $__env->startSection('content'); ?>
<section class="home-hero">
    <div class="container home-hero-grid">
        <div class="home-hero-copy">
            <span class="eyebrow">LAYANAN KESEHATAN TERPERCAYA</span>
            <h1>Temukan Dokter<br><span>dan Buat Janji</span><br>dengan Mudah</h1>
            <p>Periksa jadwal praktik dokter, pilih jam yang tersedia, dan daftarkan kunjungan Anda tanpa harus antre untuk pendaftaran.</p>
            <div class="hero-actions"><a class="btn btn-primary" href="#jadwal-dokter">Cari Jadwal Dokter <span>→</span></a><a class="btn btn-outline" href="<?php echo e(route('booking.lookup')); ?>">Cek Booking</a></div>
            <div class="hero-points"><span><b>✓</b> Pilih jadwal per jam</span><span><b>✓</b> Konfirmasi lebih mudah</span></div>
        </div>
        <div class="home-hero-media"><img src="<?php echo e(asset('images/hero-medical-team.jpg')); ?>" alt="Tim dokter Rumah Sakit BSI"><div class="hero-floating"><span class="floating-icon">✚</span><div><strong>Booking online</strong><small>Praktis dan terjadwal</small></div></div></div>
    </div>
</section>

<section class="section section-search" id="jadwal-dokter">
    <div class="container">
        <div class="section-heading"><div><span class="eyebrow">INFORMASI</span><h2>Jadwal Dokter</h2><p>Temukan dokter dan pilih jadwal praktik yang sesuai dengan kebutuhan Anda.</p></div><a class="text-link" href="<?php echo e(route('doctors.index')); ?>">Lihat semua dokter <span>→</span></a></div>
        <form class="filter-bar" action="<?php echo e(route('home')); ?>" method="GET">
            <label class="filter-field"><span>Pilih Poli</span><select name="polyclinic"><option value="">Semua Poli</option><?php $__currentLoopData = $polyclinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $polyclinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($polyclinic->id); ?>" <?php if(request('polyclinic') == $polyclinic->id): echo 'selected'; endif; ?>><?php echo e($polyclinic->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <label class="filter-field"><span>Nama Dokter</span><input type="search" name="doctor" placeholder="Cari nama dokter..." value="<?php echo e(request('doctor')); ?>"></label>
            <button class="btn btn-primary" type="submit">Tampilkan Jadwal</button>
        </form>

        <div class="doctor-list">
            <?php $__empty_1 = true; $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="doctor-row-card">
                    <div class="doctor-mini-profile">
                        <div class="doctor-avatar-ring"><img src="<?php echo e($doctor->photo_url); ?>" alt="Foto <?php echo e($doctor->name); ?>"></div>
                        <div class="doctor-profile-text"><span class="tag tag-teal"><?php echo e($doctor->polyclinic->name); ?></span><h3><?php echo e($doctor->name); ?><?php echo e($doctor->title ? ', '.$doctor->title : ''); ?></h3><p><?php echo e($doctor->speciality); ?></p><div class="doctor-meta"><span>☆ <?php echo e(number_format((float) $doctor->rating, 1)); ?></span><span><?php echo e($doctor->experience_years); ?>+ tahun pengalaman</span></div><a class="btn btn-small btn-primary" href="<?php echo e(route('appointments.create', $doctor)); ?>">Daftar Online</a></div>
                    </div>
                    <div class="weekly-schedule-wrap">
                        <div class="schedule-caption"><span>Jadwal Praktik</span><small>Jam yang ditampilkan adalah jam praktik dokter.</small></div>
                        <div class="weekly-grid">
                            <?php $__currentLoopData = \App\Models\DoctorSchedule::DAYS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php ($daySchedules = $doctor->schedules->where('day_of_week', $day)->where('is_active', true)); ?>
                                <div class="weekly-day"><strong><?php echo e(substr($dayName, 0, 3)); ?></strong><span><?php $__empty_2 = true; $__currentLoopData = $daySchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><?php echo e(substr($schedule->start_time, 0, 5)); ?>–<?php echo e(substr($schedule->end_time, 0, 5)); ?><?php if(!$loop->last): ?><br><?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?> <em>–</em> <?php endif; ?></span></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="schedule-card-footer"><span><i class="mini-dot"></i> Slot dapat dipilih sesuai ketersediaan</span><a href="<?php echo e(route('doctors.show', $doctor)); ?>">Detail dokter <span>→</span></a></div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state"><div class="empty-icon">⌕</div><h3>Dokter belum ditemukan</h3><p>Coba ubah pilihan poli atau kata kunci pencarian Anda.</p><a href="<?php echo e(route('home')); ?>" class="btn btn-outline">Reset Filter</a></div>
            <?php endif; ?>
        </div>
        <div class="pagination-wrap"><?php echo e($doctors->links()); ?></div>
    </div>
</section>
<section class="section section-soft"><div class="container feature-grid"><div><span class="eyebrow">ALUR PENDAFTARAN</span><h2>Booking dokter dalam<br><span>3 langkah sederhana</span></h2><p>Seluruh proses dirancang agar pasien dapat mendaftar dengan jelas dan nyaman.</p></div><div class="feature-item"><b>01</b><div><h3>Pilih dokter</h3><p>Tentukan poli dan dokter sesuai kebutuhan pemeriksaan.</p></div></div><div class="feature-item"><b>02</b><div><h3>Pilih tanggal & jam</h3><p>Jam yang telah dipesan otomatis tidak bisa dipilih pasien lain.</p></div></div><div class="feature-item"><b>03</b><div><h3>Isi data pasien</h3><p>Simpan kode booking untuk melihat status pendaftaran Anda.</p></div></div></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\klinik-bsi-booking\resources\views/public/home.blade.php ENDPATH**/ ?>