<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Portal Dokter'); ?> · Rumah Sakit BSI</title>
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"><link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>"><link rel="stylesheet" href="<?php echo e(asset('css/portal.css')); ?>">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-sidebar doctor-sidebar" data-admin-sidebar>
        <a class="admin-brand" href="<?php echo e(route('doctor-portal.dashboard')); ?>"><span class="brand-mark">＋</span><span><strong>RS BSI</strong><small>DOCTOR PORTAL</small></span></a>
        <div class="sidebar-caption">RUANG PRAKTIK</div>
        <nav class="sidebar-nav"><a href="<?php echo e(route('doctor-portal.dashboard')); ?>" class="<?php echo e(request()->routeIs('doctor-portal.dashboard') ? 'active' : ''); ?>"><span>▦</span>Ringkasan</a><a href="<?php echo e(route('doctor-portal.dashboard')); ?>#jadwal"><span>▣</span>Jadwal Pasien</a><a href="<?php echo e(route('doctor-portal.medical-records.index')); ?>" class="<?php echo e(request()->routeIs('doctor-portal.medical-records.*') ? 'active' : ''); ?>"><span>▤</span>Rekam Medis</a></nav>
        <div class="sidebar-bottom"><div class="sidebar-user"><span class="admin-avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></span><div><strong><?php echo e(auth()->user()->name); ?></strong><small>Dokter · <?php echo e(auth()->user()->doctor?->speciality); ?></small></div></div><form method="POST" action="<?php echo e(route('doctor-portal.logout')); ?>"><?php echo csrf_field(); ?><button class="sidebar-logout" type="submit"><span>↪</span> Keluar</button></form><a href="<?php echo e(route('home')); ?>" class="sidebar-public-link">Buka halaman pasien ↗</a></div>
    </aside>
    <div class="admin-main-wrap"><header class="admin-topbar"><button class="sidebar-toggle" type="button" data-admin-toggle aria-label="Buka navigasi">☰</button><div><span class="topbar-overline">PORTAL DOKTER</span><strong><?php echo $__env->yieldContent('page-heading', 'Dashboard'); ?></strong></div><div class="topbar-right"><span class="admin-live-dot"></span><span>Ruang Praktik</span><span class="topbar-date"><?php echo e(now('Asia/Jakarta')->format('d M Y')); ?></span></div></header>
        <main class="admin-content"><?php if(session('success')): ?><div class="admin-alert success"><span>✓</span><?php echo e(session('success')); ?><button type="button" data-dismiss-alert>×</button></div><?php endif; ?> <?php if(session('warning')): ?><div class="admin-alert warning"><span>!</span><?php echo e(session('warning')); ?><button type="button" data-dismiss-alert>×</button></div><?php endif; ?> <?php if($errors->any()): ?><div class="admin-alert danger"><span>!</span><div><strong>Periksa kembali input berikut:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><button type="button" data-dismiss-alert>×</button></div><?php endif; ?> <?php echo $__env->yieldContent('content'); ?></main>
    </div>
</div><?php if(request()->routeIs('doctor-portal.medical-records.*')): ?><script src="https://cdn.jsdelivr.net/npm/sweetalert2@11" defer></script><?php endif; ?><script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body></html>
<?php /**PATH C:\Users\klinik-bsi-booking\resources\views/layouts/doctor-portal.blade.php ENDPATH**/ ?>