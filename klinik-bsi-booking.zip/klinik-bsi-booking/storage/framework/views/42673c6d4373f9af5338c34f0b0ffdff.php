<?php if(session('success')): ?>
    <div class="container flash-wrap"><div class="alert alert-success" role="status"><span>✓</span><?php echo e(session('success')); ?><button type="button" data-dismiss-alert aria-label="Tutup">×</button></div></div>
<?php endif; ?>
<?php if(session('info')): ?>
    <div class="container flash-wrap"><div class="alert alert-info" role="status"><span>ⓘ</span><?php echo e(session('info')); ?><button type="button" data-dismiss-alert aria-label="Tutup">×</button></div></div>
<?php endif; ?>
<?php if(session('warning')): ?>
    <div class="container flash-wrap"><div class="alert alert-warning" role="alert"><span>!</span><?php echo e(session('warning')); ?><button type="button" data-dismiss-alert aria-label="Tutup">×</button></div></div>
<?php endif; ?>
<?php if($errors->any()): ?>
    <div class="container flash-wrap"><div class="alert alert-danger" role="alert"><span>!</span><div><strong>Periksa kembali data Anda.</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><button type="button" data-dismiss-alert aria-label="Tutup">×</button></div></div>
<?php endif; ?>
<?php /**PATH C:\Users\klinik-bsi-booking\resources\views/partials/flash.blade.php ENDPATH**/ ?>