
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Login Admin · Rumah Sakit BSI</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
</head>

<body class="login-body">

    <div class="login-layout">

        <!-- Login Visual -->
        <div class="login-visual">

            <div class="login-brand">
                <span class="brand-mark">＋</span>

                <span>
                    <strong>RUMAH SAKIT BSI</strong>
                    <small>HEALTHCARE & APPOINTMENT</small>
                </span>
            </div>

            <div class="login-visual-copy">

                <span class="eyebrow">ADMINISTRATOR AREA</span>

                <h1>
                    Kelola layanan
                    <br>
                    <span>lebih teratur.</span>
                </h1>

                <p>
                    Pantau pendaftaran pasien, atur jadwal dokter,
                    dan kelola informasi poliklinik melalui satu dashboard.
                </p>

            </div>

            <img
                src="<?php echo e(asset('images/hero-medical-team.jpg')); ?>"
                alt="Tim medis"
            >

        </div>


        <!-- Login Form -->
        <div class="login-form-side">

            <form
                class="login-card"
                method="POST"
                action="<?php echo e(route('admin.login.submit')); ?>"
            >

                <?php echo csrf_field(); ?>

                <div class="login-card-mark">
                    ＋
                </div>

                <span class="eyebrow">
                    SELAMAT DATANG
                </span>

                <h2>Login Admin</h2>

                <p>
                    Masuk menggunakan akun administrator Anda.
                </p>


                
                <?php if(session('warning')): ?>
                    <div class="inline-message">
                        <?php echo e(session('warning')); ?>

                    </div>
                <?php endif; ?>


                
                <?php if($errors->any()): ?>
                    <div class="inline-error">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>


                <!-- Email -->
                <label class="form-field">

                    <span>Email Admin</span>

                    <input
                        class="form-control"
                        type="email"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        placeholder="admin@rumahsakit.test"
                        autocomplete="username"
                        required
                        autofocus
                    >

                </label>


                <!-- Password -->
                <label class="form-field">

                    <span>Password</span>

                    <input
                        class="form-control"
                        type="password"
                        name="password"
                        placeholder="Masukkan password"
                        autocomplete="current-password"
                        required
                    >

                </label>


                <!-- Remember Me -->
                <label class="check-field remember-field">

                    <input
                        type="checkbox"
                        name="remember"
                        value="1"
                    >

                    <span>Ingat saya</span>

                </label>


                <!-- Submit -->
                <button
                    class="btn btn-primary btn-block btn-large"
                    type="submit"
                >
                    Masuk Dashboard
                    <span>→</span>
                </button>


                <!-- Back to Home -->
                <a
                    class="login-back-link"
                    href="<?php echo e(route('home')); ?>"
                >
                    ← Kembali ke halaman pasien
                </a>

            </form>


            <small class="login-copyright">
                © <?php echo e(date('Y')); ?> Rumah Sakit BSI
            </small>

        </div>

    </div>

</body>

</html>
<?php /**PATH C:\Users\klinik-bsi-booking\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>