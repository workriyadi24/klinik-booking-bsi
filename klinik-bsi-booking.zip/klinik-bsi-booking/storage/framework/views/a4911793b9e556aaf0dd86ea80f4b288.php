<?php $__env->startSection('title', 'Rekam Medis Pasien'); ?>
<?php $__env->startSection('page-heading', 'Rekam Medis'); ?>
<?php $__env->startSection('content'); ?>
<div class="admin-page-heading"><div><span class="eyebrow">DOKUMENTASI KLINIS</span><h1>Rekam Medis Pasien</h1><p>Catatan pemeriksaan yang berada dalam kewenangan praktik Anda.</p></div></div>
<section class="admin-panel">
    <form class="admin-filter-form" method="GET" action="<?php echo e(route('doctor-portal.medical-records.index')); ?>">
        <label><span>Cari rekam medis, pasien, atau nomor RM</span><input class="form-control" type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="Contoh: RME-... atau nama pasien"></label>
        <label><span>Status</span><select class="form-control" name="status"><option value="">Semua status</option><option value="draft" <?php if(request('status')==='draft'): echo 'selected'; endif; ?>>Draf</option><option value="finalized" <?php if(request('status')==='finalized'): echo 'selected'; endif; ?>>Disahkan</option></select></label>
        <button class="btn btn-primary" type="submit">Terapkan</button>
        <?php if(request()->query()): ?><a class="btn btn-outline" href="<?php echo e(route('doctor-portal.medical-records.index')); ?>">Reset</a><?php endif; ?>
    </form>
    <div class="table-scroll"><table class="admin-table"><thead><tr><th>No. Rekam Medis</th><th>Pasien</th><th>Tanggal</th><th>Poliklinik</th><th>Status</th><th></th></tr></thead><tbody>
    <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr><td><strong><?php echo e($record->record_number); ?></strong><small><?php echo e($record->appointment->booking_code); ?></small></td><td><strong><?php echo e($record->patient->full_name); ?></strong><small><?php echo e($record->patient->medical_record_number); ?></small></td><td class="nowrap"><?php echo e($record->encounter_date->format('d M Y')); ?></td><td><?php echo e($record->polyclinic->name); ?></td><td><span class="status-badge <?php echo e($record->status_class); ?>"><?php echo e($record->status_label); ?></span></td><td><a class="table-action" href="<?php echo e($record->isFinalized() ? route('doctor-portal.medical-records.show',$record) : route('doctor-portal.medical-records.edit',$record)); ?>"><?php echo e($record->isFinalized() ? 'Lihat' : 'Lanjutkan draf'); ?></a></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6"><div class="table-empty">Belum ada rekam medis. Rekam medis dibuat melalui detail janji temu setelah pemeriksaan dilakukan.</div></td></tr>
    <?php endif; ?>
    </tbody></table></div>
    <?php if($records->hasPages()): ?><div class="admin-pagination"><?php echo e($records->links()); ?></div><?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor-portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\klinik-bsi-booking\resources\views/doctor-portal/medical-records/index.blade.php ENDPATH**/ ?>