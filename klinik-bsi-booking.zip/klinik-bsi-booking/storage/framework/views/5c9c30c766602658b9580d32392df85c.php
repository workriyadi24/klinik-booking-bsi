<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="Informasi jadwal dokter dan pendaftaran janji temu Rumah Sakit BSI.">
    <title><?php echo $__env->yieldContent('title', 'Rumah Sakit BSI'); ?> - Rumah Sakit BSI</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php if(request()->routeIs('patient.*') || request()->routeIs('doctor-portal.login')): ?><link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>"><?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/portal.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="public-body">
    <div class="top-strip"><div class="container top-strip-inner"><span>PENDAFTARAN RUMAH SAKIT BSI</span><span><i class="dot-live"></i> Layanan informasi & pendaftaran online</span></div></div>
    <header class="site-header">
        <div class="container nav-inner">
            <a class="brand" href="<?php echo e(route('home')); ?>" aria-label="Rumah Sakit BSI Beranda">
                <span class="brand-mark">＋</span>
                <span class="brand-text"><strong>RUMAH SAKIT</strong><small>BSI · HEALTHCARE</small></span>
            </a>
            <button class="nav-toggle" type="button" aria-label="Buka menu" aria-expanded="false" data-nav-toggle><span></span><span></span><span></span></button>
            <nav class="main-nav" data-nav-menu>
                <a class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a>
                <a class="<?php echo e(request()->routeIs('doctors.*') ? 'active' : ''); ?>" href="<?php echo e(route('doctors.index')); ?>">Dokter</a>
                <a class="<?php echo e(request()->routeIs('information') ? 'active' : ''); ?>" href="<?php echo e(route('information')); ?>">Informasi</a>
                <a class="<?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">Kontak</a>
                <a class="nav-track" href="<?php echo e(route('booking.lookup')); ?>">Cek Booking</a>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->isPatient()): ?>
                        <a class="nav-account" href="<?php echo e(route('patient.dashboard')); ?>">Akun Saya</a>
                        <a class="nav-account" href="<?php echo e(route('patient.medical-records.index')); ?>">Rekam Medis</a>
                        <form class="nav-logout-form" method="POST" action="<?php echo e(route('patient.logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Keluar</button></form>
                    <?php elseif(auth()->user()->isDoctor()): ?>
                        <a class="nav-account" href="<?php echo e(route('doctor-portal.dashboard')); ?>">Portal Dokter</a>
                    <?php elseif(auth()->user()->is_admin): ?>
                        <a class="nav-account" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard Admin</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a class="nav-login" href="<?php echo e(route('patient.login')); ?>">Masuk</a>
                    <a class="nav-account" href="<?php echo e(route('patient.register')); ?>">Daftar Pasien</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="site-footer">
        <div class="container footer-grid">
            <div><span class="footer-label">HUBUNGI KAMI</span><strong><?php echo e(config('clinic.phone')); ?></strong><p>Layanan Informasi & Pendaftaran</p></div>
            <div><span class="footer-label">ALAMAT</span><strong><?php echo e(config('clinic.address')); ?></strong><p>Rumah Sakit BSI</p></div>
            <div><span class="footer-label">JAM LAYANAN</span><strong><?php echo e(config('clinic.open_hours')); ?></strong><p>Informasi jadwal dokter dapat berubah.</p><p><a href="<?php echo e(route('doctor-portal.login')); ?>">Portal Dokter</a> · <a href="<?php echo e(route('admin.login')); ?>">Admin</a></p></div>
        </div>
        <div class="footer-bottom">Copyright © <?php echo e(date('Y')); ?> Rumah Sakit BSI. All Rights Reserved.</div>
    </footer>
    <?php if(request()->routeIs('appointments.create')): ?><script src="https://cdn.jsdelivr.net/npm/sweetalert2@11" defer></script><?php endif; ?>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\klinik-bsi-booking\resources\views/layouts/public.blade.php ENDPATH**/ ?>