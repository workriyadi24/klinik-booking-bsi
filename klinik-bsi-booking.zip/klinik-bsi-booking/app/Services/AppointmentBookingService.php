<?php

namespace App\Services;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\DoctorSchedule;
use App\Models\Patient;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AppointmentBookingService
{
    /**
     * Return available slots for a doctor on a date. A booked slot stays unavailable
     * until its appointment is explicitly cancelled.
     */
    public function availableSlots(Doctor $doctor, string $date, ?int $exceptAppointmentId = null): array
    {
        $day = Carbon::parse($date)->dayOfWeek;
        $exception = $doctor->exceptions()->whereDate('exception_date', $date)->first();

        if ($exception?->is_closed) {
            return [];
        }

        $schedules = $doctor->schedules()
            ->where('is_active', true)
            ->where('day_of_week', $day)
            ->where(function ($query) use ($date) {
                $query->whereNull('valid_from')->orWhereDate('valid_from', '<=', $date);
            })
            ->where(function ($query) use ($date) {
                $query->whereNull('valid_until')->orWhereDate('valid_until', '>=', $date);
            })
            ->get();

        // An open exception may define special hours even when no regular schedule exists.
        if ($exception && !$exception->is_closed && $exception->start_time && $exception->end_time) {
            $schedules = collect([(object) [
                'id' => null,
                'start_time' => $exception->start_time,
                'end_time' => $exception->end_time,
                'slot_duration_minutes' => 60,
            ]]);
        }

        if ($schedules->isEmpty()) {
            return [];
        }

        $bookedTimes = Appointment::query()
            ->where('doctor_id', $doctor->id)
            ->whereDate('appointment_date', $date)
            ->where('status', '!=', 'cancelled')
            ->when($exceptAppointmentId, fn ($query) => $query->where('id', '!=', $exceptAppointmentId))
            ->pluck('start_time')
            ->map(fn ($time) => substr((string) $time, 0, 5))
            ->all();

        $slots = [];
        $now = now('Asia/Jakarta');
        $targetDate = Carbon::parse($date, 'Asia/Jakarta')->startOfDay();

        foreach ($schedules as $schedule) {
            $cursor = Carbon::parse($date.' '.$schedule->start_time, 'Asia/Jakarta');
            $end = Carbon::parse($date.' '.$schedule->end_time, 'Asia/Jakarta');
            $duration = max(15, (int) $schedule->slot_duration_minutes);

            while ($cursor->copy()->addMinutes($duration)->lessThanOrEqualTo($end)) {
                $slotStart = $cursor->format('H:i');
                $slotEnd = $cursor->copy()->addMinutes($duration)->format('H:i');
                $isPast = $targetDate->isToday() && $cursor->lessThanOrEqualTo($now);
                $isBooked = in_array($slotStart, $bookedTimes, true);

                $slots[] = [
                    'time' => $slotStart,
                    'end_time' => $slotEnd,
                    'schedule_id' => $schedule->id,
                    'available' => !$isPast && !$isBooked && $doctor->is_active,
                    'reason' => $isPast ? 'Waktu telah lewat' : ($isBooked ? 'Sudah dibooking' : null),
                ];

                $cursor->addMinutes($duration);
            }
        }

        usort($slots, fn ($a, $b) => strcmp($a['time'], $b['time']));

        return $slots;
    }

    public function findAvailableSlot(Doctor $doctor, string $date, string $startTime, ?int $exceptAppointmentId = null): array
    {
        $slot = collect($this->availableSlots($doctor, $date, $exceptAppointmentId))
            ->first(fn ($item) => $item['time'] === substr($startTime, 0, 5) && $item['available']);

        if (!$slot) {
            throw ValidationException::withMessages([
                'start_time' => 'Jadwal tersebut sudah tidak tersedia. Silakan pilih jam lain.',
            ]);
        }

        return $slot;
    }

    public function createBookingForPatient(array $data, Doctor $doctor, Patient $patient): Appointment
    {
        return DB::transaction(function () use ($data, $doctor, $patient) {
            $lockedDoctor = Doctor::query()->whereKey($doctor->id)->lockForUpdate()->firstOrFail();
            if (!$lockedDoctor->is_active || !$lockedDoctor->polyclinic()->where('is_active', true)->exists()) {
                throw ValidationException::withMessages(['doctor_id' => 'Dokter atau poliklinik sedang tidak menerima booking.']);
            }

            $slot = $this->findAvailableSlot($lockedDoctor, $data['appointment_date'], $data['start_time']);

            return Appointment::create([
                'booking_code' => $this->generateBookingCode(),
                'patient_id' => $patient->id,
                'doctor_id' => $lockedDoctor->id,
                'polyclinic_id' => $lockedDoctor->polyclinic_id,
                'doctor_schedule_id' => $slot['schedule_id'],
                'appointment_date' => $data['appointment_date'],
                'start_time' => $slot['time'],
                'end_time' => $slot['end_time'],
                'status' => 'pending',
                'complaint' => $data['complaint'],
                'symptoms' => $data['symptoms'] ?? null,
                'symptom_duration' => $data['symptom_duration'] ?? null,
                'created_by' => $patient->user_id,
            ]);
        }, 3);
    }

    public function updateAppointment(Appointment $appointment, array $data, Doctor $doctor): Appointment
    {
        return DB::transaction(function () use ($appointment, $data, $doctor) {
            $lockedDoctor = Doctor::query()->whereKey($doctor->id)->lockForUpdate()->firstOrFail();
            $sameSlot = $appointment->status !== 'cancelled'
                && (int) $appointment->doctor_id === (int) $lockedDoctor->id
                && $appointment->appointment_date->toDateString() === $data['appointment_date']
                && substr((string) $appointment->start_time, 0, 5) === substr($data['start_time'], 0, 5);

            $doctorCanReceiveBooking = $lockedDoctor->is_active
                && $lockedDoctor->polyclinic()->where('is_active', true)->exists();
            if (!$doctorCanReceiveBooking && !$sameSlot) {
                throw ValidationException::withMessages([
                    'doctor_id' => 'Dokter atau poliklinik sudah nonaktif. Pilih dokter aktif untuk reschedule.',
                ]);
            }

            $slot = $sameSlot
                ? [
                    'time' => substr((string) $appointment->start_time, 0, 5),
                    'end_time' => substr((string) $appointment->end_time, 0, 5),
                    'schedule_id' => $appointment->doctor_schedule_id,
                ]
                : $this->findAvailableSlot(
                    $lockedDoctor,
                    $data['appointment_date'],
                    $data['start_time'],
                    $appointment->id
                );

            $patientData = array_intersect_key($data, array_flip([
                'full_name', 'birth_place', 'birth_date', 'gender', 'address', 'religion',
                'family_card_number', 'marital_status', 'education', 'phone', 'email',
            ]));
            $patientData['family_card_number'] = $patientData['family_card_number'] ?: null;
            $appointment->patient->update($patientData);

            $status = $data['status'];
            $appointment->fill([
                'doctor_id' => $lockedDoctor->id,
                'polyclinic_id' => $lockedDoctor->polyclinic_id,
                'doctor_schedule_id' => $slot['schedule_id'],
                'appointment_date' => $data['appointment_date'],
                'start_time' => $slot['time'],
                'end_time' => $slot['end_time'],
                'status' => $status,
                'complaint' => $data['complaint'] ?? null,
                'admin_notes' => $data['admin_notes'] ?? null,
                'confirmed_at' => $status === 'confirmed' ? ($appointment->confirmed_at ?? now()) : null,
                'completed_at' => $status === 'completed' ? ($appointment->completed_at ?? now()) : null,
                'no_show_at' => $status === 'no_show' ? ($appointment->no_show_at ?? now()) : null,
                'cancelled_at' => $status === 'cancelled' ? ($appointment->cancelled_at ?? now()) : null,
            ])->save();

            return $appointment->fresh(['patient', 'doctor', 'polyclinic']);
        }, 3);
    }

    private function generateBookingCode(): string
    {
        do {
            $code = 'BSI'.strtoupper(\Illuminate\Support\Str::random(7));
        } while (Appointment::where('booking_code', $code)->exists());

        return $code;
    }
}
