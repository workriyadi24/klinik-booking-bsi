<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DoctorScheduleException extends Model
{
    protected $fillable = ['doctor_id', 'exception_date', 'is_closed', 'start_time', 'end_time', 'note'];

    protected function casts(): array
    {
        return ['exception_date' => 'date', 'is_closed' => 'boolean'];
    }

    public function doctor(): BelongsTo
    {
        return $this->belongsTo(Doctor::class);
    }
}
