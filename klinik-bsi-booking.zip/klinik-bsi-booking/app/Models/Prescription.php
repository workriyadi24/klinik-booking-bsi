<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Prescription extends Model
{
    protected $fillable = ['prescription_number', 'medical_record_id', 'instructions', 'status', 'issued_at'];

    protected function casts(): array
    {
        return ['issued_at' => 'datetime'];
    }

    public function medicalRecord(): BelongsTo { return $this->belongsTo(MedicalRecord::class); }
    public function items(): HasMany { return $this->hasMany(PrescriptionItem::class)->orderBy('sort_order')->orderBy('id'); }
}
