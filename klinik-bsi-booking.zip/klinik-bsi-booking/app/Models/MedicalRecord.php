<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class MedicalRecord extends Model
{
    public const STATUSES = ['draft', 'finalized'];

    protected $fillable = [
        'record_number', 'appointment_id', 'patient_id', 'doctor_id', 'polyclinic_id',
        'patient_allergies_snapshot', 'patient_medical_history_snapshot', 'patient_current_medications_snapshot',
        'encounter_date', 'encounter_time', 'subjective', 'objective', 'blood_pressure',
        'temperature_celsius', 'heart_rate_bpm', 'respiratory_rate_per_minute', 'weight_kg',
        'height_cm', 'oxygen_saturation_percent', 'assessment', 'plan', 'procedures',
        'follow_up_date', 'follow_up_notes', 'status', 'created_by', 'finalized_by', 'finalized_at',
    ];

    protected function casts(): array
    {
        return [
            'encounter_date' => 'date',
            'follow_up_date' => 'date',
            'temperature_celsius' => 'decimal:1',
            'weight_kg' => 'decimal:2',
            'height_cm' => 'decimal:2',
            'finalized_at' => 'datetime',
        ];
    }

    public function appointment(): BelongsTo { return $this->belongsTo(Appointment::class); }
    public function patient(): BelongsTo { return $this->belongsTo(Patient::class); }
    public function doctor(): BelongsTo { return $this->belongsTo(Doctor::class); }
    public function polyclinic(): BelongsTo { return $this->belongsTo(Polyclinic::class); }
    public function creator(): BelongsTo { return $this->belongsTo(User::class, 'created_by'); }
    public function finalizer(): BelongsTo { return $this->belongsTo(User::class, 'finalized_by'); }
    public function prescription(): HasOne { return $this->hasOne(Prescription::class); }
    public function addenda(): HasMany { return $this->hasMany(MedicalRecordAddendum::class)->latest(); }
    public function audits(): HasMany { return $this->hasMany(MedicalRecordAudit::class)->latest(); }

    public function isFinalized(): bool
    {
        return $this->status === 'finalized' && $this->finalized_at !== null;
    }

    public function getStatusLabelAttribute(): string
    {
        return $this->isFinalized() ? 'Disahkan' : 'Draf';
    }

    public function getStatusClassAttribute(): string
    {
        return $this->isFinalized() ? 'success' : 'warning';
    }

    public function logActivity(?User $actor, string $action, array $details = [], ?string $ip = null, ?string $userAgent = null): void
    {
        $this->audits()->create([
            'actor_user_id' => $actor?->id,
            'action' => $action,
            'details' => $details ?: null,
            'ip_address' => $ip,
            'user_agent' => $userAgent ? mb_substr($userAgent, 0, 512) : null,
        ]);
    }
}
