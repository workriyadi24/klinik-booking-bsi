<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DoctorSchedule extends Model
{
    public const DAYS = [
        0 => 'Minggu', 1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu',
        4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu',
    ];

    protected $fillable = [
        'doctor_id', 'day_of_week', 'start_time', 'end_time',
        'slot_duration_minutes', 'valid_from', 'valid_until', 'is_active',
    ];

    protected function casts(): array
    {
        return ['is_active' => 'boolean', 'valid_from' => 'date', 'valid_until' => 'date'];
    }

    public function doctor(): BelongsTo
    {
        return $this->belongsTo(Doctor::class);
    }

    public function getDayNameAttribute(): string
    {
        return self::DAYS[$this->day_of_week] ?? '-';
    }
}
