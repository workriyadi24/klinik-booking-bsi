<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Facades\Storage;

class Doctor extends Model
{
    protected $fillable = [
        'polyclinic_id', 'name', 'slug', 'title', 'speciality', 'photo_path',
        'experience_years', 'rating', 'rating_count', 'practice_location', 'bio', 'is_active',
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'rating' => 'decimal:1',
            'experience_years' => 'integer',
            'rating_count' => 'integer',
        ];
    }

    public function polyclinic(): BelongsTo
    {
        return $this->belongsTo(Polyclinic::class);
    }

    public function user(): HasOne
    {
        return $this->hasOne(User::class);
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(DoctorSchedule::class)->orderBy('day_of_week')->orderBy('start_time');
    }

    public function exceptions(): HasMany
    {
        return $this->hasMany(DoctorScheduleException::class);
    }

    public function appointments(): HasMany
    {
        return $this->hasMany(Appointment::class);
    }

    public function medicalRecords(): HasMany
    {
        return $this->hasMany(MedicalRecord::class);
    }

    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    public function getPhotoUrlAttribute(): string
    {
        if ($this->photo_path && Storage::disk('public')->exists($this->photo_path)) {
            return Storage::disk('public')->url($this->photo_path);
        }

        $demoPhotos = [
            'dr-syifa-azzahra-spkj' => 'images/doctor-syifa.jpg',
            'dr-andi-pratama-sppd' => 'images/doctor-andi.jpg',
            'dr-nabila-putri-spm' => 'images/doctor-nabila.jpg',
            'dr-bima-saputra-spog' => 'images/doctor-bima.jpg',
        ];

        return asset($demoPhotos[$this->slug] ?? 'images/hero-medical-team.jpg');
    }
}
