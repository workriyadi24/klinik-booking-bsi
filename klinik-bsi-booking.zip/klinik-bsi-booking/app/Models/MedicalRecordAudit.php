<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MedicalRecordAudit extends Model
{
    protected $fillable = ['medical_record_id', 'actor_user_id', 'action', 'details', 'ip_address', 'user_agent'];

    protected function casts(): array
    {
        return ['details' => 'array'];
    }

    public function medicalRecord(): BelongsTo { return $this->belongsTo(MedicalRecord::class); }
    public function actor(): BelongsTo { return $this->belongsTo(User::class, 'actor_user_id'); }
}
