<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\Polyclinic;

class DashboardController extends Controller
{
    public function index()
    {
        $today = now('Asia/Jakarta')->toDateString();
        $stats = [
            'today' => Appointment::whereDate('appointment_date', $today)->where('status', '!=', 'cancelled')->count(),
            'pending' => Appointment::where('status', 'pending')->count(),
            'confirmed' => Appointment::whereDate('appointment_date', $today)->where('status', 'confirmed')->count(),
            'no_show' => Appointment::whereDate('appointment_date', $today)->where('status', 'no_show')->count(),
            'doctors' => Doctor::where('is_active', true)->count(),
            'patients' => Patient::count(),
            'polyclinics' => Polyclinic::where('is_active', true)->count(),
        ];

        $todayAppointments = Appointment::with(['patient', 'doctor', 'polyclinic'])
            ->whereDate('appointment_date', $today)
            ->orderBy('start_time')->limit(8)->get();

        $upcomingAppointments = Appointment::with(['patient', 'doctor'])
            ->whereDate('appointment_date', '>', $today)
            ->whereIn('status', ['pending', 'confirmed'])
            ->orderBy('appointment_date')->orderBy('start_time')->limit(5)->get();

        return view('admin.dashboard.index', compact('stats', 'todayAppointments', 'upcomingAppointments'));
    }
}
