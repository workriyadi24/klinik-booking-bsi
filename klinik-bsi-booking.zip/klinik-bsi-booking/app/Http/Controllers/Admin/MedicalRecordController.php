<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MedicalRecord;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

class MedicalRecordController extends Controller
{
    public function index(Request $request)
    {
        $records = MedicalRecord::with(['patient', 'doctor', 'polyclinic', 'appointment'])
            ->when($request->filled('status'), fn (Builder $query) => $query->where('status', $request->string('status')->toString()))
            ->when($request->filled('q'), function (Builder $query) use ($request) {
                $term = trim($request->string('q')->toString());
                $query->where(function (Builder $sub) use ($term) {
                    $sub->where('record_number', 'like', "%{$term}%")
                        ->orWhereHas('patient', fn (Builder $patient) => $patient->where('full_name', 'like', "%{$term}%")->orWhere('medical_record_number', 'like', "%{$term}%"))
                        ->orWhereHas('doctor', fn (Builder $doctor) => $doctor->where('name', 'like', "%{$term}%"));
                });
            })
            ->orderByDesc('encounter_date')->orderByDesc('id')->paginate(15)->withQueryString();

        return view('admin.medical-records.index', compact('records'));
    }

    public function show(Request $request, MedicalRecord $medicalRecord)
    {
        $medicalRecord->logActivity($request->user(), 'viewed_by_admin', [], $request->ip(), $request->userAgent());
        $medicalRecord->load([
            'patient', 'doctor', 'polyclinic', 'appointment', 'prescription.items',
            'addenda.creator', 'audits.actor', 'creator', 'finalizer',
        ]);

        return view('admin.medical-records.show', compact('medicalRecord'));
    }
}
