<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Polyclinic;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class PolyclinicController extends Controller
{
    public function index()
    {
        $polyclinics = Polyclinic::withCount('doctors')->orderBy('sort_order')->orderBy('name')->paginate(15);

        return view('admin.polyclinics.index', compact('polyclinics'));
    }

    public function create()
    {
        $polyclinic = new Polyclinic(['is_active' => true, 'sort_order' => 0, 'color' => '#3FD183']);

        return view('admin.polyclinics.form', compact('polyclinic'));
    }

    public function store(Request $request)
    {
        $validated = $this->validatePolyclinic($request);
        $validated['slug'] = $this->uniqueSlug($validated['name']);
        Polyclinic::create($validated);

        return redirect()->route('admin.polyclinics.index')->with('success', 'Poli berhasil ditambahkan.');
    }

    public function edit(Polyclinic $polyclinic)
    {
        return view('admin.polyclinics.form', compact('polyclinic'));
    }

    public function update(Request $request, Polyclinic $polyclinic)
    {
        $validated = $this->validatePolyclinic($request);
        $validated['slug'] = $this->uniqueSlug($validated['name'], $polyclinic->id);
        $polyclinic->update($validated);

        return redirect()->route('admin.polyclinics.index')->with('success', 'Data poli berhasil diperbarui.');
    }

    public function toggle(Polyclinic $polyclinic)
    {
        $polyclinic->update(['is_active' => !$polyclinic->is_active]);

        return back()->with('success', 'Status poli berhasil diperbarui.');
    }

    private function validatePolyclinic(Request $request): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:120', Rule::unique('polyclinics', 'name')->ignore($request->route('polyclinic')?->id)],
            'short_description' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:3000'],
            'icon' => ['nullable', 'string', 'max:60'],
            'color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'is_active' => ['nullable', 'boolean'],
        ]);
    }

    private function uniqueSlug(string $name, ?int $ignoreId = null): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $suffix = 2;
        while (Polyclinic::where('slug', $slug)->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))->exists()) {
            $slug = $base.'-'.$suffix++;
        }

        return $slug;
    }
}
