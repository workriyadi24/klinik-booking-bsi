<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use App\Models\Polyclinic;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class DoctorController extends Controller
{
    public function index(Request $request)
    {
        $doctors = Doctor::with('polyclinic')
            ->when($request->filled('q'), fn ($q) => $q->where(fn ($sub) => $sub->where('name', 'like', '%'.$request->q.'%')->orWhere('speciality', 'like', '%'.$request->q.'%')))
            ->when($request->filled('status'), fn ($q) => $q->where('is_active', $request->status === 'active'))
            ->orderBy('name')->paginate(15)->withQueryString();

        return view('admin.doctors.index', compact('doctors'));
    }

    public function create()
    {
        $doctor = new Doctor(['is_active' => true, 'experience_years' => 0, 'rating' => 5]);
        $polyclinics = Polyclinic::where(fn ($query) => $query->where('is_active', true)->orWhere('id', $doctor->polyclinic_id))->orderBy('name')->get();
        $account = null;

        return view('admin.doctors.form', compact('doctor', 'polyclinics', 'account'));
    }

    public function store(Request $request)
    {
        $validated = $this->validateDoctor($request);
        $validated['slug'] = $this->makeSlug($validated['name']);
        if ($request->hasFile('photo')) {
            $validated['photo_path'] = $request->file('photo')->store('doctors', 'public');
        }
        unset($validated['photo']);

        $accountEmail = $validated['account_email'];
        $accountPassword = $validated['account_password'];
        unset($validated['account_email'], $validated['account_password']);
        $doctor = DB::transaction(function () use ($validated, $accountEmail, $accountPassword) {
            $doctor = Doctor::create($validated);
            User::create([
                'name' => $doctor->name, 'email' => $accountEmail, 'password' => $accountPassword,
                'role' => 'doctor', 'doctor_id' => $doctor->id, 'is_admin' => false, 'is_active' => (bool) $doctor->is_active,
            ]);

            return $doctor;
        });

        return redirect()->route('admin.doctors.schedules.index', $doctor)->with('success', 'Dokter berhasil ditambahkan. Silakan lengkapi jadwal praktiknya.');
    }

    public function edit(Doctor $doctor)
    {
        $polyclinics = Polyclinic::where(fn ($query) => $query->where('is_active', true)->orWhere('id', $doctor->polyclinic_id))->orderBy('name')->get();

        $account = User::where('doctor_id', $doctor->id)->first();

        return view('admin.doctors.form', compact('doctor', 'polyclinics', 'account'));
    }

    public function update(Request $request, Doctor $doctor)
    {
        $validated = $this->validateDoctor($request);
        $validated['slug'] = $this->makeSlug($validated['name'], $doctor->id);
        if ($request->hasFile('photo')) {
            if ($doctor->photo_path) {
                Storage::disk('public')->delete($doctor->photo_path);
            }
            $validated['photo_path'] = $request->file('photo')->store('doctors', 'public');
        }
        unset($validated['photo']);

        $accountEmail = $validated['account_email'];
        $accountPassword = $validated['account_password'] ?? null;
        unset($validated['account_email'], $validated['account_password']);
        DB::transaction(function () use ($doctor, $validated, $accountEmail, $accountPassword) {
            $doctor->update($validated);
            $account = User::firstOrNew(['doctor_id' => $doctor->id]);
            $account->name = $doctor->name;
            $account->email = $accountEmail;
            $account->role = 'doctor';
            $account->is_admin = false;
            $account->is_active = (bool) $doctor->is_active;
            if ($accountPassword) { $account->password = $accountPassword; }
            $account->save();
        });

        return redirect()->route('admin.doctors.index')->with('success', 'Data dokter berhasil diperbarui.');
    }

    public function toggle(Doctor $doctor)
    {
        $doctor->update(['is_active' => !$doctor->is_active]);
        User::where('doctor_id', $doctor->id)->update(['is_active' => $doctor->is_active]);

        return back()->with('success', 'Status dokter berhasil diperbarui.');
    }

    private function validateDoctor(Request $request): array
    {
        $routeDoctor = $request->route('doctor');
        $doctorId = $routeDoctor instanceof Doctor ? $routeDoctor->id : null;
        $accountExists = $doctorId ? User::where('doctor_id', $doctorId)->exists() : false;
        $passwordRequired = $request->isMethod('post') || !$accountExists;

        return $request->validate([
            'polyclinic_id' => ['required', 'exists:polyclinics,id'],
            'name' => ['required', 'string', 'max:160'],
            'title' => ['nullable', 'string', 'max:100'],
            'speciality' => ['required', 'string', 'max:120'],
            'experience_years' => ['required', 'integer', 'min:0', 'max:60'],
            'rating' => ['required', 'numeric', 'min:0', 'max:5'],
            'rating_count' => ['nullable', 'integer', 'min:0'],
            'practice_location' => ['required', 'string', 'max:160'],
            'bio' => ['nullable', 'string', 'max:5000'],
            'is_active' => ['nullable', 'boolean'],
            'photo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:3072'],
            'account_email' => ['required', 'email', 'max:160', Rule::unique('users', 'email')->ignore($request->route('doctor')?->id, 'doctor_id')],
            'account_password' => [$passwordRequired ? 'required' : 'nullable', 'string', 'min:8', 'max:100'],
        ]);
    }

    private function makeSlug(string $name, ?int $ignoreId = null): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $suffix = 2;
        while (Doctor::where('slug', $slug)->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))->exists()) {
            $slug = $base.'-'.$suffix++;
        }

        return $slug;
    }
}
