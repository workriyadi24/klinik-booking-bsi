<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use App\Models\DoctorSchedule;
use App\Models\DoctorScheduleException;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class ScheduleController extends Controller
{
    public function index(Doctor $doctor)
    {
        $doctor->load(['polyclinic', 'schedules']);
        $exceptions = $doctor->exceptions()->whereDate('exception_date', '>=', now()->toDateString())->orderBy('exception_date')->limit(20)->get();

        return view('admin.schedules.index', compact('doctor', 'exceptions'));
    }

    public function store(Request $request, Doctor $doctor)
    {
        $validated = $request->validate([
            'day_of_week' => ['required', 'integer', 'between:0,6'],
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i'],
            'slot_duration_minutes' => ['required', 'integer', 'in:15,30,45,60,90,120'],
            'valid_from' => ['nullable', 'date'],
            'valid_until' => ['nullable', 'date', 'after_or_equal:valid_from'],
        ]);

        if ($validated['start_time'] >= $validated['end_time']) {
            throw ValidationException::withMessages(['end_time' => 'Jam selesai harus lebih besar dari jam mulai.']);
        }

        $overlap = $doctor->schedules()
            ->where('day_of_week', $validated['day_of_week'])
            ->where('is_active', true)
            ->where('start_time', '<', $validated['end_time'])
            ->where('end_time', '>', $validated['start_time'])
            ->exists();
        if ($overlap) {
            throw ValidationException::withMessages(['start_time' => 'Rentang jam bertabrakan dengan jadwal aktif lain pada hari yang sama.']);
        }

        $validated['doctor_id'] = $doctor->id;
        $validated['is_active'] = true;
        $doctor->schedules()->create($validated);

        return back()->with('success', 'Jadwal praktik berhasil ditambahkan.');
    }

    public function update(Request $request, Doctor $doctor, DoctorSchedule $schedule)
    {
        abort_unless($schedule->doctor_id === $doctor->id, 404);
        $validated = $request->validate([
            'day_of_week' => ['required', 'integer', 'between:0,6'],
            'start_time' => ['required', 'date_format:H:i'],
            'end_time' => ['required', 'date_format:H:i'],
            'slot_duration_minutes' => ['required', 'integer', 'in:15,30,45,60,90,120'],
            'valid_from' => ['nullable', 'date'],
            'valid_until' => ['nullable', 'date', 'after_or_equal:valid_from'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        if ($validated['start_time'] >= $validated['end_time']) {
            throw ValidationException::withMessages(['end_time' => 'Jam selesai harus lebih besar dari jam mulai.']);
        }

        if (($validated['is_active'] ?? false) || $schedule->is_active) {
            $overlap = $doctor->schedules()
                ->where('id', '!=', $schedule->id)
                ->where('day_of_week', $validated['day_of_week'])
                ->where('is_active', true)
                ->where('start_time', '<', $validated['end_time'])
                ->where('end_time', '>', $validated['start_time'])
                ->exists();
            if ($overlap && ($validated['is_active'] ?? false)) {
                throw ValidationException::withMessages(['start_time' => 'Rentang jam bertabrakan dengan jadwal aktif lain pada hari yang sama.']);
            }
        }

        $schedule->update($validated);

        return back()->with('success', 'Jadwal praktik berhasil diperbarui.');
    }

    public function destroy(Doctor $doctor, DoctorSchedule $schedule)
    {
        abort_unless($schedule->doctor_id === $doctor->id, 404);
        $schedule->delete();

        return back()->with('success', 'Jadwal praktik berhasil dihapus.');
    }

    public function saveException(Request $request, Doctor $doctor)
    {
        $validated = $request->validate([
            'exception_date' => ['required', 'date', 'after_or_equal:today'],
            'is_closed' => ['nullable', 'boolean'],
            'start_time' => ['nullable', 'date_format:H:i'],
            'end_time' => ['nullable', 'date_format:H:i'],
            'note' => ['nullable', 'string', 'max:255'],
        ]);

        $isClosed = $request->boolean('is_closed');
        if (!$isClosed && (!$validated['start_time'] || !$validated['end_time'] || $validated['start_time'] >= $validated['end_time'])) {
            throw ValidationException::withMessages(['start_time' => 'Untuk jam khusus, isi jam mulai dan jam selesai yang valid.']);
        }

        DoctorScheduleException::updateOrCreate(
            ['doctor_id' => $doctor->id, 'exception_date' => $validated['exception_date']],
            [
                'is_closed' => $isClosed,
                'start_time' => $isClosed ? null : $validated['start_time'],
                'end_time' => $isClosed ? null : $validated['end_time'],
                'note' => $validated['note'] ?? null,
            ]
        );

        return back()->with('success', 'Pengecualian jadwal berhasil disimpan.');
    }

    public function deleteException(Doctor $doctor, DoctorScheduleException $exception)
    {
        abort_unless($exception->doctor_id === $doctor->id, 404);
        $exception->delete();

        return back()->with('success', 'Pengecualian jadwal dihapus. Jadwal reguler kembali berlaku.');
    }
}
