<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Doctor;
use App\Services\AppointmentBookingService;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class AppointmentController extends Controller
{
    public function __construct(private readonly AppointmentBookingService $bookingService)
    {
    }

    public function index(Request $request)
    {
        $appointments = Appointment::with(['patient', 'doctor', 'polyclinic'])
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->status))
            ->when($request->filled('date'), fn ($query) => $query->whereDate('appointment_date', $request->date))
            ->when($request->filled('q'), function ($query) use ($request) {
                $term = trim($request->q);
                $query->where(function ($sub) use ($term) {
                    $sub->where('booking_code', 'like', '%'.$term.'%')
                        ->orWhereHas('patient', fn ($patient) => $patient->where('full_name', 'like', '%'.$term.'%')->orWhere('phone', 'like', '%'.$term.'%'))
                        ->orWhereHas('doctor', fn ($doctor) => $doctor->where('name', 'like', '%'.$term.'%'));
                });
            })
            ->orderByDesc('appointment_date')->orderBy('start_time')->paginate(15)->withQueryString();

        return view('admin.appointments.index', compact('appointments'));
    }

    public function show(Appointment $appointment)
    {
        $appointment->load(['patient', 'doctor.polyclinic', 'polyclinic', 'creator', 'medicalRecord']);

        return view('admin.appointments.show', compact('appointment'));
    }

    public function edit(Appointment $appointment)
    {
        $appointment->load(['patient', 'doctor', 'polyclinic']);
        $doctors = Doctor::with('polyclinic')->where(fn ($query) => $query->where('is_active', true)->orWhere('id', $appointment->doctor_id))->orderBy('name')->get();

        return view('admin.appointments.edit', compact('appointment', 'doctors'));
    }

    public function slots(Request $request, Doctor $doctor)
    {
        $validated = $request->validate([
            'date' => ['required', 'date_format:Y-m-d'],
            'except' => ['nullable', 'integer'],
        ]);

        return response()->json([
            'slots' => $this->bookingService->availableSlots($doctor, $validated['date'], $validated['except'] ?? null),
        ]);
    }

    public function update(Request $request, Appointment $appointment)
    {
        $validated = $request->validate([
            'doctor_id' => ['required', 'integer', Rule::exists('doctors', 'id')],
            'appointment_date' => ['required', 'date_format:Y-m-d'],
            'start_time' => ['required', 'date_format:H:i'],
            'status' => ['required', Rule::in(Appointment::STATUSES)],
            'full_name' => ['required', 'string', 'min:3', 'max:160'],
            'birth_place' => ['required', 'string', 'max:100'],
            'birth_date' => ['required', 'date', 'before:today'],
            'gender' => ['required', 'in:Laki-laki,Perempuan'],
            'address' => ['required', 'string', 'max:2000'],
            'religion' => ['nullable', 'string', 'max:40'],
            'family_card_number' => ['nullable', 'digits:16'],
            'marital_status' => ['nullable', 'in:Belum Menikah,Menikah,Cerai Hidup,Cerai Mati'],
            'education' => ['nullable', 'in:SD,SMP,SMA/SMK,Diploma,S1,S2,S3,Lainnya'],
            'phone' => ['required', 'string', 'min:9', 'max:24', 'regex:/^(\+?62|0)[0-9]{8,16}$/'],
            'email' => ['nullable', 'email', 'max:160'],
            'complaint' => ['nullable', 'string', 'max:2000'],
            'admin_notes' => ['nullable', 'string', 'max:3000'],
        ]);

        if ($appointment->medicalRecord()->exists()) {
            $clinicalLinkChanged = (int) $validated['doctor_id'] !== (int) $appointment->doctor_id
                || $validated['appointment_date'] !== $appointment->appointment_date->toDateString()
                || $validated['start_time'] !== substr((string) $appointment->start_time, 0, 5)
                || $validated['status'] !== $appointment->status;
            if ($clinicalLinkChanged) {
                throw ValidationException::withMessages(['status' => 'Booking sudah memiliki rekam medis. Dokter, tanggal, jam, dan status kunjungan dikunci untuk menjaga keterkaitan catatan klinis.']);
            }
        }

        $appointmentMoment = \Carbon\Carbon::parse($validated['appointment_date'].' '.$validated['start_time'], 'Asia/Jakarta');
        $sameExistingSlot = (int) $validated['doctor_id'] === (int) $appointment->doctor_id
            && $validated['appointment_date'] === $appointment->appointment_date->toDateString()
            && $validated['start_time'] === substr((string) $appointment->start_time, 0, 5);
        if ($appointmentMoment->isPast() && !$sameExistingSlot) {
            throw ValidationException::withMessages(['appointment_date' => 'Jadwal baru harus berada pada hari ini atau tanggal mendatang.']);
        }
        if ($appointment->status === 'no_show' && $sameExistingSlot && $validated['status'] !== 'no_show') {
            throw ValidationException::withMessages(['status' => 'Booking tidak hadir hanya dapat diaktifkan kembali melalui reschedule ke tanggal/jam baru.']);
        }
        if ($validated['status'] === 'no_show' && $appointmentMoment->isFuture()) {
            throw ValidationException::withMessages(['status' => 'Pasien hanya dapat ditandai tidak hadir setelah jam janji terlewati.']);
        }
        if ($validated['status'] === 'completed' && $appointmentMoment->isFuture()) {
            throw ValidationException::withMessages(['status' => 'Janji yang belum berlangsung tidak dapat ditandai selesai.']);
        }

        $doctor = Doctor::with('polyclinic')->findOrFail($validated['doctor_id']);
        $sameExistingSlot = (int) $doctor->id === (int) $appointment->doctor_id
            && $validated['appointment_date'] === $appointment->appointment_date->toDateString()
            && $validated['start_time'] === substr((string) $appointment->start_time, 0, 5);
        $doctorCanReceiveBooking = $doctor->is_active && $doctor->polyclinic?->is_active;
        if (!$doctorCanReceiveBooking && !$sameExistingSlot) {
            throw ValidationException::withMessages(['doctor_id' => 'Dokter atau poliklinik sudah nonaktif. Pilih dokter aktif untuk reschedule.']);
        }

        $this->bookingService->updateAppointment($appointment, $validated, $doctor);

        return redirect()->route('admin.appointments.show', $appointment)->with('success', 'Data booking berhasil diperbarui.');
    }

    public function markNoShow(Request $request, Appointment $appointment)
    {
        $request->validate(['admin_notes' => ['nullable', 'string', 'max:3000']]);
        $appointmentMoment = \Carbon\Carbon::parse($appointment->appointment_date->toDateString().' '.substr((string) $appointment->start_time, 0, 5), 'Asia/Jakarta');

        if ($appointmentMoment->isFuture()) {
            throw ValidationException::withMessages(['status' => 'Pasien belum dapat ditandai tidak hadir karena jadwal belum terlewati.']);
        }
        if (in_array($appointment->status, ['cancelled', 'completed'], true)) {
            throw ValidationException::withMessages(['status' => 'Status booking ini tidak dapat diubah menjadi tidak hadir.']);
        }
        if ($appointment->medicalRecord()->exists()) {
            throw ValidationException::withMessages(['status' => 'Booking yang sudah memiliki draf atau rekam medis tidak dapat ditandai tidak hadir.']);
        }

        $appointment->update([
            'status' => 'no_show',
            'no_show_at' => now(),
            'admin_notes' => $request->input('admin_notes', $appointment->admin_notes),
        ]);

        return redirect()->route('admin.appointments.show', $appointment)->with('success', 'Pasien ditandai tidak hadir. Booking tetap tersimpan dan dapat diedit/reschedule.');
    }
}
