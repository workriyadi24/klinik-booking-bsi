<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\Polyclinic;

class PublicPageController extends Controller
{
    public function information()
    {
        $polyclinics = Polyclinic::where('is_active', true)->orderBy('sort_order')->get();
        $doctors = Doctor::with(['polyclinic', 'schedules'])->where('is_active', true)->whereHas('polyclinic', fn ($query) => $query->where('is_active', true))->orderBy('name')->get();

        return view('public.information', compact('polyclinics', 'doctors'));
    }

    public function contact()
    {
        return view('public.contact');
    }
}
