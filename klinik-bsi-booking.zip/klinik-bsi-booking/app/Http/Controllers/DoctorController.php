<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\Polyclinic;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    public function index(Request $request)
    {
        $polyclinics = Polyclinic::where('is_active', true)->orderBy('name')->get();
        $doctors = Doctor::with(['polyclinic', 'schedules'])
            ->where('is_active', true)
            ->whereHas('polyclinic', fn ($query) => $query->where('is_active', true))
            ->when($request->filled('polyclinic'), fn ($q) => $q->where('polyclinic_id', $request->integer('polyclinic')))
            ->when($request->filled('q'), fn ($q) => $q->where(fn ($sub) => $sub->where('name', 'like', '%'.$request->q.'%')->orWhere('speciality', 'like', '%'.$request->q.'%')))
            ->orderBy('name')->paginate(9)->withQueryString();

        return view('public.doctors', compact('doctors', 'polyclinics'));
    }

    public function show(Doctor $doctor)
    {
        abort_unless($doctor->is_active && $doctor->polyclinic()->where('is_active', true)->exists(), 404);
        $doctor->load(['polyclinic', 'schedules']);

        return view('public.doctor-detail', compact('doctor'));
    }
}
