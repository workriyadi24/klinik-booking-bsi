<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PatientPortalController extends Controller
{
    public function dashboard(Request $request)
    {
        $patient = $request->user()->patient;
        if (!$patient) {
            return redirect()->route('patient.profile.create');
        }

        $appointments = $patient->appointments()
            ->with(['doctor.polyclinic', 'polyclinic', 'medicalRecord'])
            ->orderByDesc('appointment_date')->orderByDesc('start_time')
            ->paginate(8);
        $medicalRecords = $patient->medicalRecords()->where('status', 'finalized')
            ->with(['doctor', 'polyclinic'])
            ->orderByDesc('encounter_date')->orderByDesc('id')->limit(5)->get();
        $stats = [
            'upcoming' => $patient->appointments()->whereIn('status', ['pending', 'confirmed'])->whereDate('appointment_date', '>=', now('Asia/Jakarta')->toDateString())->count(),
            'completed' => $patient->appointments()->where('status', 'completed')->count(),
            'total' => $patient->appointments()->count(),
        ];

        return view('patient.dashboard', compact('patient', 'appointments', 'stats', 'medicalRecords'));
    }

    public function cancel(Request $request, Appointment $appointment)
    {
        $patient = $request->user()->patient;
        abort_unless($patient && (int) $appointment->patient_id === (int) $patient->id, 404);

        DB::transaction(function () use ($appointment) {
            $locked = Appointment::whereKey($appointment->id)->lockForUpdate()->firstOrFail();
            abort_unless($locked->status === 'pending', 422, 'Hanya janji temu yang masih menunggu yang dapat dibatalkan melalui portal pasien.');
            abort_unless(!$locked->medicalRecord()->exists(), 422, 'Janji temu sudah memiliki draf rekam medis. Hubungi klinik untuk bantuan lebih lanjut.');
            $appointmentMoment = Carbon::parse($locked->appointment_date->toDateString().' '.substr((string) $locked->start_time, 0, 5), 'Asia/Jakarta');
            abort_unless($appointmentMoment->isFuture(), 422, 'Jadwal yang sudah dimulai atau lewat tidak dapat dibatalkan.');
            $locked->update(['status' => 'cancelled', 'cancelled_at' => now()]);
        });

        return back()->with('success', 'Janji temu berhasil dibatalkan.');
    }
}
