<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Services\AppointmentBookingService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class AppointmentController extends Controller
{
    public function __construct(private readonly AppointmentBookingService $bookingService)
    {
    }

    public function create(Doctor $doctor)
    {
        abort_unless($doctor->is_active && $doctor->polyclinic()->where('is_active', true)->exists(), 404);
        $doctor->load('polyclinic');
        $minimumDate = now('Asia/Jakarta')->toDateString();
        $maximumDate = now('Asia/Jakarta')->addDays(60)->toDateString();

        return view('public.appointment-create', compact('doctor', 'minimumDate', 'maximumDate'));
    }

    public function slots(Request $request, Doctor $doctor)
    {
        abort_unless($doctor->is_active && $doctor->polyclinic()->where('is_active', true)->exists(), 404);
        $validated = $request->validate([
            'date' => ['required', 'date_format:Y-m-d', 'after_or_equal:'.now('Asia/Jakarta')->toDateString(), 'before_or_equal:'.now('Asia/Jakarta')->addDays(60)->toDateString()],
        ]);

        $slots = $this->bookingService->availableSlots($doctor, $validated['date']);

        return response()->json([
            'date' => $validated['date'],
            'has_schedule' => count($slots) > 0,
            'has_available_slot' => collect($slots)->contains(fn ($slot) => $slot['available']),
            'slots' => $slots,
        ]);
    }

    public function register(Request $request, Doctor $doctor)
    {
        abort_unless($doctor->is_active && $doctor->polyclinic()->where('is_active', true)->exists(), 404);
        $validated = $request->validate([
            'date' => ['required', 'date_format:Y-m-d', 'after_or_equal:'.now('Asia/Jakarta')->toDateString(), 'before_or_equal:'.now('Asia/Jakarta')->addDays(60)->toDateString()],
            'time' => ['required', 'date_format:H:i'],
        ]);

        try {
            $slot = $this->bookingService->findAvailableSlot($doctor, $validated['date'], $validated['time']);
        } catch (ValidationException $exception) {
            return redirect()->route('appointments.create', $doctor)->withErrors($exception->errors())->withInput();
        }

        if (!Auth::check()) {
            $this->storeBookingIntent($request, $doctor, $validated['date'], $slot['time']);

            return redirect()->route('patient.login')->with('info', 'Silakan login atau buat akun terlebih dahulu untuk melanjutkan booking.');
        }

        abort_unless(Auth::user()->isPatient(), 403, 'Gunakan akun pasien untuk membuat janji temu.');
        $patient = Patient::where('user_id', Auth::id())->first();
        if (!$patient) {
            $this->storeBookingIntent($request, $doctor, $validated['date'], $slot['time']);

            return redirect()->route('patient.profile.create')->with('info', 'Lengkapi profil pasien satu kali sebelum membuat janji temu.');
        }

        $doctor->load('polyclinic');

        return view('public.patient-register', [
            'doctor' => $doctor,
            'patient' => $patient,
            'date' => $validated['date'],
            'time' => $slot['time'],
            'endTime' => $slot['end_time'],
        ]);
    }

    public function store(Request $request, Doctor $doctor)
    {
        abort_unless($doctor->is_active && $doctor->polyclinic()->where('is_active', true)->exists(), 404);
        if (!Auth::check()) {
            $date = (string) $request->input('appointment_date', '');
            $time = (string) $request->input('start_time', '');
            if (preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $date) && preg_match('/^\\d{2}:\\d{2}$/', $time)) {
                $this->storeBookingIntent($request, $doctor, $date, $time);
            }
            return redirect()->route('patient.login')->with('info', 'Login terlebih dahulu untuk mengirim janji temu.');
        }
        abort_unless(Auth::user()->isPatient(), 403, 'Silakan gunakan akun pasien untuk membuat janji temu.');

        $validated = $request->validate([
            'appointment_date' => ['required', 'date_format:Y-m-d', 'after_or_equal:'.now('Asia/Jakarta')->toDateString(), 'before_or_equal:'.now('Asia/Jakarta')->addDays(60)->toDateString()],
            'start_time' => ['required', 'date_format:H:i'],
            'complaint' => ['required', 'string', 'min:5', 'max:2000'],
            'symptoms' => ['nullable', 'string', 'max:3000'],
            'symptom_duration' => ['nullable', 'string', 'max:120'],
            'privacy_accepted' => ['accepted'],
        ], [
            'complaint.required' => 'Ceritakan keluhan atau tujuan pemeriksaan Anda.',
            'privacy_accepted.accepted' => 'Persetujuan penggunaan data wajib dicentang.',
        ]);

        $patient = Patient::where('user_id', Auth::id())->first();
        if (!$patient) {
            $this->storeBookingIntent($request, $doctor, $validated['appointment_date'], $validated['start_time']);
            return redirect()->route('patient.profile.create')->with('info', 'Lengkapi profil pasien sebelum mengirim janji temu.');
        }
        $appointment = $this->bookingService->createBookingForPatient($validated, $doctor, $patient);
        $request->session()->forget('booking_intent');
        $request->session()->put('booking_access_'.$appointment->booking_code, true);

        return redirect()->route('booking.show', $appointment->booking_code)
            ->with('success', 'Pendaftaran berhasil dikirim. Simpan kode booking Anda.');
    }

    public function showBooking(Request $request, Appointment $appointment)
    {
        $samePatient = $request->user()?->isPatient()
            && (int) $request->user()->patient?->id === (int) $appointment->patient_id;
        if (!$samePatient && !$request->session()->get('booking_access_'.$appointment->booking_code)) {
            return redirect()->route('booking.lookup')->with('warning', 'Masukkan kode booking dan nomor telepon untuk melihat detail janji temu.');
        }

        $appointment->load(['patient', 'doctor.polyclinic', 'polyclinic']);

        return view('public.booking-success', compact('appointment'));
    }

    private function storeBookingIntent(Request $request, Doctor $doctor, string $date, string $time): void
    {
        $request->session()->put('booking_intent', [
            'doctor_id' => $doctor->id,
            'doctor_slug' => $doctor->slug,
            'date' => $date,
            'time' => $time,
            'created_at' => now()->timestamp,
        ]);
    }
}
