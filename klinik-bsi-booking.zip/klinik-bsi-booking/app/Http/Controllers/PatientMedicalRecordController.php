<?php

namespace App\Http\Controllers;

use App\Models\MedicalRecord;
use Illuminate\Http\Request;

class PatientMedicalRecordController extends Controller
{
    public function index(Request $request)
    {
        $patient = $request->user()->patient;
        if (!$patient) {
            return redirect()->route('patient.profile.create')->with('warning', 'Lengkapi profil pasien terlebih dahulu untuk membuka rekam medis.');
        }

        $records = $patient->medicalRecords()
            ->where('status', 'finalized')
            ->with(['doctor', 'polyclinic', 'prescription.items'])
            ->orderByDesc('encounter_date')->orderByDesc('id')->paginate(12);

        return view('patient.medical-records.index', compact('patient', 'records'));
    }

    public function show(Request $request, MedicalRecord $medicalRecord)
    {
        $patient = $request->user()->patient;
        abort_unless($patient && (int) $medicalRecord->patient_id === (int) $patient->id && $medicalRecord->isFinalized(), 404);
        $medicalRecord->load(['appointment', 'doctor.polyclinic', 'polyclinic', 'prescription.items', 'addenda.creator']);
        $medicalRecord->logActivity($request->user(), 'viewed_by_patient', [], $request->ip(), $request->userAgent());

        return view('patient.medical-records.show', compact('medicalRecord'));
    }
}
