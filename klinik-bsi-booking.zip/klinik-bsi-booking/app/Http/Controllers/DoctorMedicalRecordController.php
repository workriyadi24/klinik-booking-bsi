<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\MedicalRecord;
use App\Models\Patient;
use App\Models\Prescription;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class DoctorMedicalRecordController extends Controller
{
    public function index(Request $request)
    {
        $doctor = $request->user()->doctor()->firstOrFail();
        $records = $doctor->medicalRecords()
            ->with(['patient', 'polyclinic', 'appointment'])
            ->when($request->filled('status'), fn (Builder $query) => $query->where('status', $request->string('status')->toString()))
            ->when($request->filled('q'), function (Builder $query) use ($request) {
                $term = trim($request->string('q')->toString());
                $query->where(function (Builder $sub) use ($term) {
                    $sub->where('record_number', 'like', "%{$term}%")
                        ->orWhereHas('patient', fn (Builder $patient) => $patient->where('full_name', 'like', "%{$term}%")->orWhere('medical_record_number', 'like', "%{$term}%"))
                        ->orWhereHas('appointment', fn (Builder $appointment) => $appointment->where('booking_code', 'like', "%{$term}%"));
                });
            })
            ->orderByDesc('encounter_date')->orderByDesc('id')->paginate(15)->withQueryString();

        return view('doctor-portal.medical-records.index', compact('doctor', 'records'));
    }

    public function create(Request $request, Appointment $appointment)
    {
        $this->ensureOwnAppointment($request, $appointment);
        $this->ensureCanDocument($appointment);

        if ($appointment->medicalRecord) {
            return $appointment->medicalRecord->isFinalized()
                ? redirect()->route('doctor-portal.medical-records.show', $appointment->medicalRecord)
                : redirect()->route('doctor-portal.medical-records.edit', $appointment->medicalRecord);
        }

        $medicalRecord = new MedicalRecord([
            'encounter_date' => $appointment->appointment_date,
            'encounter_time' => $appointment->start_time,
            'subjective' => trim(implode("\n\n", array_filter([
                $appointment->complaint ? 'Keluhan utama: '.$appointment->complaint : null,
                $appointment->symptoms ? 'Gejala: '.$appointment->symptoms : null,
                $appointment->symptom_duration ? 'Durasi gejala: '.$appointment->symptom_duration : null,
            ]))),
        ]);
        $medicalRecord->setRelation('prescription', new Prescription(['instructions' => null]));
        $patientHistory = $this->loadPatientHistory($request, $appointment->patient()->firstOrFail(), null);

        return view('doctor-portal.medical-records.form', compact('appointment', 'medicalRecord', 'patientHistory'));
    }

    public function store(Request $request, Appointment $appointment)
    {
        $this->ensureOwnAppointment($request, $appointment);
        $this->ensureCanDocument($appointment);

        $data = $this->validatedData($request);
        $record = DB::transaction(function () use ($request, $appointment, $data) {
            $lockedAppointment = Appointment::whereKey($appointment->id)->lockForUpdate()->firstOrFail();
            $this->ensureCanDocument($lockedAppointment);
            $existing = MedicalRecord::where('appointment_id', $lockedAppointment->id)->lockForUpdate()->first();
            if ($existing) {
                throw ValidationException::withMessages(['record' => 'Rekam medis untuk janji temu ini sudah dibuat. Silakan buka catatan yang tersedia.']);
            }

            $patient = $lockedAppointment->patient()->firstOrFail();
            $record = MedicalRecord::create($this->recordAttributes($data) + [
                'record_number' => $this->newRecordNumber($lockedAppointment),
                'appointment_id' => $lockedAppointment->id,
                'patient_id' => $lockedAppointment->patient_id,
                'doctor_id' => $lockedAppointment->doctor_id,
                'polyclinic_id' => $lockedAppointment->polyclinic_id,
                'patient_allergies_snapshot' => $patient->allergies,
                'patient_medical_history_snapshot' => $patient->medical_history,
                'patient_current_medications_snapshot' => $patient->current_medications,
                'encounter_date' => $lockedAppointment->appointment_date,
                'encounter_time' => $lockedAppointment->start_time,
                'status' => 'draft',
                'created_by' => $request->user()->id,
            ]);

            $this->syncPrescription($record, $data);
            $record->logActivity($request->user(), 'created', ['source' => 'appointment'], $request->ip(), $request->userAgent());
            $this->finalizeWhenRequested($record, $lockedAppointment, $data, $request);

            return $record;
        });

        if ($record->isFinalized()) {
            return redirect()->route('doctor-portal.medical-records.show', $record)->with('success', 'Rekam medis berhasil disimpan dan disahkan.');
        }

        return redirect()->route('doctor-portal.medical-records.edit', $record)->with('success', 'Draf rekam medis berhasil disimpan.');
    }

    public function show(Request $request, MedicalRecord $medicalRecord)
    {
        $this->ensureOwnRecord($request, $medicalRecord);
        $medicalRecord->load(['appointment', 'patient', 'doctor.polyclinic', 'polyclinic', 'prescription.items', 'addenda.creator', 'finalizer']);
        $medicalRecord->logActivity($request->user(), 'viewed_by_doctor', [], $request->ip(), $request->userAgent());
        $previousRecords = $this->loadPatientHistory($request, $medicalRecord->patient, $medicalRecord->id);

        return view('doctor-portal.medical-records.show', compact('medicalRecord', 'previousRecords'));
    }

    public function edit(Request $request, MedicalRecord $medicalRecord)
    {
        $this->ensureOwnRecord($request, $medicalRecord);
        if ($medicalRecord->isFinalized()) {
            return redirect()->route('doctor-portal.medical-records.show', $medicalRecord);
        }
        $medicalRecord->load(['appointment.patient', 'prescription.items']);
        $appointment = $medicalRecord->appointment;
        $patientHistory = $this->loadPatientHistory($request, $medicalRecord->patient, $medicalRecord->id);

        return view('doctor-portal.medical-records.form', compact('appointment', 'medicalRecord', 'patientHistory'));
    }

    public function update(Request $request, MedicalRecord $medicalRecord)
    {
        $this->ensureOwnRecord($request, $medicalRecord);
        abort_if($medicalRecord->isFinalized(), 422, 'Rekam medis yang sudah disahkan tidak dapat diedit. Gunakan addendum untuk koreksi atau informasi tambahan.');
        $data = $this->validatedData($request);

        DB::transaction(function () use ($request, $medicalRecord, $data) {
            $record = MedicalRecord::whereKey($medicalRecord->id)->lockForUpdate()->firstOrFail();
            abort_if($record->isFinalized(), 422, 'Rekam medis sudah disahkan dan tidak dapat diedit.');
            $appointment = Appointment::whereKey($record->appointment_id)->lockForUpdate()->firstOrFail();
            $record->fill($this->recordAttributes($data))->save();
            $this->syncPrescription($record, $data);
            $record->logActivity($request->user(), 'draft_updated', [
                'updated_sections' => array_keys($this->recordAttributes($data)),
                'prescription_item_count' => $this->prescriptionItemCount($data),
            ], $request->ip(), $request->userAgent());
            $this->finalizeWhenRequested($record, $appointment, $data, $request);
        });

        $medicalRecord->refresh();
        if ($medicalRecord->isFinalized()) {
            return redirect()->route('doctor-portal.medical-records.show', $medicalRecord)->with('success', 'Rekam medis berhasil disahkan. Catatan final kini terkunci dan hanya dapat ditambah melalui addendum.');
        }

        return redirect()->route('doctor-portal.medical-records.edit', $medicalRecord)->with('success', 'Perubahan draf rekam medis berhasil disimpan.');
    }

    public function addendum(Request $request, MedicalRecord $medicalRecord)
    {
        $this->ensureOwnRecord($request, $medicalRecord);
        abort_unless($medicalRecord->isFinalized(), 422, 'Addendum hanya dapat ditambahkan setelah rekam medis disahkan.');
        $data = $request->validate([
            'content' => ['required', 'string', 'min:5', 'max:10000'],
        ], [
            'content.required' => 'Isi addendum wajib diisi.',
            'content.min' => 'Addendum terlalu singkat. Jelaskan koreksi atau informasi tambahannya.',
        ]);

        DB::transaction(function () use ($request, $medicalRecord, $data) {
            $record = MedicalRecord::whereKey($medicalRecord->id)->lockForUpdate()->firstOrFail();
            abort_unless($record->isFinalized(), 422, 'Status rekam medis berubah. Muat ulang halaman.');
            $record->addenda()->create([
                'doctor_id' => $record->doctor_id,
                'created_by' => $request->user()->id,
                'content' => $data['content'],
            ]);
            $record->logActivity($request->user(), 'addendum_added', [], $request->ip(), $request->userAgent());
        });

        return back()->with('success', 'Addendum berhasil ditambahkan tanpa mengubah catatan rekam medis final.');
    }

    private function validatedData(Request $request): array
    {
        return $request->validate([
            'action' => ['required', 'in:draft,finalize'],
            'subjective' => ['nullable', 'string', 'max:20000'],
            'objective' => ['nullable', 'string', 'max:20000'],
            'blood_pressure' => ['nullable', 'string', 'max:24'],
            'temperature_celsius' => ['nullable', 'numeric', 'between:25,45'],
            'heart_rate_bpm' => ['nullable', 'integer', 'between:20,250'],
            'respiratory_rate_per_minute' => ['nullable', 'integer', 'between:4,80'],
            'weight_kg' => ['nullable', 'numeric', 'between:0.1,500'],
            'height_cm' => ['nullable', 'numeric', 'between:20,260'],
            'oxygen_saturation_percent' => ['nullable', 'integer', 'between:1,100'],
            'assessment' => [$request->input('action') === 'finalize' ? 'required' : 'nullable', 'string', 'max:20000'],
            'plan' => ['nullable', 'string', 'max:20000'],
            'procedures' => ['nullable', 'string', 'max:20000'],
            'follow_up_date' => ['nullable', 'date', 'after_or_equal:today'],
            'follow_up_notes' => ['nullable', 'string', 'max:5000'],
            'prescription_instructions' => ['nullable', 'string', 'max:5000'],
            'prescriptions' => ['nullable', 'array', 'max:10'],
            'prescriptions.*' => ['array'],
            'prescriptions.*.medicine_name' => ['nullable', 'string', 'max:180'],
            'prescriptions.*.strength' => ['nullable', 'string', 'max:100'],
            'prescriptions.*.dosage' => ['nullable', 'string', 'max:120'],
            'prescriptions.*.frequency' => ['nullable', 'string', 'max:120'],
            'prescriptions.*.duration' => ['nullable', 'string', 'max:120'],
            'prescriptions.*.quantity' => ['nullable', 'string', 'max:80'],
            'prescriptions.*.item_instructions' => ['nullable', 'string', 'max:1000'],
        ], [
            'assessment.required' => 'Diagnosis/asesmen wajib diisi sebelum rekam medis disahkan.',
            'follow_up_date.after_or_equal' => 'Tanggal kontrol tidak boleh berada di masa lalu.',
        ]);
    }

    private function recordAttributes(array $data): array
    {
        return collect($data)->only([
            'subjective', 'objective', 'blood_pressure', 'temperature_celsius', 'heart_rate_bpm',
            'respiratory_rate_per_minute', 'weight_kg', 'height_cm', 'oxygen_saturation_percent',
            'assessment', 'plan', 'procedures', 'follow_up_date', 'follow_up_notes',
        ])->all();
    }

    private function syncPrescription(MedicalRecord $record, array $data): void
    {
        $items = collect($data['prescriptions'] ?? [])
            ->filter(fn (array $item) => filled($item['medicine_name'] ?? null))
            ->values();

        $prescription = $record->prescription;
        if ($items->isEmpty()) {
            $prescription?->delete();
            $record->unsetRelation('prescription');
            return;
        }

        if (!$prescription) {
            $prescription = $record->prescription()->create([
                'prescription_number' => 'RX-'.now('Asia/Jakarta')->format('Ymd').'-'.Str::upper(Str::random(6)),
                'instructions' => $data['prescription_instructions'] ?? null,
                'status' => 'draft',
            ]);
        } else {
            $prescription->update([
                'instructions' => $data['prescription_instructions'] ?? null,
                'status' => 'draft',
                'issued_at' => null,
            ]);
        }

        $prescription->items()->delete();
        foreach ($items as $index => $item) {
            $prescription->items()->create([
                'medicine_name' => trim($item['medicine_name']),
                'strength' => $item['strength'] ?? null,
                'dosage' => $item['dosage'] ?? null,
                'frequency' => $item['frequency'] ?? null,
                'duration' => $item['duration'] ?? null,
                'quantity' => $item['quantity'] ?? null,
                'item_instructions' => $item['item_instructions'] ?? null,
                'sort_order' => $index,
            ]);
        }
        $record->setRelation('prescription', $prescription);
    }

    private function finalizeWhenRequested(MedicalRecord $record, Appointment $appointment, array $data, Request $request): void
    {
        if (($data['action'] ?? 'draft') !== 'finalize') {
            return;
        }

        $moment = Carbon::parse($appointment->appointment_date->toDateString().' '.substr((string) $appointment->start_time, 0, 5), 'Asia/Jakarta');
        if ($moment->isFuture()) {
            throw ValidationException::withMessages(['action' => 'Rekam medis hanya dapat disahkan setelah waktu pemeriksaan berlangsung. Simpan sebagai draf terlebih dahulu.']);
        }
        if (in_array($appointment->status, ['cancelled', 'no_show'], true)) {
            throw ValidationException::withMessages(['action' => 'Janji temu yang dibatalkan atau tidak hadir tidak dapat disahkan.']);
        }

        $patient = $record->patient()->first();
        $record->update([
            'patient_allergies_snapshot' => $patient?->allergies,
            'patient_medical_history_snapshot' => $patient?->medical_history,
            'patient_current_medications_snapshot' => $patient?->current_medications,
            'status' => 'finalized',
            'finalized_by' => $request->user()->id,
            'finalized_at' => now(),
        ]);
        $record->prescription?->update(['status' => 'issued', 'issued_at' => now()]);
        $appointment->update([
            'status' => 'completed',
            'confirmed_at' => $appointment->confirmed_at ?? now(),
            'completed_at' => $appointment->completed_at ?? now(),
        ]);
        $record->logActivity($request->user(), 'finalized', ['prescription_issued' => (bool) $record->prescription], $request->ip(), $request->userAgent());
    }

    private function prescriptionItemCount(array $data): int
    {
        return collect($data['prescriptions'] ?? [])->filter(fn (array $item) => filled($item['medicine_name'] ?? null))->count();
    }

    private function newRecordNumber(Appointment $appointment): string
    {
        return 'RME-'.$appointment->appointment_date->format('Ymd').'-'.Str::upper(Str::random(6));
    }

    private function loadPatientHistory(Request $request, Patient $patient, ?int $excludeRecordId): Collection
    {
        $records = $patient->medicalRecords()
            ->where('status', 'finalized')
            ->when($excludeRecordId, fn (Builder $query) => $query->where('id', '!=', $excludeRecordId))
            ->with(['doctor', 'polyclinic', 'appointment'])
            ->orderByDesc('encounter_date')->orderByDesc('id')
            ->limit(5)->get();

        foreach ($records as $historyRecord) {
            $historyRecord->logActivity(
                $request->user(),
                'history_viewed_by_treating_doctor',
                ['current_record_id' => $excludeRecordId],
                $request->ip(),
                $request->userAgent()
            );
        }

        return $records;
    }

    private function ensureCanDocument(Appointment $appointment): void
    {
        abort_unless(in_array($appointment->status, ['confirmed', 'completed'], true), 422, 'Konfirmasi janji temu terlebih dahulu sebelum membuat rekam medis.');
        $moment = Carbon::parse($appointment->appointment_date->toDateString().' '.substr((string) $appointment->start_time, 0, 5), 'Asia/Jakarta');
        abort_if($moment->isFuture(), 422, 'Rekam medis baru dapat dibuat setelah waktu pemeriksaan dimulai.');
    }

    private function ensureOwnAppointment(Request $request, Appointment $appointment): void
    {
        $doctor = $request->user()->doctor;
        abort_unless($doctor && (int) $appointment->doctor_id === (int) $doctor->id, 404);
    }

    private function ensureOwnRecord(Request $request, MedicalRecord $medicalRecord): void
    {
        $doctor = $request->user()->doctor;
        abort_unless($doctor && (int) $medicalRecord->doctor_id === (int) $doctor->id, 404);
    }
}
