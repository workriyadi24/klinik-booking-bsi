<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\Polyclinic;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $polyclinics = Polyclinic::query()->where('is_active', true)->orderBy('sort_order')->orderBy('name')->get();

        $doctors = Doctor::query()
            ->with(['polyclinic', 'schedules'])
            ->where('is_active', true)
            ->whereHas('polyclinic', fn ($query) => $query->where('is_active', true))
            ->when($request->filled('polyclinic'), fn ($query) => $query->where('polyclinic_id', $request->integer('polyclinic')))
            ->when($request->filled('doctor'), fn ($query) => $query->where('name', 'like', '%'.$request->string('doctor').'%'))
            ->orderBy('name')
            ->paginate(6)
            ->withQueryString();

        return view('public.home', compact('polyclinics', 'doctors'));
    }
}
