<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Throwable;

class PatientAuthController extends Controller
{
    public function showLogin()
    {
        if (Auth::check() && Auth::user()->isPatient()) {
            return $this->afterAuthentication();
        }

        return view('patient.auth.login');
    }

    public function showRegister()
    {
        if (Auth::check() && Auth::user()->isPatient()) {
            return $this->afterAuthentication();
        }

        return view('patient.auth.register');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'min:3', 'max:160'],
            'email' => ['required', 'email', 'max:160', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'terms' => ['accepted'],
        ], [
            'email.unique' => 'Email sudah terdaftar. Silakan login menggunakan akun tersebut.',
            'password.confirmed' => 'Konfirmasi password tidak sama.',
            'terms.accepted' => 'Persetujuan penggunaan data wajib dicentang.',
        ]);

        $user = User::create([
            'name' => $data['name'],
            'email' => Str::lower($data['email']),
            'password' => $data['password'],
            'role' => 'patient',
            'is_admin' => false,
            'is_active' => true,
        ]);

        Auth::login($user);
        $request->session()->regenerate();

        return redirect()->route('patient.profile.create')
            ->with('success', 'Akun berhasil dibuat. Lengkapi profil pasien satu kali untuk melanjutkan.');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $credentials['email'] = Str::lower($credentials['email']);
        $key = 'patient|'.$credentials['email'].'|'.$request->ip();
        if (RateLimiter::tooManyAttempts($key, 5)) {
            throw ValidationException::withMessages([
                'email' => 'Terlalu banyak percobaan login. Coba lagi dalam '.RateLimiter::availableIn($key).' detik.',
            ]);
        }

        if (!Auth::attempt($credentials + ['role' => 'patient', 'is_admin' => false, 'is_active' => true], $request->boolean('remember'))) {
            RateLimiter::hit($key, 60);
            throw ValidationException::withMessages(['email' => 'Email atau password tidak sesuai.']);
        }

        RateLimiter::clear($key);
        $request->session()->regenerate();

        return $this->afterAuthentication();
    }

    public function googleRedirect(Request $request)
    {
        $clientId = config('services.google.client_id');
        $redirectUri = config('services.google.redirect');
        if (!$clientId || !config('services.google.client_secret') || !$redirectUri) {
            return redirect()->route('patient.login')->withErrors([
                'google' => 'Login Google belum diaktifkan. Isi GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, dan GOOGLE_REDIRECT_URI di file .env.',
            ]);
        }

        $state = Str::random(48);
        $request->session()->put('google_oauth_state', $state);
        $query = http_build_query([
            'client_id' => $clientId,
            'redirect_uri' => $redirectUri,
            'response_type' => 'code',
            'scope' => 'openid email profile',
            'state' => $state,
            'prompt' => 'select_account',
        ]);

        return redirect()->away('https://accounts.google.com/o/oauth2/v2/auth?'.$query);
    }

    public function googleCallback(Request $request)
    {
        $sessionState = (string) $request->session()->pull('google_oauth_state', '');
        $queryState = (string) $request->query('state', '');
        if (!$sessionState || !$queryState || !hash_equals($sessionState, $queryState) || !$request->filled('code')) {
            return redirect()->route('patient.login')->withErrors(['google' => 'Sesi login Google tidak valid atau telah kedaluwarsa. Silakan coba kembali.']);
        }

        try {
            $tokenResponse = Http::asForm()->acceptJson()->timeout(12)->post('https://oauth2.googleapis.com/token', [
                'code' => $request->query('code'),
                'client_id' => config('services.google.client_id'),
                'client_secret' => config('services.google.client_secret'),
                'redirect_uri' => config('services.google.redirect'),
                'grant_type' => 'authorization_code',
            ])->throw()->json();

            $googleUser = Http::withToken($tokenResponse['access_token'] ?? '')
                ->acceptJson()->timeout(12)->get('https://openidconnect.googleapis.com/v1/userinfo')->throw()->json();
        } catch (Throwable $exception) {
            report($exception);

            return redirect()->route('patient.login')->withErrors(['google' => 'Google tidak dapat dihubungi saat ini. Silakan gunakan login email atau coba kembali.']);
        }

        if (empty($googleUser['sub']) || empty($googleUser['email']) || !filter_var($googleUser['email'], FILTER_VALIDATE_EMAIL) || !($googleUser['email_verified'] ?? false)) {
            return redirect()->route('patient.login')->withErrors(['google' => 'Akun Google harus memiliki email terverifikasi.']);
        }

        $email = Str::lower($googleUser['email']);
        $user = User::where('google_id', $googleUser['sub'])->first();
        if (!$user) {
            $user = User::where('email', $email)->first();
        }

        if ($user && !$user->isPatient()) {
            return redirect()->route('patient.login')->withErrors(['google' => 'Email Google ini telah digunakan untuk akun petugas. Gunakan halaman login sesuai peran akun.']);
        }

        if (!$user) {
            $user = User::create([
                'name' => $googleUser['name'] ?? Str::before($email, '@'),
                'email' => $email,
                'password' => Str::random(64),
                'role' => 'patient',
                'is_admin' => false,
                'is_active' => true,
                'google_id' => $googleUser['sub'],
                'email_verified_at' => now(),
            ]);
        } else {
            $user->forceFill([
                'google_id' => $googleUser['sub'],
                'email_verified_at' => $user->email_verified_at ?? now(),
            ])->save();
        }

        if (!$user->is_active) {
            return redirect()->route('patient.login')->withErrors(['google' => 'Akun pasien sedang dinonaktifkan. Hubungi petugas klinik.']);
        }

        Auth::login($user, true);
        $request->session()->regenerate();

        return $this->afterAuthentication();
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')->with('success', 'Anda berhasil keluar dari akun pasien.');
    }

    private function afterAuthentication()
    {
        $user = Auth::user();
        if (!$user || !$user->isPatient()) {
            return redirect()->route('patient.login');
        }
        if (!$user->is_active) {
            Auth::logout();
            return redirect()->route('patient.login')->withErrors(['email' => 'Akun pasien sedang dinonaktifkan. Hubungi petugas klinik.']);
        }

        if (!$user->patient()->exists()) {
            return redirect()->route('patient.profile.create');
        }

        $intent = session('booking_intent');
        if ($intent && (!isset($intent['created_at']) || $intent['created_at'] < now()->subMinutes(30)->timestamp)) {
            session()->forget('booking_intent');
            $intent = null;
        }
        if ($intent && !empty($intent['doctor_slug']) && !empty($intent['date']) && !empty($intent['time'])) {
            return redirect()->route('appointments.register', [
                'doctor' => $intent['doctor_slug'], 'date' => $intent['date'], 'time' => $intent['time'],
            ]);
        }

        return redirect()->intended(route('patient.dashboard'));
    }
}
