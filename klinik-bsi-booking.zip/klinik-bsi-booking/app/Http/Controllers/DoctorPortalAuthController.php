<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class DoctorPortalAuthController extends Controller
{
    public function showLogin()
    {
        if (Auth::check() && Auth::user()->isDoctor() && Auth::user()->is_active) {
            return redirect()->route('doctor-portal.dashboard');
        }

        return view('doctor-portal.auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);
        $credentials['email'] = Str::lower($credentials['email']);
        $key = 'doctor|'.$credentials['email'].'|'.$request->ip();

        if (RateLimiter::tooManyAttempts($key, 5)) {
            throw ValidationException::withMessages([
                'email' => 'Terlalu banyak percobaan login. Coba lagi dalam '.RateLimiter::availableIn($key).' detik.',
            ]);
        }

        if (!Auth::attempt($credentials + ['role' => 'doctor', 'is_admin' => false, 'is_active' => true], $request->boolean('remember'))) {
            RateLimiter::hit($key, 60);
            throw ValidationException::withMessages(['email' => 'Email atau password dokter tidak sesuai.']);
        }

        if (!Auth::user()->doctor_id) {
            Auth::logout();
            throw ValidationException::withMessages(['email' => 'Akun dokter belum terhubung dengan profil dokter. Hubungi administrator.']);
        }

        RateLimiter::clear($key);
        $request->session()->regenerate();

        return redirect()->intended(route('doctor-portal.dashboard'));
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('doctor-portal.login')->with('success', 'Anda berhasil keluar dari portal dokter.');
    }
}
