<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use Illuminate\Http\Request;

class PatientProfileController extends Controller
{
    public function create()
    {
        $user = auth()->user();
        if ($user->patient()->exists()) {
            return redirect()->route('patient.dashboard');
        }

        return view('patient.profile.form', ['patient' => new Patient(), 'isCreate' => true]);
    }

    public function store(Request $request)
    {
        abort_if($request->user()->patient()->exists(), 409, 'Profil pasien sudah tersedia.');
        $validated = $this->validatedData($request);
        $validated['user_id'] = $request->user()->id;
        $validated['email'] = $request->user()->email;
        $validated['medical_record_number'] = $this->generateMedicalRecordNumber();

        Patient::create($validated);

        $intent = session('booking_intent');
        if ($intent && (!isset($intent['created_at']) || $intent['created_at'] < now()->subMinutes(30)->timestamp)) {
            session()->forget('booking_intent');
            $intent = null;
        }
        if ($intent && !empty($intent['doctor_slug']) && !empty($intent['date']) && !empty($intent['time'])) {
            return redirect()->route('appointments.register', [
                'doctor' => $intent['doctor_slug'], 'date' => $intent['date'], 'time' => $intent['time'],
            ])->with('success', 'Profil pasien tersimpan. Periksa kembali detail janji temu Anda.');
        }

        return redirect()->route('patient.dashboard')->with('success', 'Profil pasien berhasil disimpan.');
    }

    public function edit(Request $request)
    {
        $patient = $request->user()->patient;
        abort_unless($patient, 404);

        return view('patient.profile.form', ['patient' => $patient, 'isCreate' => false]);
    }

    public function update(Request $request)
    {
        $patient = $request->user()->patient;
        abort_unless($patient, 404);
        $patient->update($this->validatedData($request));

        return redirect()->route('patient.dashboard')->with('success', 'Profil pasien berhasil diperbarui.');
    }

    private function validatedData(Request $request): array
    {
        return $request->validate([
            'full_name' => ['required', 'string', 'min:3', 'max:160'],
            'birth_place' => ['required', 'string', 'max:100'],
            'birth_date' => ['required', 'date', 'before:today'],
            'gender' => ['required', 'in:Laki-laki,Perempuan'],
            'address' => ['required', 'string', 'max:2000'],
            'religion' => ['nullable', 'string', 'max:40'],
            'family_card_number' => ['nullable', 'digits:16'],
            'marital_status' => ['nullable', 'in:Belum Menikah,Menikah,Cerai Hidup,Cerai Mati'],
            'education' => ['nullable', 'in:SD,SMP,SMA/SMK,Diploma,S1,S2,S3,Lainnya'],
            'phone' => ['required', 'string', 'min:9', 'max:24', 'regex:/^(\\+?62|0)[0-9]{8,16}$/'],
            'medical_history' => ['nullable', 'string', 'max:3000'],
            'allergies' => ['nullable', 'string', 'max:2000'],
            'current_medications' => ['nullable', 'string', 'max:2000'],
        ], [
            'family_card_number.digits' => 'Nomor KK harus terdiri dari 16 digit.',
            'phone.regex' => 'Masukkan nomor WhatsApp/telepon Indonesia yang valid, contoh 081234567890.',
        ]);
    }

    private function generateMedicalRecordNumber(): string
    {
        do {
            $number = 'RM'.now('Asia/Jakarta')->format('ymd').str_pad((string) random_int(1, 99999), 5, '0', STR_PAD_LEFT);
        } while (Patient::where('medical_record_number', $number)->exists());

        return $number;
    }
}
