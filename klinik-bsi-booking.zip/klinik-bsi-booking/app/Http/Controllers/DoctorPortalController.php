<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class DoctorPortalController extends Controller
{
    public function dashboard(Request $request)
    {
        $doctor = $request->user()->doctor()->with('polyclinic')->firstOrFail();
        $base = $doctor->appointments();
        $stats = [
            'today' => (clone $base)->whereDate('appointment_date', now('Asia/Jakarta')->toDateString())->count(),
            'pending' => (clone $base)->where('status', 'pending')->count(),
            'upcoming' => (clone $base)->whereIn('status', ['pending', 'confirmed'])->whereDate('appointment_date', '>=', now('Asia/Jakarta')->toDateString())->count(),
            'completed' => (clone $base)->where('status', 'completed')->count(),
        ];
        $appointments = $doctor->appointments()
            ->with(['patient', 'polyclinic'])
            ->whereDate('appointment_date', '>=', now('Asia/Jakarta')->toDateString())
            ->whereNotIn('status', ['cancelled', 'no_show'])
            ->orderBy('appointment_date')->orderBy('start_time')->limit(12)->get();
        $recentAppointments = $doctor->appointments()->with('patient')
            ->orderByDesc('appointment_date')->orderByDesc('start_time')->limit(8)->get();

        return view('doctor-portal.dashboard', compact('doctor', 'stats', 'appointments', 'recentAppointments'));
    }

    public function show(Request $request, Appointment $appointment)
    {
        $doctor = $request->user()->doctor;
        abort_unless($doctor && (int) $appointment->doctor_id === (int) $doctor->id, 404);
        $appointment->load(['patient.user', 'doctor.polyclinic', 'polyclinic', 'medicalRecord']);
        $appointmentMoment = Carbon::parse($appointment->appointment_date->toDateString().' '.substr((string) $appointment->start_time, 0, 5), 'Asia/Jakarta');
        $canCreateMedicalRecord = in_array($appointment->status, ['confirmed', 'completed'], true) && !$appointmentMoment->isFuture();

        return view('doctor-portal.appointments.show', compact('doctor', 'appointment', 'canCreateMedicalRecord'));
    }

    public function update(Request $request, Appointment $appointment)
    {
        $doctor = $request->user()->doctor;
        abort_unless($doctor && (int) $appointment->doctor_id === (int) $doctor->id, 404);

        $data = $request->validate([
            'status' => ['required', 'in:confirmed'],
        ]);

        if (in_array($appointment->status, ['cancelled', 'no_show'], true)) {
            throw ValidationException::withMessages(['status' => 'Janji temu yang dibatalkan atau tidak hadir tidak dapat dikonfirmasi.']);
        }
        if ($appointment->status === 'completed') {
            throw ValidationException::withMessages(['status' => 'Pemeriksaan sudah selesai. Gunakan rekam medis untuk melihat catatan final.']);
        }

        $appointment->update([
            'status' => $data['status'],
            'confirmed_at' => $appointment->confirmed_at ?? now(),
        ]);

        return redirect()->route('doctor-portal.appointments.show', $appointment)->with('success', 'Janji temu berhasil dikonfirmasi. Setelah pemeriksaan, buat dan sahkan rekam medis pasien.');
    }
}
