<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class EnsureDoctor
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check()) {
            return redirect()->guest(route('doctor-portal.login'));
        }

        $user = Auth::user();
        if (!$user->is_active || $user->is_admin || $user->role !== 'doctor' || !$user->doctor_id || !$user->doctor?->is_active) {
            abort(403, 'Akun ini tidak memiliki akses portal dokter.');
        }

        return $next($request);
    }
}
