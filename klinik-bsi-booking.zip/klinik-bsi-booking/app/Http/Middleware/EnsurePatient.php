<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class EnsurePatient
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check()) {
            return redirect()->guest(route('patient.login'));
        }

        $user = Auth::user();
        if (!$user->is_active || $user->is_admin || $user->role !== 'patient') {
            abort(403, 'Akun ini tidak memiliki akses pasien.');
        }

        return $next($request);
    }
}
