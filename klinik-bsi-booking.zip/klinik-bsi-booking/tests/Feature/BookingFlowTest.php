<?php

namespace Tests\Feature;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BookingFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed([
            \Database\Seeders\AdminUserSeeder::class,
            \Database\Seeders\ClinicDemoSeeder::class,
        ]);
    }

    public function test_patient_can_book_one_available_doctor_slot_with_saved_profile(): void
    {
        $doctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $date = Carbon::now('Asia/Jakarta')->next(Carbon::MONDAY)->toDateString();
        $user = $this->createPatient('Pasien Contoh', 'pasien-test@example.test');

        $response = $this->actingAs($user)->post(route('appointments.store', $doctor), $this->validBookingData($date));

        $response->assertRedirect();
        $this->assertDatabaseHas('appointments', [
            'doctor_id' => $doctor->id,
            'appointment_date' => $date,
            'start_time' => '08:00:00',
            'status' => 'pending',
            'complaint' => 'Konsultasi awal pasien.',
        ]);
    }

    public function test_booked_slot_cannot_be_booked_twice(): void
    {
        $doctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $date = Carbon::now('Asia/Jakarta')->next(Carbon::MONDAY)->toDateString();
        $firstUser = $this->createPatient('Pasien Pertama', 'pasien1-test@example.test');
        $secondUser = $this->createPatient('Pasien Kedua', 'pasien2-test@example.test');

        $this->actingAs($firstUser)->post(route('appointments.store', $doctor), $this->validBookingData($date));
        $second = $this->validBookingData($date);
        $second['complaint'] = 'Keluhan pasien yang berbeda.';

        $response = $this->actingAs($secondUser)->from(route('appointments.create', $doctor))
            ->post(route('appointments.store', $doctor), $second);

        $response->assertRedirect(route('appointments.create', $doctor));
        $response->assertSessionHasErrors('start_time');
        $this->assertDatabaseCount('appointments', 1);
    }

    public function test_family_members_can_have_separate_accounts_with_shared_phone_and_family_card(): void
    {
        $doctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $date = Carbon::now('Asia/Jakarta')->next(Carbon::MONDAY)->toDateString();
        $firstUser = $this->createPatient('Pasien Utama', 'utama-test@example.test', '081234567890');
        $secondUser = $this->createPatient('Anak Pasien', 'anak-test@example.test', '081234567890');

        $this->actingAs($firstUser)->post(route('appointments.store', $doctor), $this->validBookingData($date));
        $second = $this->validBookingData($date);
        $second['start_time'] = '09:00';

        $this->actingAs($secondUser)->post(route('appointments.store', $doctor), $second)->assertRedirect();

        $this->assertDatabaseCount('patients', 2);
        $this->assertDatabaseCount('appointments', 2);
    }

    public function test_guest_must_login_and_booking_selection_is_preserved(): void
    {
        $doctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $date = Carbon::now('Asia/Jakarta')->next(Carbon::MONDAY)->toDateString();

        $response = $this->get(route('appointments.register', ['doctor' => $doctor, 'date' => $date, 'time' => '08:00']));

        $response->assertRedirect(route('patient.login'));
        $response->assertSessionHas('booking_intent.doctor_id', $doctor->id);
        $response->assertSessionHas('booking_intent.doctor_slug', $doctor->slug);
        $response->assertSessionHas('booking_intent.date', $date);
        $response->assertSessionHas('booking_intent.time', '08:00');
    }

    public function test_patient_dashboard_requires_login(): void
    {
        $this->get(route('patient.dashboard'))->assertRedirect(route('patient.login'));
    }

    public function test_doctor_can_only_open_appointments_assigned_to_them(): void
    {
        $patient = $this->createPatient('Pasien Portal', 'portal-test@example.test');
        $ownDoctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $otherDoctor = Doctor::where('slug', 'dr-andi-pratama-sppd')->firstOrFail();
        $dateOwn = Carbon::now('Asia/Jakarta')->next(Carbon::MONDAY)->toDateString();
        $dateOther = Carbon::now('Asia/Jakarta')->next(Carbon::WEDNESDAY)->toDateString();

        $this->actingAs($patient)->post(route('appointments.store', $ownDoctor), $this->validBookingData($dateOwn));
        $ownAppointment = Appointment::firstOrFail();
        $secondBooking = $this->validBookingData($dateOther);
        $secondBooking['start_time'] = '09:00';
        $this->actingAs($patient)->post(route('appointments.store', $otherDoctor), $secondBooking);
        $otherAppointment = Appointment::where('doctor_id', $otherDoctor->id)->firstOrFail();

        $doctorAccount = User::where('email', 'dokter1@rumahsakit.test')->firstOrFail();
        $this->post(route('doctor-portal.login.submit'), [
            'email' => $doctorAccount->email, 'password' => 'password',
        ])->assertRedirect(route('doctor-portal.dashboard'));

        $this->get(route('doctor-portal.appointments.show', $ownAppointment))->assertOk();
        $this->get(route('doctor-portal.appointments.show', $otherAppointment))->assertNotFound();
    }


    public function test_patient_can_create_account_and_is_sent_to_complete_profile(): void
    {
        $response = $this->post(route('patient.register.submit'), [
            'name' => 'Pasien Baru',
            'email' => 'pasien-baru@example.test',
            'password' => 'password123',
            'password_confirmation' => 'password123',
            'terms' => '1',
        ]);

        $response->assertRedirect(route('patient.profile.create'));
        $this->assertAuthenticated();
        $this->assertDatabaseHas('users', [
            'email' => 'pasien-baru@example.test', 'role' => 'patient', 'is_admin' => false,
        ]);
        $this->get(route('patient.profile.create'))->assertOk();
    }

    public function test_existing_patient_account_can_login_without_creating_another_patient_record(): void
    {
        $user = $this->createPatient('Pasien Lama', 'pasien-lama@example.test');

        $this->post(route('patient.login.submit'), [
            'email' => $user->email, 'password' => 'password',
        ])->assertRedirect(route('patient.dashboard'));

        $this->assertAuthenticatedAs($user);
        $this->assertDatabaseCount('patients', 1);
    }

    public function test_admin_dashboard_requires_login(): void
    {
        $this->get(route('admin.dashboard'))->assertRedirect(route('admin.login'));
    }

    private function createPatient(string $name, string $email, string $phone = '081234567890'): User
    {
        $user = User::create([
            'name' => $name, 'email' => $email, 'password' => 'password',
            'role' => 'patient', 'is_admin' => false, 'is_active' => true,
        ]);

        Patient::create([
            'user_id' => $user->id, 'medical_record_number' => 'RM'.str_pad((string) $user->id, 8, '0', STR_PAD_LEFT),
            'full_name' => $name, 'birth_place' => 'Jakarta', 'birth_date' => '1998-05-10',
            'gender' => 'Laki-laki', 'address' => 'Jl. Contoh No. 10, Jakarta',
            'phone' => $phone, 'email' => $email, 'family_card_number' => '3171000000000001',
        ]);

        return $user;
    }

    private function validBookingData(string $date): array
    {
        return [
            'appointment_date' => $date,
            'start_time' => '08:00',
            'complaint' => 'Konsultasi awal pasien.',
            'symptoms' => 'Merasa pusing sesekali.',
            'symptom_duration' => 'Tiga hari',
            'privacy_accepted' => '1',
        ];
    }
}
