<?php

namespace Tests\Feature;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\MedicalRecord;
use App\Models\Patient;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MedicalRecordFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed([
            \Database\Seeders\AdminUserSeeder::class,
            \Database\Seeders\ClinicDemoSeeder::class,
        ]);
    }

    public function test_doctor_can_save_a_draft_then_finalize_a_medical_record_and_issue_prescription(): void
    {
        [$patientUser, $patient] = $this->makePatient('Rani Demo', 'rani-medical@example.test');
        $doctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $appointment = $this->makeAppointment($patient, $doctor, Carbon::now('Asia/Jakarta')->subDay());
        $doctorUser = User::where('email', 'dokter1@rumahsakit.test')->firstOrFail();

        $payload = $this->recordPayload('draft');
        $this->actingAs($doctorUser)
            ->post(route('doctor-portal.medical-records.store', $appointment), $payload)
            ->assertRedirect();

        $record = MedicalRecord::where('appointment_id', $appointment->id)->firstOrFail();
        $this->assertSame('draft', $record->status);
        $this->assertDatabaseHas('appointments', ['id' => $appointment->id, 'status' => 'confirmed']);

        $payload['action'] = 'finalize';
        $this->actingAs($doctorUser)
            ->put(route('doctor-portal.medical-records.update', $record), $payload)
            ->assertRedirect(route('doctor-portal.medical-records.show', $record));

        $this->assertDatabaseHas('medical_records', ['id' => $record->id, 'status' => 'finalized']);
        $this->assertDatabaseHas('appointments', ['id' => $appointment->id, 'status' => 'completed']);
        $this->assertDatabaseHas('prescriptions', ['medical_record_id' => $record->id, 'status' => 'issued']);
        $this->assertDatabaseHas('prescription_items', ['medicine_name' => 'Obat contoh demo']);
        $this->assertDatabaseHas('medical_record_audits', ['medical_record_id' => $record->id, 'action' => 'finalized']);
    }

    public function test_doctor_cannot_access_medical_record_owned_by_another_doctor(): void
    {
        [, $patient] = $this->makePatient('Pasien Uji', 'patient-access@example.test');
        $doctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $appointment = $this->makeAppointment($patient, $doctor, Carbon::now('Asia/Jakarta')->subDay());
        $doctorUser = User::where('email', 'dokter1@rumahsakit.test')->firstOrFail();
        $this->actingAs($doctorUser)->post(route('doctor-portal.medical-records.store', $appointment), $this->recordPayload('draft'));
        $record = MedicalRecord::where('appointment_id', $appointment->id)->firstOrFail();

        $otherDoctor = User::where('email', 'dokter2@rumahsakit.test')->firstOrFail();
        $this->actingAs($otherDoctor)->get(route('doctor-portal.medical-records.edit', $record))->assertNotFound();
    }

    public function test_treating_doctor_can_review_previous_finalized_record_from_another_doctor_and_access_is_audited(): void
    {
        [, $patient] = $this->makePatient('Pasien Riwayat', 'patient-history@example.test');
        $doctorOne = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $doctorTwo = Doctor::where('slug', 'dr-andi-pratama-sppd')->firstOrFail();
        $doctorOneUser = User::where('email', 'dokter1@rumahsakit.test')->firstOrFail();

        $olderAppointment = $this->makeAppointment($patient, $doctorTwo, Carbon::now('Asia/Jakarta')->subDays(5), 'BSIHISTORY01');
        $olderRecord = MedicalRecord::create([
            'record_number' => 'RME-HISTORY-0001',
            'appointment_id' => $olderAppointment->id,
            'patient_id' => $patient->id,
            'doctor_id' => $doctorTwo->id,
            'polyclinic_id' => $doctorTwo->polyclinic_id,
            'encounter_date' => $olderAppointment->appointment_date,
            'encounter_time' => $olderAppointment->start_time,
            'subjective' => 'Keluhan dari kunjungan sebelumnya lintas dokter.',
            'assessment' => 'Asesmen dari dokter sebelumnya yang relevan.',
            'status' => 'finalized',
            'finalized_by' => User::where('email', 'dokter2@rumahsakit.test')->value('id'),
            'finalized_at' => now(),
        ]);

        $currentAppointment = $this->makeAppointment($patient, $doctorOne, Carbon::now('Asia/Jakarta')->subDay(), 'BSIHISTORY02');
        $currentRecord = MedicalRecord::create([
            'record_number' => 'RME-HISTORY-0002',
            'appointment_id' => $currentAppointment->id,
            'patient_id' => $patient->id,
            'doctor_id' => $doctorOne->id,
            'polyclinic_id' => $doctorOne->polyclinic_id,
            'encounter_date' => $currentAppointment->appointment_date,
            'encounter_time' => $currentAppointment->start_time,
            'assessment' => 'Asesmen kunjungan dokter saat ini.',
            'status' => 'finalized',
            'finalized_by' => $doctorOneUser->id,
            'finalized_at' => now(),
        ]);

        $this->actingAs($doctorOneUser)
            ->get(route('doctor-portal.medical-records.show', $currentRecord))
            ->assertOk()
            ->assertSee('Asesmen dari dokter sebelumnya yang relevan.');

        $this->assertDatabaseHas('medical_record_audits', [
            'medical_record_id' => $olderRecord->id,
            'actor_user_id' => $doctorOneUser->id,
            'action' => 'history_viewed_by_treating_doctor',
        ]);
    }

    public function test_patient_can_only_view_own_finalized_medical_records(): void
    {
        [$patientUser, $patient] = $this->makePatient('Pasien Pemilik', 'owner-medical@example.test');
        [, $otherPatient] = $this->makePatient('Pasien Lain', 'other-medical@example.test');
        $doctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->firstOrFail();
        $appointment = $this->makeAppointment($patient, $doctor, Carbon::now('Asia/Jakarta')->subDays(2));
        $record = MedicalRecord::create([
            'record_number' => 'RME-TEST-00001',
            'appointment_id' => $appointment->id,
            'patient_id' => $patient->id,
            'doctor_id' => $doctor->id,
            'polyclinic_id' => $doctor->polyclinic_id,
            'encounter_date' => $appointment->appointment_date,
            'encounter_time' => $appointment->start_time,
            'assessment' => 'Asesmen demo',
            'status' => 'finalized',
            'finalized_by' => User::where('email', 'dokter1@rumahsakit.test')->value('id'),
            'finalized_at' => now(),
        ]);
        $this->actingAs($patientUser)->get(route('patient.medical-records.show', $record))->assertOk();

        $otherAppointment = $this->makeAppointment($otherPatient, $doctor, Carbon::now('Asia/Jakarta')->subDays(3), 'BSITEST02');
        $otherRecord = MedicalRecord::create([
            'record_number' => 'RME-TEST-00002',
            'appointment_id' => $otherAppointment->id,
            'patient_id' => $otherPatient->id,
            'doctor_id' => $doctor->id,
            'polyclinic_id' => $doctor->polyclinic_id,
            'encounter_date' => $otherAppointment->appointment_date,
            'encounter_time' => $otherAppointment->start_time,
            'assessment' => 'Asesmen demo',
            'status' => 'finalized',
            'finalized_by' => User::where('email', 'dokter1@rumahsakit.test')->value('id'),
            'finalized_at' => now(),
        ]);
        $this->get(route('patient.medical-records.show', $otherRecord))->assertNotFound();
    }

    private function makePatient(string $name, string $email): array
    {
        $user = User::create(['name' => $name, 'email' => $email, 'password' => 'password', 'role' => 'patient', 'is_admin' => false, 'is_active' => true]);
        $patient = Patient::create([
            'user_id' => $user->id,
            'medical_record_number' => 'RM'.str_pad((string) $user->id, 8, '0', STR_PAD_LEFT),
            'full_name' => $name,
            'birth_place' => 'Jakarta',
            'birth_date' => '1998-05-10',
            'gender' => 'Perempuan',
            'address' => 'Jakarta',
            'phone' => '081234567890',
            'email' => $email,
        ]);

        return [$user, $patient];
    }

    private function makeAppointment(Patient $patient, Doctor $doctor, Carbon $date, string $code = 'BSITEST01'): Appointment
    {
        static $sequence = 0;
        $sequence++;
        return Appointment::create([
            'booking_code' => $code === 'BSITEST01' && $sequence > 1 ? 'BSITEST0'.$sequence : $code,
            'patient_id' => $patient->id,
            'doctor_id' => $doctor->id,
            'polyclinic_id' => $doctor->polyclinic_id,
            'appointment_date' => $date->toDateString(),
            'start_time' => '09:00:00',
            'end_time' => '09:30:00',
            'status' => 'confirmed',
            'complaint' => 'Keluhan untuk tes.',
            'confirmed_at' => now(),
        ]);
    }

    private function recordPayload(string $action): array
    {
        return [
            'action' => $action,
            'subjective' => 'Keluhan dan riwayat singkat untuk pengujian.',
            'objective' => 'Temuan pemeriksaan contoh.',
            'blood_pressure' => '120/80 mmHg',
            'temperature_celsius' => '36.5',
            'heart_rate_bpm' => 78,
            'assessment' => 'Asesmen klinis contoh untuk pengujian.',
            'plan' => 'Rencana tindak lanjut contoh.',
            'prescriptions' => [[
                'medicine_name' => 'Obat contoh demo',
                'strength' => '500 mg',
                'dosage' => '1 tablet',
                'frequency' => '2 kali sehari',
                'duration' => '3 hari',
                'quantity' => '6 tablet',
                'item_instructions' => 'Sesudah makan',
            ]],
            'prescription_instructions' => 'Instruksi resep tes.',
        ];
    }
}
