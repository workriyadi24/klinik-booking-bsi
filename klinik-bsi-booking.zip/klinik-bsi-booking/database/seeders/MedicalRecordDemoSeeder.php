<?php

namespace Database\Seeders;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\MedicalRecord;
use App\Models\Patient;
use App\Models\Prescription;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class MedicalRecordDemoSeeder extends Seeder
{
    public function run(): void
    {
        $patient = Patient::where('medical_record_number', 'RMDEMO0001')->first();
        $doctor = Doctor::where('slug', 'dr-syifa-azzahra-spkj')->first();
        if (!$patient || !$doctor) {
            return;
        }

        $visitDate = Carbon::now('Asia/Jakarta')->subDays(10);
        $appointment = Appointment::updateOrCreate(
            ['booking_code' => 'BSIDEMO003'],
            [
                'patient_id' => $patient->id,
                'doctor_id' => $doctor->id,
                'polyclinic_id' => $doctor->polyclinic_id,
                'appointment_date' => $visitDate->toDateString(),
                'start_time' => '10:00:00',
                'end_time' => '10:30:00',
                'status' => 'completed',
                'complaint' => 'Pasien mengeluhkan gangguan tidur dan rasa cemas yang muncul sesekali.',
                'symptoms' => 'Sulit memulai tidur, tidur tidak nyenyak, dan merasa tegang saat menghadapi pekerjaan.',
                'symptom_duration' => 'Sekitar dua minggu',
                'confirmed_at' => $visitDate->copy()->setTime(9, 0),
                'completed_at' => $visitDate->copy()->setTime(10, 30),
            ]
        );

        $record = MedicalRecord::updateOrCreate(
            ['appointment_id' => $appointment->id],
            [
                'record_number' => 'RME-DEMO-0003',
                'patient_id' => $patient->id,
                'doctor_id' => $doctor->id,
                'polyclinic_id' => $doctor->polyclinic_id,
                'patient_allergies_snapshot' => $patient->allergies,
                'patient_medical_history_snapshot' => $patient->medical_history,
                'patient_current_medications_snapshot' => $patient->current_medications,
                'encounter_date' => $visitDate->toDateString(),
                'encounter_time' => '10:00:00',
                'subjective' => 'Pasien menyampaikan sulit memulai tidur dan beberapa kali terbangun pada malam hari. Keluhan muncul terutama ketika beban pekerjaan meningkat. Pasien menyangkal keluhan fisik lain yang mengganggu aktivitas sehari-hari.',
                'objective' => 'Pasien datang dalam keadaan sadar dan komunikatif. Dilakukan wawancara klinis awal. Temuan pemeriksaan fisik khusus tidak dicatat pada data demo ini.',
                'blood_pressure' => '118/76 mmHg',
                'temperature_celsius' => 36.6,
                'heart_rate_bpm' => 78,
                'respiratory_rate_per_minute' => 18,
                'weight_kg' => 62.5,
                'height_cm' => 165,
                'oxygen_saturation_percent' => 98,
                'assessment' => 'Keluhan gangguan tidur yang perlu dievaluasi lebih lanjut. Asesmen ini merupakan contoh data demo, bukan diagnosis untuk pasien nyata.',
                'plan' => 'Edukasi kebiasaan tidur sehat, pengelolaan stres, dan pemantauan pola tidur. Evaluasi ulang pada kunjungan kontrol.',
                'procedures' => 'Wawancara dan asesmen awal.',
                'follow_up_date' => $visitDate->copy()->addDays(14)->toDateString(),
                'follow_up_notes' => 'Kontrol sesuai jadwal atau lebih awal bila keluhan memburuk.',
                'status' => 'finalized',
                'created_by' => $doctor->user?->id,
                'finalized_by' => $doctor->user?->id,
                'finalized_at' => $visitDate->copy()->setTime(10, 30),
            ]
        );

        $prescription = Prescription::updateOrCreate(
            ['medical_record_id' => $record->id],
            [
                'prescription_number' => 'RX-DEMO-0003',
                'instructions' => 'Data resep ini hanya contoh tampilan modul untuk demonstrasi. Tidak untuk digunakan sebagai instruksi pengobatan.',
                'status' => 'issued',
                'issued_at' => $visitDate->copy()->setTime(10, 30),
            ]
        );
        $prescription->items()->delete();
        $prescription->items()->create([
            'medicine_name' => 'Contoh item resep (demo)',
            'strength' => '—',
            'dosage' => 'Tidak berlaku',
            'frequency' => 'Tidak berlaku',
            'duration' => 'Tidak berlaku',
            'quantity' => '0',
            'item_instructions' => 'Placeholder demonstrasi; bukan obat atau rekomendasi medis.',
            'sort_order' => 1,
        ]);

        $record->addenda()->firstOrCreate(
            ['content' => 'Contoh addendum: data kunjungan ini dibuat untuk demonstrasi fitur. Tidak mewakili catatan medis pasien nyata.'],
            ['doctor_id' => $doctor->id, 'created_by' => $doctor->user?->id]
        );
    }
}
