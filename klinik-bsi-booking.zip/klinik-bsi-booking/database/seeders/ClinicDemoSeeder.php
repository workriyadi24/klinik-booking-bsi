<?php

namespace Database\Seeders;

use App\Models\Doctor;
use App\Models\DoctorSchedule;
use App\Models\Polyclinic;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class ClinicDemoSeeder extends Seeder
{
    public function run(): void
    {
        $polyclinicData = [
            ['name' => 'Psikiatri', 'slug' => 'psikiatri', 'short_description' => 'Layanan kesehatan jiwa dan konsultasi psikologis.', 'description' => 'Pelayanan kesehatan jiwa untuk anak, remaja, dan dewasa.', 'icon' => 'brain', 'color' => '#0DC6BE', 'sort_order' => 1],
            ['name' => 'Penyakit Dalam', 'slug' => 'penyakit-dalam', 'short_description' => 'Pemeriksaan dan penanganan penyakit orang dewasa.', 'description' => 'Konsultasi, pemeriksaan, dan tindak lanjut penyakit dalam.', 'icon' => 'heart-pulse', 'color' => '#3FD183', 'sort_order' => 2],
            ['name' => 'Mata', 'slug' => 'mata', 'short_description' => 'Pemeriksaan kesehatan dan gangguan penglihatan.', 'description' => 'Pelayanan pemeriksaan mata dan konsultasi gangguan penglihatan.', 'icon' => 'eye', 'color' => '#185A80', 'sort_order' => 3],
            ['name' => 'Kebidanan & Kandungan', 'slug' => 'kebidanan-kandungan', 'short_description' => 'Layanan kesehatan ibu dan kandungan.', 'description' => 'Konsultasi kesehatan reproduksi, kehamilan, dan kandungan.', 'icon' => 'baby', 'color' => '#0DC6BE', 'sort_order' => 4],
            ['name' => 'Gigi', 'slug' => 'gigi', 'short_description' => 'Pemeriksaan dan perawatan kesehatan gigi.', 'description' => 'Pemeriksaan rutin, konsultasi, dan perawatan gigi.', 'icon' => 'tooth', 'color' => '#3FD183', 'sort_order' => 5],
        ];

        foreach ($polyclinicData as $data) {
            Polyclinic::updateOrCreate(['slug' => $data['slug']], $data + ['is_active' => true]);
        }

        $doctors = [
            [
                'slug' => 'dr-syifa-azzahra-spkj', 'name' => 'dr. Syifa Azzahra', 'title' => 'Sp.KJ',
                'speciality' => 'Psikiatri Dewasa', 'polyclinic' => 'psikiatri', 'experience_years' => 4,
                'rating' => 4.8, 'rating_count' => 320, 'bio' => 'Melayani konsultasi kesehatan jiwa, gangguan kecemasan, suasana hati, dan pendampingan kesehatan mental.',
                'photo_path' => Storage::disk('public')->exists('doctors/doctor-syifa.jpg') ? 'doctors/doctor-syifa.jpg' : null,
                'schedules' => [[1, '08:00', '11:00', 60], [1, '14:00', '16:00', 60], [4, '08:00', '11:00', 60], [4, '14:00', '16:00', 60]],
            ],
            [
                'slug' => 'dr-andi-pratama-sppd', 'name' => 'dr. Andi Pratama', 'title' => 'Sp.PD',
                'speciality' => 'Penyakit Dalam', 'polyclinic' => 'penyakit-dalam', 'experience_years' => 8,
                'rating' => 4.9, 'rating_count' => 215, 'bio' => 'Berfokus pada pemeriksaan kesehatan orang dewasa dan penanganan penyakit dalam.',
                'photo_path' => null,
                'schedules' => [[1, '09:00', '12:00', 60], [3, '09:00', '12:00', 60], [5, '13:00', '16:00', 60]],
            ],
            [
                'slug' => 'dr-nabila-putri-spm', 'name' => 'dr. Nabila Putri', 'title' => 'Sp.M',
                'speciality' => 'Dokter Mata', 'polyclinic' => 'mata', 'experience_years' => 6,
                'rating' => 4.7, 'rating_count' => 180, 'bio' => 'Melayani pemeriksaan mata umum dan konsultasi gangguan penglihatan.',
                'photo_path' => null,
                'schedules' => [[2, '08:00', '12:00', 60], [4, '13:00', '17:00', 60], [6, '08:00', '11:00', 60]],
            ],
            [
                'slug' => 'dr-bima-saputra-spog', 'name' => 'dr. Bima Saputra', 'title' => 'Sp.OG',
                'speciality' => 'Obstetri & Ginekologi', 'polyclinic' => 'kebidanan-kandungan', 'experience_years' => 10,
                'rating' => 4.9, 'rating_count' => 275, 'bio' => 'Memberikan layanan konsultasi kesehatan ibu, kehamilan, dan kandungan.',
                'photo_path' => null,
                'schedules' => [[2, '09:00', '12:00', 60], [4, '09:00', '12:00', 60], [6, '13:00', '16:00', 60]],
            ],
        ];

        foreach ($doctors as $data) {
            $polyclinic = Polyclinic::where('slug', $data['polyclinic'])->firstOrFail();
            $schedules = $data['schedules'];
            unset($data['polyclinic'], $data['schedules']);
            $doctor = Doctor::updateOrCreate(
                ['slug' => $data['slug']],
                $data + ['polyclinic_id' => $polyclinic->id, 'practice_location' => 'Rumah Sakit BSI', 'is_active' => true]
            );

            $doctorNumber = match ($doctor->slug) {
                'dr-syifa-azzahra-spkj' => 1,
                'dr-andi-pratama-sppd' => 2,
                'dr-nabila-putri-spm' => 3,
                'dr-bima-saputra-spog' => 4,
                default => 9,
            };
            User::updateOrCreate(
                ['email' => 'dokter'.$doctorNumber.'@rumahsakit.test'],
                ['name' => $doctor->name, 'password' => Hash::make('password'), 'role' => 'doctor', 'doctor_id' => $doctor->id, 'is_admin' => false, 'is_active' => true]
            );

            foreach ($schedules as [$day, $start, $end, $duration]) {
                DoctorSchedule::firstOrCreate([
                    'doctor_id' => $doctor->id,
                    'day_of_week' => $day,
                    'start_time' => $start,
                    'end_time' => $end,
                ], [
                    'slot_duration_minutes' => $duration,
                    'is_active' => true,
                ]);
            }
        }
    }
}
