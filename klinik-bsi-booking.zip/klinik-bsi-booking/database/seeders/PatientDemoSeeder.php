<?php

namespace Database\Seeders;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class PatientDemoSeeder extends Seeder
{
    public function run(): void
    {
        $patients = [
            [
                'email' => 'pasien@rumahsakit.test', 'name' => 'Andi Pratama', 'phone' => '081234567890',
                'birth_place' => 'Jakarta', 'birth_date' => '1998-05-10', 'gender' => 'Laki-laki',
                'address' => 'Jl. Melati No. 10, Jakarta Timur', 'medical_history' => 'Riwayat maag ringan.',
                'allergies' => 'Tidak ada alergi yang diketahui.', 'current_medications' => 'Tidak ada.',
            ],
            [
                'email' => 'pasien2@rumahsakit.test', 'name' => 'Nadia Putri', 'phone' => '081298765432',
                'birth_place' => 'Bekasi', 'birth_date' => '2000-08-21', 'gender' => 'Perempuan',
                'address' => 'Jl. Anggrek No. 5, Bekasi', 'medical_history' => 'Tidak ada riwayat penyakit yang disampaikan.',
                'allergies' => 'Alergi debu.', 'current_medications' => 'Tidak ada.',
            ],
        ];

        $created = [];
        foreach ($patients as $index => $data) {
            $user = User::updateOrCreate(
                ['email' => $data['email']],
                ['name' => $data['name'], 'password' => Hash::make('password'), 'role' => 'patient', 'doctor_id' => null, 'is_admin' => false, 'is_active' => true]
            );
            $patient = Patient::updateOrCreate(
                ['user_id' => $user->id],
                [
                    'medical_record_number' => 'RMDEMO'.str_pad((string) ($index + 1), 4, '0', STR_PAD_LEFT),
                    'full_name' => $data['name'], 'birth_place' => $data['birth_place'], 'birth_date' => $data['birth_date'],
                    'gender' => $data['gender'], 'address' => $data['address'], 'phone' => $data['phone'],
                    'email' => $data['email'], 'religion' => 'Islam', 'marital_status' => 'Belum Menikah',
                    'education' => 'S1', 'medical_history' => $data['medical_history'], 'allergies' => $data['allergies'],
                    'current_medications' => $data['current_medications'],
                ]
            );
            $created[] = $patient;
        }

        // Booking contoh ditaruh pada dokter selain dokter yang dipakai test alur booking.
        $doctorAndi = Doctor::where('slug', 'dr-andi-pratama-sppd')->first();
        if ($doctorAndi) {
            $date = Carbon::now('Asia/Jakarta')->next(Carbon::WEDNESDAY)->toDateString();
            Appointment::updateOrCreate(
                ['booking_code' => 'BSIDEMO001'],
                [
                    'patient_id' => $created[0]->id, 'doctor_id' => $doctorAndi->id,
                    'polyclinic_id' => $doctorAndi->polyclinic_id, 'appointment_date' => $date,
                    'start_time' => '09:00:00', 'end_time' => '10:00:00', 'status' => 'pending',
                    'complaint' => 'Sering merasa tidak nyaman pada perut setelah makan.',
                    'symptoms' => 'Perut terasa perih dan kembung, terutama setelah makan pedas.',
                    'symptom_duration' => 'Sekitar dua minggu',
                ]
            );
        }

        $doctorNabila = Doctor::where('slug', 'dr-nabila-putri-spm')->first();
        if ($doctorNabila) {
            $date = Carbon::now('Asia/Jakarta')->next(Carbon::TUESDAY)->toDateString();
            Appointment::updateOrCreate(
                ['booking_code' => 'BSIDEMO002'],
                [
                    'patient_id' => $created[1]->id, 'doctor_id' => $doctorNabila->id,
                    'polyclinic_id' => $doctorNabila->polyclinic_id, 'appointment_date' => $date,
                    'start_time' => '08:00:00', 'end_time' => '09:00:00', 'status' => 'confirmed',
                    'complaint' => 'Pandangan mata terkadang terasa buram saat membaca.',
                    'symptoms' => 'Mata terasa cepat lelah setelah melihat layar dalam waktu lama.',
                    'symptom_duration' => 'Sekitar satu bulan', 'confirmed_at' => now(),
                ]
            );
        }
    }
}
