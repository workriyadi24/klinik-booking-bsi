<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('role', 20)->default('patient')->index();
            $table->string('google_id')->nullable()->unique();
            $table->unsignedBigInteger('doctor_id')->nullable()->unique();
        });

        Schema::table('patients', function (Blueprint $table) {
            $table->unsignedBigInteger('user_id')->nullable()->unique();
            $table->text('medical_history')->nullable();
            $table->text('allergies')->nullable();
            $table->text('current_medications')->nullable();
        });

        // SQLite cannot add foreign-key constraints to an existing table.
        // Keep unique nullable relationship columns for SQLite tests; enforce DB-level
        // referential integrity on MySQL/PostgreSQL production databases.
        if (Schema::getConnection()->getDriverName() !== 'sqlite') {
            Schema::table('users', function (Blueprint $table) {
                $table->foreign('doctor_id')->references('id')->on('doctors')->nullOnDelete();
            });
            Schema::table('patients', function (Blueprint $table) {
                $table->foreign('user_id')->references('id')->on('users')->nullOnDelete();
            });
        }

        Schema::table('appointments', function (Blueprint $table) {
            $table->text('symptoms')->nullable();
            $table->string('symptom_duration', 120)->nullable();
            $table->text('diagnosis')->nullable();
            $table->text('medical_notes')->nullable();
        });
    }

    public function down(): void
    {
        if (Schema::getConnection()->getDriverName() !== 'sqlite') {
            Schema::table('patients', function (Blueprint $table) {
                $table->dropForeign(['user_id']);
            });
            Schema::table('users', function (Blueprint $table) {
                $table->dropForeign(['doctor_id']);
            });
        }

        Schema::table('appointments', function (Blueprint $table) {
            $table->dropColumn(['symptoms', 'symptom_duration', 'diagnosis', 'medical_notes']);
        });

        Schema::table('patients', function (Blueprint $table) {
            $table->dropUnique(['user_id']);
            $table->dropColumn(['user_id', 'medical_history', 'allergies', 'current_medications']);
        });

        Schema::table('users', function (Blueprint $table) {
            $table->dropUnique(['doctor_id']);
            $table->dropUnique(['google_id']);
            $table->dropIndex(['role']);
            $table->dropColumn(['role', 'google_id', 'doctor_id']);
        });
    }
};
