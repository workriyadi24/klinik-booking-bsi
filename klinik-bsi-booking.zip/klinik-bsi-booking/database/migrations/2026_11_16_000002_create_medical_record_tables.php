<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('medical_records', function (Blueprint $table) {
            $table->id();
            $table->string('record_number', 48)->unique();
            $table->foreignId('appointment_id')->unique()->constrained()->restrictOnDelete();
            $table->foreignId('patient_id')->constrained()->restrictOnDelete();
            $table->foreignId('doctor_id')->constrained()->restrictOnDelete();
            $table->foreignId('polyclinic_id')->constrained()->restrictOnDelete();
            $table->longText('patient_allergies_snapshot')->nullable();
            $table->longText('patient_medical_history_snapshot')->nullable();
            $table->longText('patient_current_medications_snapshot')->nullable();
            $table->date('encounter_date');
            $table->time('encounter_time')->nullable();
            $table->longText('subjective')->nullable();
            $table->longText('objective')->nullable();
            $table->string('blood_pressure', 24)->nullable();
            $table->decimal('temperature_celsius', 4, 1)->nullable();
            $table->unsignedSmallInteger('heart_rate_bpm')->nullable();
            $table->unsignedSmallInteger('respiratory_rate_per_minute')->nullable();
            $table->decimal('weight_kg', 5, 2)->nullable();
            $table->decimal('height_cm', 5, 2)->nullable();
            $table->unsignedTinyInteger('oxygen_saturation_percent')->nullable();
            $table->longText('assessment')->nullable();
            $table->longText('plan')->nullable();
            $table->longText('procedures')->nullable();
            $table->date('follow_up_date')->nullable();
            $table->text('follow_up_notes')->nullable();
            $table->string('status', 16)->default('draft')->index();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('finalized_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('finalized_at')->nullable();
            $table->timestamps();
            $table->index(['patient_id', 'encounter_date']);
            $table->index(['doctor_id', 'encounter_date']);
        });

        Schema::create('prescriptions', function (Blueprint $table) {
            $table->id();
            $table->string('prescription_number', 48)->unique();
            $table->foreignId('medical_record_id')->unique()->constrained()->cascadeOnDelete();
            $table->text('instructions')->nullable();
            $table->string('status', 16)->default('draft')->index();
            $table->timestamp('issued_at')->nullable();
            $table->timestamps();
        });

        Schema::create('prescription_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('prescription_id')->constrained()->cascadeOnDelete();
            $table->string('medicine_name', 180);
            $table->string('strength', 100)->nullable();
            $table->string('dosage', 120)->nullable();
            $table->string('frequency', 120)->nullable();
            $table->string('duration', 120)->nullable();
            $table->string('quantity', 80)->nullable();
            $table->text('item_instructions')->nullable();
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->timestamps();
            $table->index(['prescription_id', 'sort_order']);
        });

        Schema::create('medical_record_addenda', function (Blueprint $table) {
            $table->id();
            $table->foreignId('medical_record_id')->constrained()->cascadeOnDelete();
            $table->foreignId('doctor_id')->constrained()->restrictOnDelete();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->longText('content');
            $table->timestamps();
            $table->index(['medical_record_id', 'created_at']);
        });

        Schema::create('medical_record_audits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('medical_record_id')->constrained()->cascadeOnDelete();
            $table->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('action', 40);
            $table->json('details')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->string('user_agent', 512)->nullable();
            $table->timestamps();
            $table->index(['medical_record_id', 'created_at']);
            $table->index(['actor_user_id', 'action']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('medical_record_audits');
        Schema::dropIfExists('medical_record_addenda');
        Schema::dropIfExists('prescription_items');
        Schema::dropIfExists('prescriptions');
        Schema::dropIfExists('medical_records');
    }
};
