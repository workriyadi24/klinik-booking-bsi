<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('doctors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('polyclinic_id')->constrained()->restrictOnDelete();
            $table->string('name', 160);
            $table->string('slug', 180)->unique();
            $table->string('title', 100)->nullable();
            $table->string('speciality', 120);
            $table->string('photo_path')->nullable();
            $table->unsignedSmallInteger('experience_years')->default(0);
            $table->decimal('rating', 2, 1)->default(5.0);
            $table->unsignedInteger('rating_count')->default(0);
            $table->string('practice_location', 160)->default('Rumah Sakit BSI');
            $table->text('bio')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index(['polyclinic_id', 'is_active']);
            $table->index(['name', 'speciality']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('doctors');
    }
};
