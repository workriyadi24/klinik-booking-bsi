<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->id();
            $table->string('medical_record_number', 24)->nullable()->unique();
            $table->string('full_name', 160);
            $table->string('birth_place', 100);
            $table->date('birth_date');
            $table->string('gender', 20);
            $table->text('address');
            $table->string('religion', 40)->nullable();
            $table->string('family_card_number', 32)->nullable()->index();
            $table->string('marital_status', 40)->nullable();
            $table->string('education', 60)->nullable();
            $table->string('phone', 24)->index();
            $table->string('email')->nullable()->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('patients');
    }
};
