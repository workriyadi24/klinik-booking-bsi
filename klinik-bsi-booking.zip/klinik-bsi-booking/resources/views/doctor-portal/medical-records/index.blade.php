@extends('layouts.doctor-portal')
@section('title', 'Rekam Medis Pasien')
@section('page-heading', 'Rekam Medis')
@section('content')
<div class="admin-page-heading"><div><span class="eyebrow">DOKUMENTASI KLINIS</span><h1>Rekam Medis Pasien</h1><p>Catatan pemeriksaan yang berada dalam kewenangan praktik Anda.</p></div></div>
<section class="admin-panel">
    <form class="admin-filter-form" method="GET" action="{{ route('doctor-portal.medical-records.index') }}">
        <label><span>Cari rekam medis, pasien, atau nomor RM</span><input class="form-control" type="search" name="q" value="{{ request('q') }}" placeholder="Contoh: RME-... atau nama pasien"></label>
        <label><span>Status</span><select class="form-control" name="status"><option value="">Semua status</option><option value="draft" @selected(request('status')==='draft')>Draf</option><option value="finalized" @selected(request('status')==='finalized')>Disahkan</option></select></label>
        <button class="btn btn-primary" type="submit">Terapkan</button>
        @if(request()->query())<a class="btn btn-outline" href="{{ route('doctor-portal.medical-records.index') }}">Reset</a>@endif
    </form>
    <div class="table-scroll"><table class="admin-table"><thead><tr><th>No. Rekam Medis</th><th>Pasien</th><th>Tanggal</th><th>Poliklinik</th><th>Status</th><th></th></tr></thead><tbody>
    @forelse($records as $record)
        <tr><td><strong>{{ $record->record_number }}</strong><small>{{ $record->appointment->booking_code }}</small></td><td><strong>{{ $record->patient->full_name }}</strong><small>{{ $record->patient->medical_record_number }}</small></td><td class="nowrap">{{ $record->encounter_date->format('d M Y') }}</td><td>{{ $record->polyclinic->name }}</td><td><span class="status-badge {{ $record->status_class }}">{{ $record->status_label }}</span></td><td><a class="table-action" href="{{ $record->isFinalized() ? route('doctor-portal.medical-records.show',$record) : route('doctor-portal.medical-records.edit',$record) }}">{{ $record->isFinalized() ? 'Lihat' : 'Lanjutkan draf' }}</a></td></tr>
    @empty
        <tr><td colspan="6"><div class="table-empty">Belum ada rekam medis. Rekam medis dibuat melalui detail janji temu setelah pemeriksaan dilakukan.</div></td></tr>
    @endforelse
    </tbody></table></div>
    @if($records->hasPages())<div class="admin-pagination">{{ $records->links() }}</div>@endif
</section>
@endsection
