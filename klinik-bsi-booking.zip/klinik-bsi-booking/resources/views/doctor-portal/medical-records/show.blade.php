@extends('layouts.doctor-portal')
@section('title', 'Rekam Medis '.$medicalRecord->record_number)
@section('page-heading', 'Detail Rekam Medis')
@section('content')
<div class="admin-page-heading"><div><a class="admin-back-link" href="{{ route('doctor-portal.medical-records.index') }}">← Kembali ke daftar rekam medis</a><h1>{{ $medicalRecord->record_number }}</h1><p>{{ $medicalRecord->patient->full_name }} · {{ $medicalRecord->encounter_date->locale('id')->translatedFormat('l, d F Y') }}</p></div><span class="status-badge success">Disahkan {{ $medicalRecord->finalized_at?->format('d M Y H:i') }}</span></div>
<div class="medical-record-guidance"><strong>Catatan final</strong><p>Isi utama rekam medis ini telah disahkan dan dikunci. Apabila terdapat koreksi atau informasi tambahan, gunakan addendum agar catatan awal tetap utuh.</p></div>
<div class="doctor-detail-grid">
    <section class="admin-panel"><div class="panel-heading"><div><h2>Identitas & Kunjungan</h2><p>Referensi pasien dan janji temu terkait.</p></div></div><div class="detail-admin-grid"><div><span>Nama pasien</span><strong>{{ $medicalRecord->patient->full_name }}</strong></div><div><span>Nomor RM</span><strong>{{ $medicalRecord->patient->medical_record_number }}</strong></div><div><span>Kode booking</span><strong>{{ $medicalRecord->appointment->booking_code }}</strong></div><div><span>Dokter</span><strong>{{ $medicalRecord->doctor->name }}</strong></div><div><span>Poliklinik</span><strong>{{ $medicalRecord->polyclinic->name }}</strong></div><div><span>Waktu kunjungan</span><strong>{{ $medicalRecord->encounter_time ? substr((string)$medicalRecord->encounter_time,0,5).' WIB' : '–' }}</strong></div><div><span>Jenis kelamin</span><strong>{{ $medicalRecord->patient->gender ?: '–' }}</strong></div><div><span>Tanggal lahir</span><strong>{{ $medicalRecord->patient->birth_date?->format('d M Y') ?: '–' }}</strong></div></div></section>
    <section class="admin-panel"><div class="panel-heading"><div><h2>Informasi Kesehatan Pasien</h2><p>Ringkasan informasi yang tersimpan pada profil pasien.</p></div></div><div class="medical-summary-list"><div><span>Alergi</span><p>{{ $medicalRecord->patient_allergies_snapshot ?? $medicalRecord->patient->allergies ?? 'Tidak dicatat' }}</p></div><div><span>Riwayat penyakit / operasi</span><p>{{ $medicalRecord->patient_medical_history_snapshot ?? $medicalRecord->patient->medical_history ?? 'Tidak dicatat' }}</p></div><div><span>Obat yang sedang dikonsumsi</span><p>{{ $medicalRecord->patient_current_medications_snapshot ?? $medicalRecord->patient->current_medications ?? 'Tidak dicatat' }}</p></div></div></section>
</div>
<section class="admin-panel medical-record-section"><div class="panel-heading"><div><h2>Anamnesis / Subjektif</h2></div></div><div class="medical-record-text">{{ $medicalRecord->subjective ?: 'Tidak dicatat.' }}</div></section>
<section class="admin-panel medical-record-section"><div class="panel-heading"><div><h2>Pemeriksaan Objektif & Tanda Vital</h2></div></div><div class="medical-vitals-display">
    @foreach(['Tekanan darah' => $medicalRecord->blood_pressure, 'Suhu' => $medicalRecord->temperature_celsius ? $medicalRecord->temperature_celsius.' °C' : null, 'Nadi' => $medicalRecord->heart_rate_bpm ? $medicalRecord->heart_rate_bpm.' kali/menit' : null, 'Pernapasan' => $medicalRecord->respiratory_rate_per_minute ? $medicalRecord->respiratory_rate_per_minute.' kali/menit' : null, 'Berat badan' => $medicalRecord->weight_kg ? $medicalRecord->weight_kg.' kg' : null, 'Tinggi badan' => $medicalRecord->height_cm ? $medicalRecord->height_cm.' cm' : null, 'SpO₂' => $medicalRecord->oxygen_saturation_percent ? $medicalRecord->oxygen_saturation_percent.'%' : null] as $label => $value)
        @if($value)<div><span>{{ $label }}</span><strong>{{ $value }}</strong></div>@endif
    @endforeach
</div><div class="medical-record-text">{{ $medicalRecord->objective ?: 'Tidak ada temuan objektif tambahan yang dicatat.' }}</div></section>
<div class="doctor-detail-grid">
    <section class="admin-panel medical-record-section"><div class="panel-heading"><div><h2>Asesmen / Diagnosis</h2></div></div><div class="medical-record-text">{{ $medicalRecord->assessment }}</div></section>
    <section class="admin-panel medical-record-section"><div class="panel-heading"><div><h2>Rencana Terapi</h2></div></div><div class="medical-record-text">{{ $medicalRecord->plan ?: 'Tidak dicatat.' }}</div></section>
</div>
<section class="admin-panel medical-record-section"><div class="panel-heading"><div><h2>Tindakan & Prosedur</h2></div></div><div class="medical-record-text">{{ $medicalRecord->procedures ?: 'Tidak ada tindakan yang dicatat.' }}</div></section>
<section class="admin-panel medical-record-section"><div class="panel-heading"><div><h2>Resep Obat</h2><p>{{ $medicalRecord->prescription?->prescription_number ?: 'Tidak ada resep pada kunjungan ini.' }}</p></div></div>
    @if($medicalRecord->prescription)<p class="medical-record-text">{{ $medicalRecord->prescription->instructions ?: 'Tidak ada catatan umum resep.' }}</p><div class="table-scroll"><table class="admin-table"><thead><tr><th>Obat</th><th>Dosis</th><th>Frekuensi</th><th>Durasi</th><th>Jumlah</th><th>Petunjuk</th></tr></thead><tbody>@foreach($medicalRecord->prescription->items as $item)<tr><td><strong>{{ $item->medicine_name }}</strong><small>{{ $item->strength }}</small></td><td>{{ $item->dosage ?: '–' }}</td><td>{{ $item->frequency ?: '–' }}</td><td>{{ $item->duration ?: '–' }}</td><td>{{ $item->quantity ?: '–' }}</td><td>{{ $item->item_instructions ?: '–' }}</td></tr>@endforeach</tbody></table></div>@else<p class="table-empty">Tidak ada obat yang diresepkan pada kunjungan ini.</p>@endif
</section>
<section class="admin-panel medical-record-section"><div class="panel-heading"><div><h2>Rencana Kontrol</h2></div></div><div class="detail-admin-grid"><div><span>Tanggal kontrol</span><strong>{{ $medicalRecord->follow_up_date?->format('d M Y') ?: 'Tidak dijadwalkan' }}</strong></div><div><span>Catatan</span><strong>{{ $medicalRecord->follow_up_notes ?: '–' }}</strong></div></div></section>
<section class="admin-panel medical-record-section"><div class="panel-heading"><div><h2>Addendum</h2><p>Catatan tambahan setelah pengesahan tanpa mengubah isi rekam medis final.</p></div></div>
    @forelse($medicalRecord->addenda as $addendum)<article class="medical-addendum"><div><strong>{{ $addendum->creator?->name ?: 'Tenaga medis' }}</strong><small>{{ $addendum->created_at->format('d M Y H:i') }}</small></div><p>{{ $addendum->content }}</p></article>@empty<p class="table-empty">Belum ada addendum.</p>@endforelse
    <form method="POST" action="{{ route('doctor-portal.medical-records.addendum',$medicalRecord) }}" class="medical-addendum-form">@csrf<label class="form-field"><span>Tambah addendum</span><textarea class="form-control" rows="3" name="content" maxlength="10000" required placeholder="Tuliskan koreksi atau informasi tambahan beserta konteksnya."></textarea></label><div class="form-actions"><button class="btn btn-primary" type="submit">Simpan Addendum</button></div></form>
</section>
@if($previousRecords->isNotEmpty())
<section class="admin-panel medical-record-section medical-history-context">
    <div class="panel-heading"><div><h2>Riwayat Kunjungan Sebelumnya</h2><p>Ringkasan lima kunjungan final terakhir pasien, termasuk dari poliklinik atau dokter lain. Akses ditampilkan dalam konteks perawatan dan tercatat pada audit log.</p></div></div>
    <div class="medical-history-timeline">
        @foreach($previousRecords as $previous)
            <article class="medical-history-item">
                <div class="medical-history-meta"><strong>{{ $previous->encounter_date->locale('id')->translatedFormat('d F Y') }}</strong><span>{{ $previous->doctor->name }}{{ $previous->doctor->title ? ', '.$previous->doctor->title : '' }} · {{ $previous->polyclinic->name }}</span></div>
                <div><b>Asesmen</b><p>{{ $previous->assessment ?: 'Tidak dicatat.' }}</p></div>
                @if($previous->subjective)<div><b>Keluhan / anamnesis</b><p>{{ \Illuminate\Support\Str::limit($previous->subjective, 360) }}</p></div>@endif
                @if($previous->plan)<div><b>Rencana sebelumnya</b><p>{{ \Illuminate\Support\Str::limit($previous->plan, 260) }}</p></div>@endif
            </article>
        @endforeach
    </div>
</section>
@endif
@endsection
