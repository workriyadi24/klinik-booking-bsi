@extends('layouts.doctor-portal')
@section('title', $medicalRecord->exists ? 'Edit Draf Rekam Medis' : 'Buat Rekam Medis')
@section('page-heading', 'Dokumentasi Pemeriksaan')
@section('content')
@php
    $savedItems = $medicalRecord->prescription?->items?->map(fn($item) => [
        'medicine_name' => $item->medicine_name, 'strength' => $item->strength, 'dosage' => $item->dosage,
        'frequency' => $item->frequency, 'duration' => $item->duration, 'quantity' => $item->quantity,
        'item_instructions' => $item->item_instructions,
    ])->values()->all() ?? [];
    $prescriptionRows = old('prescriptions', $savedItems ?: [['medicine_name'=>'','strength'=>'','dosage'=>'','frequency'=>'','duration'=>'','quantity'=>'','item_instructions'=>'']]);
@endphp
<div class="admin-page-heading"><div><a class="admin-back-link" href="{{ route('doctor-portal.appointments.show',$appointment) }}">← Kembali ke detail janji temu</a><h1>{{ $medicalRecord->exists ? 'Lanjutkan Draf Rekam Medis' : 'Buat Rekam Medis' }}</h1><p>Pasien <strong>{{ $appointment->patient->full_name }}</strong> · {{ $appointment->appointment_date->format('d M Y') }} · {{ $appointment->booking_code }}</p></div><span class="status-badge warning">Draf</span></div>
<div class="medical-record-guidance"><strong>Dokumentasi klinis</strong><p>Isi berdasarkan wawancara dan temuan pemeriksaan yang benar-benar dilakukan. Pastikan identitas pasien dan tanggal kunjungan sesuai sebelum mengesahkan catatan.</p></div>
@if($patientHistory->isNotEmpty())
<section class="admin-panel medical-history-context">
    <div class="panel-heading"><div><h2>Riwayat Kunjungan Sebelumnya</h2><p>Ringkasan rekam medis final pasien dari kunjungan sebelumnya, termasuk dokter lain. Gunakan sebagai konteks dan tetap lakukan asesmen terbaru.</p></div><span class="status-badge info">{{ $patientHistory->count() }} kunjungan</span></div>
    <div class="medical-history-timeline">
        @foreach($patientHistory as $historyRecord)
            <article class="medical-history-item">
                <div class="medical-history-meta"><strong>{{ $historyRecord->encounter_date->locale('id')->translatedFormat('d F Y') }}</strong><span>{{ $historyRecord->doctor->name }}{{ $historyRecord->doctor->title ? ', '.$historyRecord->doctor->title : '' }} · {{ $historyRecord->polyclinic->name }}</span></div>
                <div><b>Asesmen sebelumnya</b><p>{{ $historyRecord->assessment ?: 'Tidak dicatat.' }}</p></div>
                @if($historyRecord->subjective)<div><b>Keluhan / anamnesis</b><p>{{ \Illuminate\Support\Str::limit($historyRecord->subjective, 360) }}</p></div>@endif
                @if($historyRecord->plan)<div><b>Rencana sebelumnya</b><p>{{ \Illuminate\Support\Str::limit($historyRecord->plan, 260) }}</p></div>@endif
            </article>
        @endforeach
    </div>
</section>
@endif
<form method="POST" action="{{ $medicalRecord->exists ? route('doctor-portal.medical-records.update',$medicalRecord) : route('doctor-portal.medical-records.store',$appointment) }}" class="medical-record-form">
    @csrf
    @if($medicalRecord->exists) @method('PUT') @endif
    <section class="admin-panel medical-form-section"><div class="panel-heading"><div><h2>1. Anamnesis / Data Subjektif</h2><p>Informasi yang disampaikan pasien saat pemeriksaan.</p></div></div>
        <label class="form-field"><span>Keluhan, riwayat keluhan, dan informasi relevan</span><textarea class="form-control" rows="6" name="subjective" maxlength="20000" placeholder="Tuliskan keluhan, awal munculnya keluhan, lokasi, karakteristik, faktor pemicu/peringan, dan informasi relevan lainnya.">{{ old('subjective',$medicalRecord->subjective) }}</textarea></label>
    </section>
    <section class="admin-panel medical-form-section"><div class="panel-heading"><div><h2>2. Pemeriksaan Objektif</h2><p>Temuan pemeriksaan fisik dan tanda-tanda vital. Isi hanya data yang benar-benar diukur.</p></div></div>
        <div class="medical-vitals-grid">
            <label class="form-field"><span>Tekanan darah</span><input class="form-control" name="blood_pressure" value="{{ old('blood_pressure',$medicalRecord->blood_pressure) }}" maxlength="24" placeholder="Contoh: 120/80 mmHg"></label>
            <label class="form-field"><span>Suhu (°C)</span><input class="form-control" type="number" step="0.1" min="25" max="45" name="temperature_celsius" value="{{ old('temperature_celsius',$medicalRecord->temperature_celsius) }}" placeholder="36.5"></label>
            <label class="form-field"><span>Nadi (kali/menit)</span><input class="form-control" type="number" min="20" max="250" name="heart_rate_bpm" value="{{ old('heart_rate_bpm',$medicalRecord->heart_rate_bpm) }}"></label>
            <label class="form-field"><span>Pernapasan (kali/menit)</span><input class="form-control" type="number" min="4" max="80" name="respiratory_rate_per_minute" value="{{ old('respiratory_rate_per_minute',$medicalRecord->respiratory_rate_per_minute) }}"></label>
            <label class="form-field"><span>Berat badan (kg)</span><input class="form-control" type="number" step="0.01" min="0.1" max="500" name="weight_kg" value="{{ old('weight_kg',$medicalRecord->weight_kg) }}"></label>
            <label class="form-field"><span>Tinggi badan (cm)</span><input class="form-control" type="number" step="0.01" min="20" max="260" name="height_cm" value="{{ old('height_cm',$medicalRecord->height_cm) }}"></label>
            <label class="form-field"><span>SpO₂ (%)</span><input class="form-control" type="number" min="1" max="100" name="oxygen_saturation_percent" value="{{ old('oxygen_saturation_percent',$medicalRecord->oxygen_saturation_percent) }}"></label>
        </div>
        <label class="form-field"><span>Hasil pemeriksaan fisik / objektif</span><textarea class="form-control" rows="5" name="objective" maxlength="20000" placeholder="Tuliskan temuan pemeriksaan yang relevan.">{{ old('objective',$medicalRecord->objective) }}</textarea></label>
    </section>
    <section class="admin-panel medical-form-section"><div class="panel-heading"><div><h2>3. Asesmen dan Rencana</h2><p>Bagian ini wajib memiliki diagnosis/asesmen sebelum catatan difinalisasi.</p></div></div>
        <label class="form-field"><span>Diagnosis / Asesmen <b>*</b></span><textarea class="form-control" rows="4" name="assessment" maxlength="20000" placeholder="Tuliskan diagnosis atau asesmen klinis berdasarkan hasil pemeriksaan.">{{ old('assessment',$medicalRecord->assessment) }}</textarea></label>
        <label class="form-field"><span>Rencana terapi / tindak lanjut</span><textarea class="form-control" rows="4" name="plan" maxlength="20000" placeholder="Tuliskan rencana terapi, edukasi, atau pemantauan.">{{ old('plan',$medicalRecord->plan) }}</textarea></label>
        <label class="form-field"><span>Tindakan / prosedur yang dilakukan</span><textarea class="form-control" rows="3" name="procedures" maxlength="20000" placeholder="Tuliskan tindakan yang benar-benar dilakukan, bila ada.">{{ old('procedures',$medicalRecord->procedures) }}</textarea></label>
    </section>
    <section class="admin-panel medical-form-section"><div class="panel-heading"><div><h2>4. Resep Obat</h2><p>Tambahkan obat bila diresepkan. Jangan mengisi obat bila tidak ada resep.</p></div><button type="button" class="btn btn-outline btn-small" data-add-prescription>+ Tambah obat</button></div>
        <div class="prescription-rows" data-prescription-rows>
            @foreach($prescriptionRows as $index => $item)
                <div class="prescription-row" data-prescription-row>
                    <div class="prescription-row-heading"><strong>Obat <span data-row-number>{{ $index + 1 }}</span></strong><button type="button" class="text-remove" data-remove-prescription>Hapus</button></div>
                    <div class="medical-vitals-grid">
                        <label class="form-field"><span>Nama obat</span><input class="form-control" name="prescriptions[{{ $index }}][medicine_name]" value="{{ $item['medicine_name'] ?? '' }}" maxlength="180" placeholder="Nama obat"></label>
                        <label class="form-field"><span>Kekuatan</span><input class="form-control" name="prescriptions[{{ $index }}][strength]" value="{{ $item['strength'] ?? '' }}" maxlength="100" placeholder="Contoh: 500 mg"></label>
                        <label class="form-field"><span>Dosis</span><input class="form-control" name="prescriptions[{{ $index }}][dosage]" value="{{ $item['dosage'] ?? '' }}" maxlength="120" placeholder="Contoh: 1 tablet"></label>
                        <label class="form-field"><span>Frekuensi</span><input class="form-control" name="prescriptions[{{ $index }}][frequency]" value="{{ $item['frequency'] ?? '' }}" maxlength="120" placeholder="Contoh: 3 kali sehari"></label>
                        <label class="form-field"><span>Durasi</span><input class="form-control" name="prescriptions[{{ $index }}][duration]" value="{{ $item['duration'] ?? '' }}" maxlength="120" placeholder="Contoh: 5 hari"></label>
                        <label class="form-field"><span>Jumlah</span><input class="form-control" name="prescriptions[{{ $index }}][quantity]" value="{{ $item['quantity'] ?? '' }}" maxlength="80" placeholder="Contoh: 15 tablet"></label>
                        <label class="form-field full-width"><span>Petunjuk khusus</span><input class="form-control" name="prescriptions[{{ $index }}][item_instructions]" value="{{ $item['item_instructions'] ?? '' }}" maxlength="1000" placeholder="Contoh: sesudah makan"></label>
                    </div>
                </div>
            @endforeach
        </div>
        <label class="form-field"><span>Catatan umum resep</span><textarea class="form-control" rows="2" name="prescription_instructions" maxlength="5000" placeholder="Petunjuk umum penggunaan resep.">{{ old('prescription_instructions',$medicalRecord->prescription?->instructions) }}</textarea></label>
    </section>
    <section class="admin-panel medical-form-section"><div class="panel-heading"><div><h2>5. Rencana Kontrol</h2><p>Isi bila pasien perlu datang kembali.</p></div></div>
        <div class="admin-form-grid"><label class="form-field"><span>Tanggal kontrol</span><input class="form-control" type="date" name="follow_up_date" min="{{ now('Asia/Jakarta')->toDateString() }}" value="{{ old('follow_up_date',$medicalRecord->follow_up_date?->format('Y-m-d')) }}"></label><label class="form-field"><span>Catatan kontrol</span><input class="form-control" name="follow_up_notes" maxlength="5000" value="{{ old('follow_up_notes',$medicalRecord->follow_up_notes) }}" placeholder="Contoh: kontrol setelah 7 hari"></label></div>
    </section>
    <div class="medical-record-submit"><div><strong>Periksa kembali isi catatan.</strong><small>Draf dapat diedit. Setelah disahkan, data inti terkunci dan koreksi dilakukan melalui addendum.</small></div><div class="heading-actions"><button class="btn btn-outline" type="submit" name="action" value="draft">Simpan Draf</button><button class="btn btn-primary" type="submit" name="action" value="finalize" data-finalize-confirm>Sahkan Rekam Medis</button></div></div>
</form>
<template id="prescription-row-template">
    <div class="prescription-row" data-prescription-row><div class="prescription-row-heading"><strong>Obat <span data-row-number></span></strong><button type="button" class="text-remove" data-remove-prescription>Hapus</button></div><div class="medical-vitals-grid">
        <label class="form-field"><span>Nama obat</span><input class="form-control" data-field="medicine_name" maxlength="180" placeholder="Nama obat"></label>
        <label class="form-field"><span>Kekuatan</span><input class="form-control" data-field="strength" maxlength="100" placeholder="Contoh: 500 mg"></label>
        <label class="form-field"><span>Dosis</span><input class="form-control" data-field="dosage" maxlength="120" placeholder="Contoh: 1 tablet"></label>
        <label class="form-field"><span>Frekuensi</span><input class="form-control" data-field="frequency" maxlength="120" placeholder="Contoh: 3 kali sehari"></label>
        <label class="form-field"><span>Durasi</span><input class="form-control" data-field="duration" maxlength="120" placeholder="Contoh: 5 hari"></label>
        <label class="form-field"><span>Jumlah</span><input class="form-control" data-field="quantity" maxlength="80" placeholder="Contoh: 15 tablet"></label>
        <label class="form-field full-width"><span>Petunjuk khusus</span><input class="form-control" data-field="item_instructions" maxlength="1000" placeholder="Contoh: sesudah makan"></label>
    </div></div>
</template>
@endsection
@push('scripts')
<script>
(() => {
    const rows = document.querySelector('[data-prescription-rows]');
    const template = document.getElementById('prescription-row-template');
    const addButton = document.querySelector('[data-add-prescription]');
    if (!rows || !template || !addButton) return;
    const renumber = () => {
        [...rows.querySelectorAll('[data-prescription-row]')].forEach((row, index) => {
            row.querySelector('[data-row-number]').textContent = index + 1;
            row.querySelectorAll('[data-field]').forEach((input) => input.name = `prescriptions[${index}][${input.dataset.field}]`);
            row.querySelectorAll('input[name^="prescriptions["]').forEach((input) => {
                if (!input.dataset.field) input.name = input.name.replace(/prescriptions\[\d+\]/, `prescriptions[${index}]`);
            });
        });
    };
    addButton.addEventListener('click', () => {
        if (rows.querySelectorAll('[data-prescription-row]').length >= 10) return alert('Maksimal 10 item obat dalam satu resep.');
        rows.append(template.content.cloneNode(true));
        renumber();
    });
    rows.addEventListener('click', (event) => {
        const button = event.target.closest('[data-remove-prescription]');
        if (!button) return;
        const row = button.closest('[data-prescription-row]');
        if (rows.querySelectorAll('[data-prescription-row]').length === 1) {
            row.querySelectorAll('input').forEach((input) => input.value = '');
        } else row.remove();
        renumber();
    });
    renumber();
    const form = document.querySelector('.medical-record-form');
    const finalizeButton = document.querySelector('[data-finalize-confirm]');
    if (form && finalizeButton) {
        form.addEventListener('submit', (event) => {
            if (event.submitter !== finalizeButton) return;
            if (form.dataset.finalizeConfirmed === '1') {
                delete form.dataset.finalizeConfirmed;
                return;
            }
            event.preventDefault();
            const submit = () => {
                form.dataset.finalizeConfirmed = '1';
                form.requestSubmit(finalizeButton);
            };
            if (window.Swal) {
                window.Swal.fire({
                    icon: 'warning',
                    title: 'Sahkan rekam medis?',
                    text: 'Catatan inti akan dikunci dan status janji temu berubah menjadi selesai. Koreksi berikutnya dicatat melalui addendum.',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, sahkan',
                    cancelButtonText: 'Periksa kembali',
                    confirmButtonColor: '#20ad70',
                }).then((result) => { if (result.isConfirmed) submit(); });
            } else if (window.confirm('Sahkan rekam medis? Catatan inti akan dikunci dan janji temu menjadi selesai.')) {
                submit();
            }
        });
    }
})();
</script>
@endpush
