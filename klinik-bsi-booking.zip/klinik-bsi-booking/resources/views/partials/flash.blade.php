@if (session('success'))
    <div class="container flash-wrap"><div class="alert alert-success" role="status"><span>✓</span>{{ session('success') }}<button type="button" data-dismiss-alert aria-label="Tutup">×</button></div></div>
@endif
@if (session('info'))
    <div class="container flash-wrap"><div class="alert alert-info" role="status"><span>ⓘ</span>{{ session('info') }}<button type="button" data-dismiss-alert aria-label="Tutup">×</button></div></div>
@endif
@if (session('warning'))
    <div class="container flash-wrap"><div class="alert alert-warning" role="alert"><span>!</span>{{ session('warning') }}<button type="button" data-dismiss-alert aria-label="Tutup">×</button></div></div>
@endif
@if ($errors->any())
    <div class="container flash-wrap"><div class="alert alert-danger" role="alert"><span>!</span><div><strong>Periksa kembali data Anda.</strong><ul>@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div><button type="button" data-dismiss-alert aria-label="Tutup">×</button></div></div>
@endif
