
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Login Admin · Rumah Sakit BSI</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>

<body class="login-body">

    <div class="login-layout">

        <!-- Login Visual -->
        <div class="login-visual">

            <div class="login-brand">
                <span class="brand-mark">＋</span>

                <span>
                    <strong>RUMAH SAKIT BSI</strong>
                    <small>HEALTHCARE & APPOINTMENT</small>
                </span>
            </div>

            <div class="login-visual-copy">

                <span class="eyebrow">ADMINISTRATOR AREA</span>

                <h1>
                    Kelola layanan
                    <br>
                    <span>lebih teratur.</span>
                </h1>

                <p>
                    Pantau pendaftaran pasien, atur jadwal dokter,
                    dan kelola informasi poliklinik melalui satu dashboard.
                </p>

            </div>

            <img
                src="{{ asset('images/hero-medical-team.jpg') }}"
                alt="Tim medis"
            >

        </div>


        <!-- Login Form -->
        <div class="login-form-side">

            <form
                class="login-card"
                method="POST"
                action="{{ route('admin.login.submit') }}"
            >

                @csrf

                <div class="login-card-mark">
                    ＋
                </div>

                <span class="eyebrow">
                    SELAMAT DATANG
                </span>

                <h2>Login Admin</h2>

                <p>
                    Masuk menggunakan akun administrator Anda.
                </p>


                {{-- Pesan peringatan --}}
                @if (session('warning'))
                    <div class="inline-message">
                        {{ session('warning') }}
                    </div>
                @endif


                {{-- Pesan kesalahan validasi --}}
                @if ($errors->any())
                    <div class="inline-error">
                        {{ $errors->first() }}
                    </div>
                @endif


                <!-- Email -->
                <label class="form-field">

                    <span>Email Admin</span>

                    <input
                        class="form-control"
                        type="email"
                        name="email"
                        value="{{ old('email') }}"
                        placeholder="admin@rumahsakit.test"
                        autocomplete="username"
                        required
                        autofocus
                    >

                </label>


                <!-- Password -->
                <label class="form-field">

                    <span>Password</span>

                    <input
                        class="form-control"
                        type="password"
                        name="password"
                        placeholder="Masukkan password"
                        autocomplete="current-password"
                        required
                    >

                </label>


                <!-- Remember Me -->
                <label class="check-field remember-field">

                    <input
                        type="checkbox"
                        name="remember"
                        value="1"
                    >

                    <span>Ingat saya</span>

                </label>


                <!-- Submit -->
                <button
                    class="btn btn-primary btn-block btn-large"
                    type="submit"
                >
                    Masuk Dashboard
                    <span>→</span>
                </button>


                <!-- Back to Home -->
                <a
                    class="login-back-link"
                    href="{{ route('home') }}"
                >
                    ← Kembali ke halaman pasien
                </a>

            </form>


            <small class="login-copyright">
                © {{ date('Y') }} Rumah Sakit BSI
            </small>

        </div>

    </div>

</body>

</html>
