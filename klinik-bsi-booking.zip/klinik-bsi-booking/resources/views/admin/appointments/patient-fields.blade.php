<div class="admin-form-grid">
    <label class="form-field"><span>Nama Pasien <b>*</b></span><input class="form-control" name="full_name" value="{{ old('full_name',$patient->full_name) }}" required maxlength="160"></label>
    <label class="form-field"><span>No. Telepon <b>*</b></span><input class="form-control" name="phone" value="{{ old('phone',$patient->phone) }}" required maxlength="24"></label>
    <label class="form-field"><span>Tempat Lahir <b>*</b></span><input class="form-control" name="birth_place" value="{{ old('birth_place',$patient->birth_place) }}" required maxlength="100"></label>
    <label class="form-field"><span>Tanggal Lahir <b>*</b></span><input class="form-control" type="date" name="birth_date" value="{{ old('birth_date',$patient->birth_date?->toDateString()) }}" max="{{ now()->subDay()->toDateString() }}" required></label>
    <label class="form-field"><span>Jenis Kelamin <b>*</b></span><select class="form-control" name="gender" required><option value="Laki-laki" @selected(old('gender',$patient->gender)==='Laki-laki')>Laki-laki</option><option value="Perempuan" @selected(old('gender',$patient->gender)==='Perempuan')>Perempuan</option></select></label>
    <label class="form-field"><span>No. Kartu Keluarga</span><input class="form-control" name="family_card_number" value="{{ old('family_card_number',$patient->family_card_number) }}" maxlength="16"></label>
    <label class="form-field"><span>Agama</span><input class="form-control" name="religion" value="{{ old('religion',$patient->religion) }}" maxlength="40"></label>
    <label class="form-field"><span>Status Perkawinan</span><select class="form-control" name="marital_status"><option value="">Pilih status</option>@foreach(['Belum Menikah','Menikah','Cerai Hidup','Cerai Mati'] as $v)<option @selected(old('marital_status',$patient->marital_status)===$v)>{{ $v }}</option>@endforeach</select></label>
    <label class="form-field"><span>Pendidikan</span><select class="form-control" name="education"><option value="">Pilih pendidikan</option>@foreach(['SD','SMP','SMA/SMK','Diploma','S1','S2','S3','Lainnya'] as $v)<option @selected(old('education',$patient->education)===$v)>{{ $v }}</option>@endforeach</select></label>
    <label class="form-field"><span>Email</span><input class="form-control" type="email" name="email" value="{{ old('email',$patient->email) }}"></label>
    <label class="form-field full-width"><span>Alamat Lengkap <b>*</b></span><textarea class="form-control" rows="3" name="address" required>{{ old('address',$patient->address) }}</textarea></label>
</div>
