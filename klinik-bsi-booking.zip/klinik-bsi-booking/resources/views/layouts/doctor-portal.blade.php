<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Portal Dokter') · Rumah Sakit BSI</title>
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}"><link rel="stylesheet" href="{{ asset('css/admin.css') }}"><link rel="stylesheet" href="{{ asset('css/portal.css') }}">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-sidebar doctor-sidebar" data-admin-sidebar>
        <a class="admin-brand" href="{{ route('doctor-portal.dashboard') }}"><span class="brand-mark">＋</span><span><strong>RS BSI</strong><small>DOCTOR PORTAL</small></span></a>
        <div class="sidebar-caption">RUANG PRAKTIK</div>
        <nav class="sidebar-nav"><a href="{{ route('doctor-portal.dashboard') }}" class="{{ request()->routeIs('doctor-portal.dashboard') ? 'active' : '' }}"><span>▦</span>Ringkasan</a><a href="{{ route('doctor-portal.dashboard') }}#jadwal"><span>▣</span>Jadwal Pasien</a><a href="{{ route('doctor-portal.medical-records.index') }}" class="{{ request()->routeIs('doctor-portal.medical-records.*') ? 'active' : '' }}"><span>▤</span>Rekam Medis</a></nav>
        <div class="sidebar-bottom"><div class="sidebar-user"><span class="admin-avatar">{{ strtoupper(substr(auth()->user()->name,0,1)) }}</span><div><strong>{{ auth()->user()->name }}</strong><small>Dokter · {{ auth()->user()->doctor?->speciality }}</small></div></div><form method="POST" action="{{ route('doctor-portal.logout') }}">@csrf<button class="sidebar-logout" type="submit"><span>↪</span> Keluar</button></form><a href="{{ route('home') }}" class="sidebar-public-link">Buka halaman pasien ↗</a></div>
    </aside>
    <div class="admin-main-wrap"><header class="admin-topbar"><button class="sidebar-toggle" type="button" data-admin-toggle aria-label="Buka navigasi">☰</button><div><span class="topbar-overline">PORTAL DOKTER</span><strong>@yield('page-heading', 'Dashboard')</strong></div><div class="topbar-right"><span class="admin-live-dot"></span><span>Ruang Praktik</span><span class="topbar-date">{{ now('Asia/Jakarta')->format('d M Y') }}</span></div></header>
        <main class="admin-content">@if(session('success'))<div class="admin-alert success"><span>✓</span>{{ session('success') }}<button type="button" data-dismiss-alert>×</button></div>@endif @if(session('warning'))<div class="admin-alert warning"><span>!</span>{{ session('warning') }}<button type="button" data-dismiss-alert>×</button></div>@endif @if($errors->any())<div class="admin-alert danger"><span>!</span><div><strong>Periksa kembali input berikut:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div><button type="button" data-dismiss-alert>×</button></div>@endif @yield('content')</main>
    </div>
</div>@if(request()->routeIs('doctor-portal.medical-records.*'))<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11" defer></script>@endif<script src="{{ asset('js/app.js') }}" defer></script>
@stack('scripts')
</body></html>
