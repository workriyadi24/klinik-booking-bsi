<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="Informasi jadwal dokter dan pendaftaran janji temu Rumah Sakit BSI.">
    <title>@yield('title', 'Rumah Sakit BSI') - Rumah Sakit BSI</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    @if(request()->routeIs('patient.*') || request()->routeIs('doctor-portal.login'))<link rel="stylesheet" href="{{ asset('css/admin.css') }}">@endif
    <link rel="stylesheet" href="{{ asset('css/portal.css') }}">
    @stack('styles')
</head>
<body class="public-body">
    <div class="top-strip"><div class="container top-strip-inner"><span>PENDAFTARAN RUMAH SAKIT BSI</span><span><i class="dot-live"></i> Layanan informasi & pendaftaran online</span></div></div>
    <header class="site-header">
        <div class="container nav-inner">
            <a class="brand" href="{{ route('home') }}" aria-label="Rumah Sakit BSI Beranda">
                <span class="brand-mark">＋</span>
                <span class="brand-text"><strong>RUMAH SAKIT</strong><small>BSI · HEALTHCARE</small></span>
            </a>
            <button class="nav-toggle" type="button" aria-label="Buka menu" aria-expanded="false" data-nav-toggle><span></span><span></span><span></span></button>
            <nav class="main-nav" data-nav-menu>
                <a class="{{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}">Beranda</a>
                <a class="{{ request()->routeIs('doctors.*') ? 'active' : '' }}" href="{{ route('doctors.index') }}">Dokter</a>
                <a class="{{ request()->routeIs('information') ? 'active' : '' }}" href="{{ route('information') }}">Informasi</a>
                <a class="{{ request()->routeIs('contact') ? 'active' : '' }}" href="{{ route('contact') }}">Kontak</a>
                <a class="nav-track" href="{{ route('booking.lookup') }}">Cek Booking</a>
                @auth
                    @if(auth()->user()->isPatient())
                        <a class="nav-account" href="{{ route('patient.dashboard') }}">Akun Saya</a>
                        <a class="nav-account" href="{{ route('patient.medical-records.index') }}">Rekam Medis</a>
                        <form class="nav-logout-form" method="POST" action="{{ route('patient.logout') }}">@csrf<button type="submit">Keluar</button></form>
                    @elseif(auth()->user()->isDoctor())
                        <a class="nav-account" href="{{ route('doctor-portal.dashboard') }}">Portal Dokter</a>
                    @elseif(auth()->user()->is_admin)
                        <a class="nav-account" href="{{ route('admin.dashboard') }}">Dashboard Admin</a>
                    @endif
                @else
                    <a class="nav-login" href="{{ route('patient.login') }}">Masuk</a>
                    <a class="nav-account" href="{{ route('patient.register') }}">Daftar Pasien</a>
                @endauth
            </nav>
        </div>
    </header>

    @include('partials.flash')
    <main>
        @yield('content')
    </main>

    <footer class="site-footer">
        <div class="container footer-grid">
            <div><span class="footer-label">HUBUNGI KAMI</span><strong>{{ config('clinic.phone') }}</strong><p>Layanan Informasi & Pendaftaran</p></div>
            <div><span class="footer-label">ALAMAT</span><strong>{{ config('clinic.address') }}</strong><p>Rumah Sakit BSI</p></div>
            <div><span class="footer-label">JAM LAYANAN</span><strong>{{ config('clinic.open_hours') }}</strong><p>Informasi jadwal dokter dapat berubah.</p><p><a href="{{ route('doctor-portal.login') }}">Portal Dokter</a> · <a href="{{ route('admin.login') }}">Admin</a></p></div>
        </div>
        <div class="footer-bottom">Copyright © {{ date('Y') }} Rumah Sakit BSI. All Rights Reserved.</div>
    </footer>
    @if(request()->routeIs('appointments.create'))<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11" defer></script>@endif
    <script src="{{ asset('js/app.js') }}" defer></script>
    @stack('scripts')
</body>
</html>
