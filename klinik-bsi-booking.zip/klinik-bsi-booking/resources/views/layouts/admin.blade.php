<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') · Admin Rumah Sakit BSI</title>
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}"><link rel="stylesheet" href="{{ asset('css/admin.css') }}">
    @stack('styles')
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-sidebar" data-admin-sidebar>
        <a class="admin-brand" href="{{ route('admin.dashboard') }}"><span class="brand-mark">＋</span><span><strong>RS BSI</strong><small>ADMIN PANEL</small></span></a>
        <div class="sidebar-caption">MENU UTAMA</div>
        <nav class="sidebar-nav">
            <a href="{{ route('admin.dashboard') }}" class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}"><span>▦</span>Dashboard</a>
            <a href="{{ route('admin.appointments.index') }}" class="{{ request()->routeIs('admin.appointments.*') ? 'active' : '' }}"><span>▣</span>Booking Pasien</a>
            <a href="{{ route('admin.medical-records.index') }}" class="{{ request()->routeIs('admin.medical-records.*') ? 'active' : '' }}"><span>▤</span>Rekam Medis</a>
            <a href="{{ route('admin.doctors.index') }}" class="{{ request()->routeIs('admin.doctors.*') ? 'active' : '' }}"><span>⚕</span>Data Dokter</a>
            <a href="{{ route('admin.polyclinics.index') }}" class="{{ request()->routeIs('admin.polyclinics.*') ? 'active' : '' }}"><span>✚</span>Data Poli</a>
        </nav>
        <div class="sidebar-bottom"><div class="sidebar-user"><span class="admin-avatar">{{ strtoupper(substr(auth()->user()->name,0,1)) }}</span><div><strong>{{ auth()->user()->name }}</strong><small>Administrator</small></div></div><form method="POST" action="{{ route('admin.logout') }}">@csrf<button class="sidebar-logout" type="submit"><span>↪</span> Keluar</button></form><a href="{{ route('home') }}" class="sidebar-public-link" target="_blank" rel="noopener">Buka halaman pasien ↗</a></div>
    </aside>
    <div class="admin-main-wrap">
        <header class="admin-topbar"><button class="sidebar-toggle" type="button" data-admin-toggle aria-label="Buka navigasi">☰</button><div><span class="topbar-overline">ADMINISTRASI</span><strong>@yield('page-heading', 'Dashboard')</strong></div><div class="topbar-right"><span class="admin-live-dot"></span><span>Panel Admin</span><span class="topbar-date">{{ now('Asia/Jakarta')->format('d M Y') }}</span></div></header>
        <main class="admin-content">
            @if (session('success'))<div class="admin-alert success"><span>✓</span>{{ session('success') }}<button type="button" data-dismiss-alert>×</button></div>@endif
            @if (session('warning'))<div class="admin-alert warning"><span>!</span>{{ session('warning') }}<button type="button" data-dismiss-alert>×</button></div>@endif
            @if ($errors->any())<div class="admin-alert danger"><span>!</span><div><strong>Periksa kembali input berikut:</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div><button type="button" data-dismiss-alert>×</button></div>@endif
            @yield('content')
        </main>
    </div>
</div>
<script src="{{ asset('js/app.js') }}" defer></script>
@stack('scripts')
</body>
</html>
