@extends('layouts.public')
@section('title', 'Daftar Dokter')
@section('content')
<section class="page-hero compact-hero"><div class="container compact-hero-inner"><div><span class="eyebrow">TIM MEDIS KAMI</span><h1>Daftar Dokter</h1><p>Pilih dokter berdasarkan poli dan jadwal praktik yang tersedia.</p></div><img src="{{ asset('images/hero-medical-team.jpg') }}" alt="Tim medis"></div></section>
<section class="section"><div class="container">
    <form class="filter-bar" method="GET" action="{{ route('doctors.index') }}"><label class="filter-field"><span>Nama / Spesialisasi</span><input type="search" name="q" value="{{ request('q') }}" placeholder="Cari dokter atau spesialisasi"></label><label class="filter-field"><span>Poli</span><select name="polyclinic"><option value="">Semua Poli</option>@foreach($polyclinics as $p)<option value="{{ $p->id }}" @selected(request('polyclinic') == $p->id)>{{ $p->name }}</option>@endforeach</select></label><button class="btn btn-primary" type="submit">Cari Dokter</button></form>
    <div class="doctor-card-grid">@forelse($doctors as $doctor)<article class="doctor-card"><div class="doctor-card-photo"><img src="{{ $doctor->photo_url }}" alt="Foto {{ $doctor->name }}"><span class="tag tag-teal">{{ $doctor->polyclinic->name }}</span></div><div class="doctor-card-content"><h3>{{ $doctor->name }}{{ $doctor->title ? ', '.$doctor->title : '' }}</h3><p>{{ $doctor->speciality }}</p><div class="doctor-card-meta"><span>☆ {{ number_format((float)$doctor->rating,1) }}</span><span>{{ $doctor->experience_years }}+ tahun pengalaman</span></div><a class="btn btn-primary btn-block" href="{{ route('doctors.show', $doctor) }}">Lihat Profil & Jadwal</a></div></article>@empty<div class="empty-state full-span"><h3>Dokter tidak ditemukan</h3><p>Belum ada dokter sesuai filter yang dipilih.</p></div>@endforelse</div>
    <div class="pagination-wrap">{{ $doctors->links() }}</div>
</div></section>
@endsection
