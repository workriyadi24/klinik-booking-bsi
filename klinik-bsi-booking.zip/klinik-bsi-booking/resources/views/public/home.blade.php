@extends('layouts.public')
@section('title', 'Beranda & Jadwal Dokter')
@section('content')
<section class="home-hero">
    <div class="container home-hero-grid">
        <div class="home-hero-copy">
            <span class="eyebrow">LAYANAN KESEHATAN TERPERCAYA</span>
            <h1>Temukan Dokter<br><span>dan Buat Janji</span><br>dengan Mudah</h1>
            <p>Periksa jadwal praktik dokter, pilih jam yang tersedia, dan daftarkan kunjungan Anda tanpa harus antre untuk pendaftaran.</p>
            <div class="hero-actions"><a class="btn btn-primary" href="#jadwal-dokter">Cari Jadwal Dokter <span>→</span></a><a class="btn btn-outline" href="{{ route('booking.lookup') }}">Cek Booking</a></div>
            <div class="hero-points"><span><b>✓</b> Pilih jadwal per jam</span><span><b>✓</b> Konfirmasi lebih mudah</span></div>
        </div>
        <div class="home-hero-media"><img src="{{ asset('images/hero-medical-team.jpg') }}" alt="Tim dokter Rumah Sakit BSI"><div class="hero-floating"><span class="floating-icon">✚</span><div><strong>Booking online</strong><small>Praktis dan terjadwal</small></div></div></div>
    </div>
</section>

<section class="section section-search" id="jadwal-dokter">
    <div class="container">
        <div class="section-heading"><div><span class="eyebrow">INFORMASI</span><h2>Jadwal Dokter</h2><p>Temukan dokter dan pilih jadwal praktik yang sesuai dengan kebutuhan Anda.</p></div><a class="text-link" href="{{ route('doctors.index') }}">Lihat semua dokter <span>→</span></a></div>
        <form class="filter-bar" action="{{ route('home') }}" method="GET">
            <label class="filter-field"><span>Pilih Poli</span><select name="polyclinic"><option value="">Semua Poli</option>@foreach ($polyclinics as $polyclinic)<option value="{{ $polyclinic->id }}" @selected(request('polyclinic') == $polyclinic->id)>{{ $polyclinic->name }}</option>@endforeach</select></label>
            <label class="filter-field"><span>Nama Dokter</span><input type="search" name="doctor" placeholder="Cari nama dokter..." value="{{ request('doctor') }}"></label>
            <button class="btn btn-primary" type="submit">Tampilkan Jadwal</button>
        </form>

        <div class="doctor-list">
            @forelse ($doctors as $doctor)
                <article class="doctor-row-card">
                    <div class="doctor-mini-profile">
                        <div class="doctor-avatar-ring"><img src="{{ $doctor->photo_url }}" alt="Foto {{ $doctor->name }}"></div>
                        <div class="doctor-profile-text"><span class="tag tag-teal">{{ $doctor->polyclinic->name }}</span><h3>{{ $doctor->name }}{{ $doctor->title ? ', '.$doctor->title : '' }}</h3><p>{{ $doctor->speciality }}</p><div class="doctor-meta"><span>☆ {{ number_format((float) $doctor->rating, 1) }}</span><span>{{ $doctor->experience_years }}+ tahun pengalaman</span></div><a class="btn btn-small btn-primary" href="{{ route('appointments.create', $doctor) }}">Daftar Online</a></div>
                    </div>
                    <div class="weekly-schedule-wrap">
                        <div class="schedule-caption"><span>Jadwal Praktik</span><small>Jam yang ditampilkan adalah jam praktik dokter.</small></div>
                        <div class="weekly-grid">
                            @foreach (\App\Models\DoctorSchedule::DAYS as $day => $dayName)
                                @php($daySchedules = $doctor->schedules->where('day_of_week', $day)->where('is_active', true))
                                <div class="weekly-day"><strong>{{ substr($dayName, 0, 3) }}</strong><span>@forelse ($daySchedules as $schedule){{ substr($schedule->start_time, 0, 5) }}–{{ substr($schedule->end_time, 0, 5) }}@if(!$loop->last)<br>@endif @empty <em>–</em> @endforelse</span></div>
                            @endforeach
                        </div>
                        <div class="schedule-card-footer"><span><i class="mini-dot"></i> Slot dapat dipilih sesuai ketersediaan</span><a href="{{ route('doctors.show', $doctor) }}">Detail dokter <span>→</span></a></div>
                    </div>
                </article>
            @empty
                <div class="empty-state"><div class="empty-icon">⌕</div><h3>Dokter belum ditemukan</h3><p>Coba ubah pilihan poli atau kata kunci pencarian Anda.</p><a href="{{ route('home') }}" class="btn btn-outline">Reset Filter</a></div>
            @endforelse
        </div>
        <div class="pagination-wrap">{{ $doctors->links() }}</div>
    </div>
</section>
<section class="section section-soft"><div class="container feature-grid"><div><span class="eyebrow">ALUR PENDAFTARAN</span><h2>Booking dokter dalam<br><span>3 langkah sederhana</span></h2><p>Seluruh proses dirancang agar pasien dapat mendaftar dengan jelas dan nyaman.</p></div><div class="feature-item"><b>01</b><div><h3>Pilih dokter</h3><p>Tentukan poli dan dokter sesuai kebutuhan pemeriksaan.</p></div></div><div class="feature-item"><b>02</b><div><h3>Pilih tanggal & jam</h3><p>Jam yang telah dipesan otomatis tidak bisa dipilih pasien lain.</p></div></div><div class="feature-item"><b>03</b><div><h3>Isi data pasien</h3><p>Simpan kode booking untuk melihat status pendaftaran Anda.</p></div></div></div></section>
@endsection
