
@extends('layouts.public')

@section('title', 'Profil ' . $doctor->name)

@section('content')

<section class="doctor-detail-hero">
    <div class="container detail-hero-grid">

        <div class="detail-hero-copy">

            <a class="back-link" href="{{ route('doctors.index') }}">
                ← Kembali ke daftar dokter
            </a>

            <span class="tag tag-gradient">
                {{ $doctor->polyclinic->name }}
            </span>

            <h1>
                {{ $doctor->name }}{{ $doctor->title ? ', ' . $doctor->title : '' }}
            </h1>

            <p class="detail-speciality">
                {{ $doctor->speciality }} · {{ $doctor->practice_location }}
            </p>

            <div class="detail-stats">

                <div>
                    <span class="stat-icon">♧</span>
                    <strong>{{ $doctor->experience_years }}+ Tahun</strong>
                    <small>Pengalaman</small>
                </div>

                <div>
                    <span class="stat-icon">☆</span>
                    <strong>{{ number_format((float) $doctor->rating, 1) }}</strong>
                    <small>Rating ({{ $doctor->rating_count }}+)</small>
                </div>

                <div>
                    <span class="stat-icon">✚</span>
                    <strong>{{ $doctor->polyclinic->name }}</strong>
                    <small>Poliklinik</small>
                </div>

            </div>

            <p class="doctor-bio">
                {{ $doctor->bio ?: 'Silakan pilih jadwal praktik untuk membuat janji konsultasi dengan dokter.' }}
            </p>

            <a class="btn btn-primary" href="{{ route('appointments.create', $doctor) }}">
                Buat Janji Sekarang
                <span>→</span>
            </a>

        </div>

        <div class="detail-doctor-image">
            <img
                src="{{ $doctor->photo_url }}"
                alt="Foto {{ $doctor->name }}"
            >
        </div>

    </div>
</section>


<section class="section">
    <div class="container detail-schedule-layout">

        <div>

            <span class="eyebrow">JADWAL PRAKTIK</span>

            <h2>Waktu konsultasi</h2>

            <p>
                Pilih tanggal untuk melihat slot per jam yang masih tersedia.
            </p>

            <div class="schedule-table-card">

                <table class="data-table">

                    <thead>
                        <tr>
                            <th>Hari</th>
                            <th>Jam Praktik</th>
                            <th>Durasi Slot</th>
                        </tr>
                    </thead>

                    <tbody>

                        @foreach (\App\Models\DoctorSchedule::DAYS as $day => $dayName)

                            @php
                                $items = $doctor->schedules
                                    ->where('day_of_week', $day)
                                    ->where('is_active', true);
                            @endphp

                            <tr>

                                <td>
                                    {{ $dayName }}
                                </td>

                                <td>

                                    @if ($items->isNotEmpty())

                                        @foreach ($items as $schedule)

                                            {{ substr($schedule->start_time, 0, 5) }}
                                            –
                                            {{ substr($schedule->end_time, 0, 5) }}

                                            @if (!$loop->last)
                                                ,
                                            @endif

                                        @endforeach

                                    @else

                                        <span class="text-muted">
                                            Tidak praktik
                                        </span>

                                    @endif

                                </td>

                                <td>

                                    @if ($items->isNotEmpty())

                                        @foreach ($items as $schedule)

                                            {{ $schedule->slot_duration_minutes }} menit

                                            @if (!$loop->last)
                                                ,
                                            @endif

                                        @endforeach

                                    @else

                                        –

                                    @endif

                                </td>

                            </tr>

                        @endforeach

                    </tbody>

                </table>

            </div>

        </div>


        <aside class="detail-booking-box">

            <div class="booking-box-icon">
                ▦
            </div>

            <h3>Siap membuat janji?</h3>

            <p>
                Jadwal tersedia diperbarui berdasarkan pemesanan pasien lainnya.
            </p>

            <a
                class="btn btn-primary btn-block"
                href="{{ route('appointments.create', $doctor) }}"
            >
                Pilih Tanggal & Jam
            </a>

            <div class="help-line">

                <span>☎</span>

                <div>
                    <strong>Butuh bantuan?</strong>
                    <small>{{ config('clinic.phone') }}</small>
                </div>

            </div>

        </aside>

    </div>
</section>

@endsection
