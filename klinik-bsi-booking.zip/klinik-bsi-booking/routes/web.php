<?php

use App\Http\Controllers\Admin\AppointmentController as AdminAppointmentController;
use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\DoctorController as AdminDoctorController;
use App\Http\Controllers\Admin\PolyclinicController as AdminPolyclinicController;
use App\Http\Controllers\Admin\ScheduleController as AdminScheduleController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\BookingLookupController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PatientAuthController;
use App\Http\Controllers\PatientProfileController;
use App\Http\Controllers\PatientPortalController;
use App\Http\Controllers\PatientMedicalRecordController;
use App\Http\Controllers\DoctorMedicalRecordController;
use App\Http\Controllers\Admin\MedicalRecordController as AdminMedicalRecordController;
use App\Http\Controllers\DoctorPortalAuthController;
use App\Http\Controllers\DoctorPortalController;
use App\Http\Controllers\PublicPageController;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/dokter', [DoctorController::class, 'index'])->name('doctors.index');
Route::get('/dokter/{doctor:slug}', [DoctorController::class, 'show'])->name('doctors.show');
Route::get('/dokter/{doctor:slug}/slots', [AppointmentController::class, 'slots'])->name('doctors.slots');
Route::get('/janji/{doctor:slug}', [AppointmentController::class, 'create'])->name('appointments.create');
Route::get('/janji/{doctor:slug}/pendaftaran', [AppointmentController::class, 'register'])->name('appointments.register');
Route::post('/janji/{doctor:slug}/daftar', [AppointmentController::class, 'store'])->name('appointments.store');
Route::get('/booking/{appointment:booking_code}', [AppointmentController::class, 'showBooking'])->name('booking.show');
Route::get('/cek-booking', [BookingLookupController::class, 'index'])->name('booking.lookup');
Route::post('/cek-booking', [BookingLookupController::class, 'lookup'])->name('booking.lookup.submit');

// Akun dan area pasien.
Route::prefix('pasien')->name('patient.')->group(function () {
    Route::get('/login', [PatientAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [PatientAuthController::class, 'login'])->middleware('throttle:10,1')->name('login.submit');
    Route::get('/daftar', [PatientAuthController::class, 'showRegister'])->name('register');
    Route::post('/daftar', [PatientAuthController::class, 'register'])->middleware('throttle:10,1')->name('register.submit');
    Route::get('/google', [PatientAuthController::class, 'googleRedirect'])->name('google.redirect');
    Route::get('/google/callback', [PatientAuthController::class, 'googleCallback'])->name('google.callback');
    Route::post('/logout', [PatientAuthController::class, 'logout'])->name('logout');

    Route::middleware('patient')->group(function () {
        Route::get('/profil/lengkapi', [PatientProfileController::class, 'create'])->name('profile.create');
        Route::post('/profil/lengkapi', [PatientProfileController::class, 'store'])->name('profile.store');
        Route::get('/profil', [PatientProfileController::class, 'edit'])->name('profile.edit');
        Route::put('/profil', [PatientProfileController::class, 'update'])->name('profile.update');
        Route::get('/dashboard', [PatientPortalController::class, 'dashboard'])->name('dashboard');
        Route::get('/rekam-medis', [PatientMedicalRecordController::class, 'index'])->name('medical-records.index');
        Route::get('/rekam-medis/{medicalRecord}', [PatientMedicalRecordController::class, 'show'])->name('medical-records.show');
        Route::patch('/janji/{appointment}/batal', [PatientPortalController::class, 'cancel'])->name('appointments.cancel');
    });
});

// Portal dokter terpisah dari halaman direktori dokter untuk umum.
Route::prefix('portal-dokter')->name('doctor-portal.')->group(function () {
    Route::get('/login', [DoctorPortalAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [DoctorPortalAuthController::class, 'login'])->middleware('throttle:10,1')->name('login.submit');
    Route::post('/logout', [DoctorPortalAuthController::class, 'logout'])->name('logout');
    Route::middleware('doctor')->group(function () {
        Route::get('/', [DoctorPortalController::class, 'dashboard'])->name('dashboard');
        Route::get('/janji/{appointment}', [DoctorPortalController::class, 'show'])->name('appointments.show');
        Route::put('/janji/{appointment}', [DoctorPortalController::class, 'update'])->name('appointments.update');
        Route::get('/rekam-medis', [DoctorMedicalRecordController::class, 'index'])->name('medical-records.index');
        Route::get('/janji/{appointment}/rekam-medis/buat', [DoctorMedicalRecordController::class, 'create'])->name('medical-records.create');
        Route::post('/janji/{appointment}/rekam-medis', [DoctorMedicalRecordController::class, 'store'])->name('medical-records.store');
        Route::get('/rekam-medis/{medicalRecord}', [DoctorMedicalRecordController::class, 'show'])->name('medical-records.show');
        Route::get('/rekam-medis/{medicalRecord}/edit', [DoctorMedicalRecordController::class, 'edit'])->name('medical-records.edit');
        Route::put('/rekam-medis/{medicalRecord}', [DoctorMedicalRecordController::class, 'update'])->name('medical-records.update');
        Route::post('/rekam-medis/{medicalRecord}/addendum', [DoctorMedicalRecordController::class, 'addendum'])->name('medical-records.addendum');
    });
});

Route::get('/informasi', [PublicPageController::class, 'information'])->name('information');
Route::get('/kontak', [PublicPageController::class, 'contact'])->name('contact');

Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/login', [AdminAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AdminAuthController::class, 'login'])->middleware('throttle:10,1')->name('login.submit');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

    Route::middleware('admin')->group(function () {
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        Route::get('/appointments', [AdminAppointmentController::class, 'index'])->name('appointments.index');
        Route::get('/medical-records', [AdminMedicalRecordController::class, 'index'])->name('medical-records.index');
        Route::get('/medical-records/{medicalRecord}', [AdminMedicalRecordController::class, 'show'])->name('medical-records.show');
        Route::get('/appointments/{appointment}', [AdminAppointmentController::class, 'show'])->name('appointments.show');
        Route::get('/appointments/{appointment}/edit', [AdminAppointmentController::class, 'edit'])->name('appointments.edit');
        Route::put('/appointments/{appointment}', [AdminAppointmentController::class, 'update'])->name('appointments.update');
        Route::patch('/appointments/{appointment}/no-show', [AdminAppointmentController::class, 'markNoShow'])->name('appointments.no-show');
        Route::get('/doctors/{doctor}/slots', [AdminAppointmentController::class, 'slots'])->name('doctors.slots');

        Route::get('/doctors', [AdminDoctorController::class, 'index'])->name('doctors.index');
        Route::get('/doctors/create', [AdminDoctorController::class, 'create'])->name('doctors.create');
        Route::post('/doctors', [AdminDoctorController::class, 'store'])->name('doctors.store');
        Route::get('/doctors/{doctor}/edit', [AdminDoctorController::class, 'edit'])->name('doctors.edit');
        Route::put('/doctors/{doctor}', [AdminDoctorController::class, 'update'])->name('doctors.update');
        Route::patch('/doctors/{doctor}/toggle', [AdminDoctorController::class, 'toggle'])->name('doctors.toggle');
        Route::get('/doctors/{doctor}/schedules', [AdminScheduleController::class, 'index'])->name('doctors.schedules.index');
        Route::post('/doctors/{doctor}/schedules', [AdminScheduleController::class, 'store'])->name('doctors.schedules.store');
        Route::put('/doctors/{doctor}/schedules/{schedule}', [AdminScheduleController::class, 'update'])->name('doctors.schedules.update');
        Route::delete('/doctors/{doctor}/schedules/{schedule}', [AdminScheduleController::class, 'destroy'])->name('doctors.schedules.destroy');
        Route::post('/doctors/{doctor}/exceptions', [AdminScheduleController::class, 'saveException'])->name('doctors.exceptions.store');
        Route::delete('/doctors/{doctor}/exceptions/{exception}', [AdminScheduleController::class, 'deleteException'])->name('doctors.exceptions.destroy');

        Route::get('/polyclinics', [AdminPolyclinicController::class, 'index'])->name('polyclinics.index');
        Route::get('/polyclinics/create', [AdminPolyclinicController::class, 'create'])->name('polyclinics.create');
        Route::post('/polyclinics', [AdminPolyclinicController::class, 'store'])->name('polyclinics.store');
        Route::get('/polyclinics/{polyclinic}/edit', [AdminPolyclinicController::class, 'edit'])->name('polyclinics.edit');
        Route::put('/polyclinics/{polyclinic}', [AdminPolyclinicController::class, 'update'])->name('polyclinics.update');
        Route::patch('/polyclinics/{polyclinic}/toggle', [AdminPolyclinicController::class, 'toggle'])->name('polyclinics.toggle');
    });
});
