<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('clinic:about', function () {
    $this->info('Sistem Booking Dokter - Rumah Sakit BSI');
})->purpose('Menampilkan informasi aplikasi klinik.');
