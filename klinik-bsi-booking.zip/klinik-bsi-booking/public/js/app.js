(() => {
    'use strict';

    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

    document.addEventListener('DOMContentLoaded', () => {
        const navToggle = $('[data-nav-toggle]');
        const navMenu = $('[data-nav-menu]');
        navToggle?.addEventListener('click', () => {
            const opened = navMenu?.classList.toggle('open') ?? false;
            navToggle.setAttribute('aria-expanded', opened ? 'true' : 'false');
        });

        const sidebarToggle = $('[data-admin-toggle]');
        const sidebar = $('[data-admin-sidebar]');
        sidebarToggle?.addEventListener('click', () => sidebar?.classList.toggle('open'));
        document.addEventListener('click', (event) => {
            if (sidebar?.classList.contains('open') && !sidebar.contains(event.target) && !sidebarToggle?.contains(event.target)) {
                sidebar.classList.remove('open');
            }
        });

        $$('[data-dismiss-alert]').forEach((button) => {
            button.addEventListener('click', () => button.closest('.alert, .admin-alert')?.remove());
        });

        $$('[data-copy]').forEach((button) => {
            button.addEventListener('click', async () => {
                const value = button.dataset.copy || '';
                try {
                    await navigator.clipboard.writeText(value);
                    button.textContent = 'Tersalin ✓';
                } catch (_) {
                    const helper = document.createElement('textarea');
                    helper.value = value;
                    document.body.appendChild(helper);
                    helper.select();
                    document.execCommand('copy');
                    helper.remove();
                    button.textContent = 'Tersalin ✓';
                }
                window.setTimeout(() => { button.textContent = 'Salin kode'; }, 1800);
            });
        });

        initPublicSlotPicker();
        initAdminSlotPicker();
        initImagePreview();
        initSpecialHoursToggle();
    });

    function formatDate(dateString) {
        if (!dateString) return '';
        const date = new Date(`${dateString}T00:00:00`);
        return new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' }).format(date);
    }

    function initPublicSlotPicker() {
        const picker = $('[data-slot-picker]');
        if (!picker) return;

        const dateInput = $('[data-slot-date]', picker);
        const slotList = $('[data-slot-list]', picker);
        const feedback = $('[data-slot-feedback]', picker);
        const dateLabel = $('[data-slot-date-label]', picker);
        const dateValue = $('[data-slot-date-value]', picker);
        const timeValue = $('[data-slot-time-value]', picker);
        const submitButton = $('[data-slot-submit]', picker);
        const form = $('[data-slot-form]', picker);
        let selectedTime = '';
        let requestSequence = 0;

        const setSelection = (time) => {
            selectedTime = time || '';
            timeValue.value = selectedTime;
            dateValue.value = dateInput.value;
            submitButton.disabled = !selectedTime;
            $$('.slot-button', slotList).forEach((button) => {
                button.classList.toggle('selected', button.dataset.time === selectedTime);
            });
            feedback.textContent = selectedTime
                ? `Jam ${selectedTime} dipilih. Silakan lanjutkan pengisian data pasien.`
                : 'Pilih salah satu jam yang masih tersedia.';
        };

        const loadSlots = async (showAlert = false) => {
            const date = dateInput.value;
            const seq = ++requestSequence;
            setSelection('');
            dateValue.value = date;
            dateLabel.textContent = formatDate(date);
            slotList.innerHTML = '<div class="slot-placeholder">Memuat jadwal dokter...</div>';
            feedback.textContent = 'Memeriksa ketersediaan jam.';

            if (!date) {
                slotList.innerHTML = '<div class="slot-placeholder">Pilih tanggal terlebih dahulu.</div>';
                return;
            }

            try {
                const response = await fetch(`${picker.dataset.slotsUrl}?date=${encodeURIComponent(date)}`, {
                    headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
                });
                if (!response.ok) throw new Error('Jadwal tidak dapat dimuat.');
                const payload = await response.json();
                if (seq !== requestSequence) return;

                slotList.innerHTML = '';
                if (!payload.slots?.length) {
                    slotList.innerHTML = '<div class="slot-placeholder">Tidak ada jadwal praktik pada tanggal ini.</div>';
                    feedback.textContent = 'Silakan pilih tanggal praktik lainnya.';
                    if (showAlert && window.Swal) window.Swal.fire({ icon: 'info', title: 'Jadwal tidak tersedia', text: 'Dokter tidak memiliki jadwal praktik pada tanggal tersebut. Silakan pilih tanggal lain.', confirmButtonText: 'Pilih tanggal lain', confirmButtonColor: '#20ad70' });
                    return;
                }

                let availableCount = 0;
                payload.slots.forEach((slot) => {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.className = 'slot-button';
                    button.textContent = slot.time;
                    button.dataset.time = slot.time;
                    button.disabled = !slot.available;
                    button.title = slot.reason || `Tersedia sampai ${slot.end_time}`;
                    if (slot.available) {
                        availableCount++;
                        button.addEventListener('click', () => setSelection(slot.time));
                    } else {
                        button.classList.add('unavailable');
                    }
                    slotList.appendChild(button);
                });
                feedback.textContent = availableCount
                    ? `${availableCount} slot masih tersedia. Jam yang sudah dipesan tidak dapat dipilih.`
                    : 'Semua slot pada tanggal ini telah terisi atau sudah lewat.';
                if (showAlert && availableCount === 0 && window.Swal) window.Swal.fire({ icon: 'warning', title: 'Slot sudah penuh', text: 'Tidak ada jam yang dapat dipilih pada tanggal ini. Silakan coba tanggal lain.', confirmButtonText: 'Mengerti', confirmButtonColor: '#20ad70' });
            } catch (error) {
                slotList.innerHTML = '<div class="slot-placeholder">Jadwal gagal dimuat. Coba kembali.</div>';
                feedback.textContent = error.message;
            }
        };

        dateInput.addEventListener('change', () => loadSlots(true));
        form?.addEventListener('submit', (event) => {
            if (!selectedTime) {
                event.preventDefault();
                feedback.textContent = 'Pilih jam praktik sebelum melanjutkan.';
            }
        });
        loadSlots();
    }

    function initAdminSlotPicker() {
        const form = $('[data-admin-slot-picker]');
        if (!form) return;

        const doctorSelect = $('[data-admin-doctor]', form);
        const dateInput = $('[data-admin-date]', form);
        const timeSelect = $('[data-admin-time]', form);
        const hint = $('[data-admin-slot-hint]', form);
        const template = form.dataset.slotsUrlTemplate;
        const exceptId = form.dataset.exceptId || '';
        const currentTime = form.dataset.currentTime || '';
        const currentDate = form.dataset.currentDate || '';
        const currentDoctor = form.dataset.currentDoctor || '';
        let sequence = 0;

        const loadSlots = async () => {
            const option = doctorSelect.options[doctorSelect.selectedIndex];
            const slug = option?.dataset.doctorSlug;
            const date = dateInput.value;
            const seq = ++sequence;
            timeSelect.innerHTML = '<option value="">Memuat slot...</option>';
            timeSelect.disabled = true;
            hint.textContent = 'Memeriksa slot yang tersedia.';
            if (!slug || !date) return;

            const url = template.replace('__DOCTOR__', encodeURIComponent(slug));
            const params = new URLSearchParams({ date, except: exceptId });
            try {
                const response = await fetch(`${url}?${params.toString()}`, { headers: { 'Accept': 'application/json' } });
                if (!response.ok) throw new Error('Slot tidak dapat dimuat.');
                const payload = await response.json();
                if (seq !== sequence) return;

                timeSelect.innerHTML = '';
                const placeholder = document.createElement('option');
                placeholder.value = '';
                placeholder.textContent = 'Pilih jam tersedia';
                placeholder.selected = true;
                timeSelect.appendChild(placeholder);
                let currentIncluded = false;
                (payload.slots || []).forEach((slot) => {
                    const isCurrent = slug === currentDoctor && date === currentDate && slot.time === currentTime;
                    const optionElement = document.createElement('option');
                    optionElement.value = slot.time;
                    optionElement.textContent = `${slot.time} - ${slot.end_time}${isCurrent ? ' · Jadwal saat ini' : (slot.available ? ' · Tersedia' : ' · Tidak tersedia')}`;
                    optionElement.disabled = !slot.available && !isCurrent;
                    optionElement.selected = isCurrent;
                    if (isCurrent) currentIncluded = true;
                    timeSelect.appendChild(optionElement);
                });

                if (slug === currentDoctor && date === currentDate && currentTime && !currentIncluded) {
                    const currentOption = document.createElement('option');
                    currentOption.value = currentTime;
                    currentOption.textContent = `${currentTime} · Jadwal saat ini`;
                    currentOption.selected = true;
                    timeSelect.prepend(currentOption);
                }

                if (!timeSelect.options.length) {
                    timeSelect.innerHTML = '<option value="">Tidak ada slot tersedia</option>';
                    hint.textContent = 'Tidak ada jadwal yang tersedia pada tanggal ini.';
                } else {
                    hint.textContent = 'Slot tidak tersedia akan dinonaktifkan. Jadwal saat ini tetap dapat dipertahankan.';
                    timeSelect.disabled = false;
                }
            } catch (error) {
                timeSelect.innerHTML = '<option value="">Gagal memuat slot</option>';
                hint.textContent = error.message;
            }
        };

        doctorSelect.addEventListener('change', loadSlots);
        dateInput.addEventListener('change', loadSlots);
        loadSlots();
    }

    function initImagePreview() {
        const input = $('[data-image-input]');
        const preview = $('[data-image-preview]');
        if (!input || !preview) return;
        input.addEventListener('change', () => {
            const file = input.files?.[0];
            if (!file) return;
            if (!file.type.startsWith('image/')) return;
            preview.src = URL.createObjectURL(file);
        });
    }

    function initSpecialHoursToggle() {
        const checkbox = $('[data-closed-toggle]');
        const fields = $('[data-special-hours]');
        if (!checkbox || !fields) return;
        const sync = () => {
            fields.hidden = checkbox.checked;
            $$('input', fields).forEach((input) => { input.required = !checkbox.checked; });
        };
        checkbox.addEventListener('change', sync);
        sync();
    }
})();
