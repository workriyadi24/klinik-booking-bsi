# Sistem Booking Dokter - Rumah Sakit BSI

Aplikasi ini menggunakan Laravel 12 dan PHP 8.2+. Sistem memiliki tiga aktor: pasien, dokter, dan admin.

## Fitur utama

### Pasien
- Registrasi dan login dengan email/password.
- Login atau pendaftaran akun melalui Google OAuth (perlu Client ID dan Client Secret dari Google Cloud).
- Profil pasien dan informasi kesehatan disimpan satu kali pada akun.
- Booking dokter berdasarkan tanggal dan slot yang tersedia.
- Slot yang telah dipesan atau telah lewat tidak dapat dipilih. Jika tanggal tidak memiliki jadwal, aplikasi menampilkan pemberitahuan.
- Dashboard pasien untuk memantau status, melihat detail, membatalkan booking yang masih menunggu, dan membuka riwayat RME yang telah disahkan.

### Dokter
- Login melalui portal dokter terpisah.
- Hanya dapat melihat appointment dan rekam medis yang terhubung dengan akun dokternya sendiri.
- Dapat melihat profil pasien, riwayat penyakit, alergi, obat aktif, keluhan, gejala, serta durasi gejala.
- Saat menangani janji temu pasien, dokter juga memperoleh ringkasan maksimal lima rekam medis final terdahulu lintas dokter/poliklinik; setiap pembukaan ringkasan dicatat di audit log.
- Dapat mengonfirmasi janji temu dan membuat Rekam Medis Elektronik (RME) ketika waktu pemeriksaan telah dimulai.
- Form RME mencakup anamnesis, pemeriksaan objektif, tanda vital, asesmen/diagnosis, rencana terapi, tindakan, resep terstruktur, serta rencana kontrol.
- Draf dapat disimpan dan dilanjutkan. Pengesahan RME otomatis menyelesaikan janji temu.
- RME yang telah disahkan dikunci. Koreksi atau informasi tambahan dicatat sebagai addendum agar catatan final awal tidak tertimpa.

### Rekam Medis Elektronik (RME)
- Satu appointment hanya dapat memiliki satu RME.
- Setiap RME terhubung ke nomor RM pasien, dokter, poliklinik, dan booking sumbernya.
- Pasien hanya dapat melihat RME miliknya yang sudah disahkan.
- Admin memiliki tampilan baca-saja untuk administrasi dan audit.
- Sistem mencatat aktivitas pembuatan, perubahan draf, pengesahan, addendum, dan pembukaan catatan oleh pasien/dokter/admin.
- Resep memiliki nomor resep, daftar item obat, dosis, frekuensi, durasi, jumlah, dan petunjuk. Fitur ini belum terhubung dengan apotek atau formularium obat.

### Admin
- Login administrator yang sudah tersedia.
- Dashboard ringkasan booking.
- Mengelola booking, dokter, akun login dokter, poliklinik, jadwal reguler, dan pengecualian jadwal.

## Persyaratan

- PHP 8.2 atau lebih baru
- Composer 2
- MySQL 8+ atau MariaDB yang kompatibel
- Ekstensi PHP yang dibutuhkan Laravel 12 (contoh: `pdo_mysql`, `mbstring`, `openssl`, `tokenizer`, `xml`, `ctype`, `json`, `fileinfo`)

## Setup lokal (Windows PowerShell)

1. Ekstrak ZIP, lalu buka folder `klinik-bsi-booking` di terminal.
2. Buat database MySQL bernama `klinik_booking`.
3. Salin file environment:

   ```powershell
   Copy-Item .env.example .env
   ```

4. Sesuaikan `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, dan `DB_PASSWORD` pada `.env`.
5. Install dependency dan siapkan aplikasi:

   ```bash
   composer install
   php artisan key:generate
   php artisan migrate --seed
   php artisan storage:link
   php artisan optimize:clear
   php artisan serve
   ```

7. Jalankan pengujian otomatis (setelah dependency terpasang):

   ```bash
   php artisan test
   ```

6. Buka `http://127.0.0.1:8000`.

> Bila database demo sebelumnya sudah berisi data dan Anda memang ingin mengosongkannya, gunakan `php artisan migrate:fresh --seed` sebagai pengganti `php artisan migrate --seed`. Perintah `migrate:fresh` menghapus seluruh tabel dan data pada database yang sedang terhubung.

Frontend sudah menggunakan file CSS/JS lokal pada folder `public`; tidak diperlukan `npm install` untuk menjalankan versi ini.

## Demo rekam medis

Seed membuat satu contoh kunjungan yang sudah selesai untuk pasien demo pertama (kode booking `BSIDEMO003`). RME contoh dapat dibuka dari akun pasien `pasien@rumahsakit.test`, akun dokter yang terkait, atau halaman admin. Isi resep pada seed diberi label placeholder dan bukan obat atau instruksi medis nyata.

## Akun demo

Semua akun demo memakai password `password`. Ganti password dan nonaktifkan akun demo sebelum aplikasi dipakai sungguhan.

| Peran | Email | Password |
|---|---|---|
| Admin | `admin@rumahsakit.test` | `password` |
| Pasien | `pasien@rumahsakit.test` | `password` |
| Pasien kedua | `pasien2@rumahsakit.test` | `password` |
| Dokter 1 - Syifa | `dokter1@rumahsakit.test` | `password` |
| Dokter 2 - Andi | `dokter2@rumahsakit.test` | `password` |
| Dokter 3 - Nabila | `dokter3@rumahsakit.test` | `password` |
| Dokter 4 - Bima | `dokter4@rumahsakit.test` | `password` |

## Mengaktifkan login Google

Login Google sengaja tidak memakai kredensial dummy. Buat OAuth 2.0 Client ID bertipe **Web application** melalui Google Cloud Console, aktifkan Google Identity/OAuth, lalu tambahkan Authorized redirect URI yang sama persis dengan URL callback aplikasi. Untuk lokal:

```dotenv
GOOGLE_CLIENT_ID=isi-client-id-anda
GOOGLE_CLIENT_SECRET=isi-client-secret-anda
GOOGLE_REDIRECT_URI="http://127.0.0.1:8000/pasien/google/callback"
```

Pastikan `APP_URL` juga bernilai `http://127.0.0.1:8000`, lalu jalankan:

```bash
php artisan config:clear
```

Email dari Google harus berstatus terverifikasi. Jika email Google sudah terhubung dengan akun pasien, sistem akan menautkan login Google ke akun tersebut. Email yang dipakai akun admin/dokter tidak dapat digunakan sebagai akun pasien.

## Jalur halaman

- Halaman publik: `/`
- Login/daftar pasien: `/pasien/login` dan `/pasien/daftar`
- Dashboard pasien: `/pasien/dashboard`
- Riwayat RME pasien: `/pasien/rekam-medis`
- Portal dokter: `/portal-dokter/login`
- Daftar RME dokter: `/portal-dokter/rekam-medis`
- Portal admin: `/admin/login`
- Daftar RME admin: `/admin/medical-records`

## Catatan sebelum production

- Akun dan data seed hanya untuk demo. Ubah seluruh password default dan jangan memakai `.env` lokal di server publik.
- Pasang HTTPS, email verification, kebijakan backup, logging/monitoring, dan konfigurasi session yang aman sebelum dipakai secara operasional.
- Foto dokter pada data demo merupakan potret fotorealistis untuk kebutuhan prototipe. Ganti dengan foto resmi dokter yang telah memperoleh izin sebelum aplikasi dipublikasikan.
- Sistem ini merupakan prototipe administrasi, booking, dan dokumentasi klinis. Sebelum penggunaan operasional, sesuaikan prosedur klinik, validasi tenaga kesehatan, retensi/backup, kebijakan akses, dan ketentuan perlindungan data kesehatan yang berlaku. Keputusan medis tetap menjadi tanggung jawab tenaga kesehatan yang berwenang.
