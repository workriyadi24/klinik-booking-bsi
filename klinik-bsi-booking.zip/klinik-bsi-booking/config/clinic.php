<?php

return [
    'name' => env('CLINIC_NAME', 'Rumah Sakit BSI'),
    'phone' => env('CLINIC_PHONE', '021 12345678'),
    'email' => env('CLINIC_EMAIL', 'info@rumahsakit.test'),
    'address' => env('CLINIC_ADDRESS', 'Jl. Sudirman No. 123, Jakarta Timur, Indonesia'),
    'open_hours' => env('CLINIC_OPEN_HOURS', 'Senin - Sabtu, 07.00 - 15.00 WIB'),
];
