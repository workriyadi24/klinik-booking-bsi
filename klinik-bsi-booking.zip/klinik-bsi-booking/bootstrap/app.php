<?php

use App\Http\Middleware\EnsureAdmin;
use App\Http\Middleware\EnsureDoctor;
use App\Http\Middleware\EnsurePatient;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'admin' => EnsureAdmin::class,
            'patient' => EnsurePatient::class,
            'doctor' => EnsureDoctor::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // Default Laravel exception handling is retained.
    })
    ->create();
